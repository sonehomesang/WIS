import { initializeApp, cert } from 'firebase-admin/app';
import { getFirestore } from 'firebase-admin/firestore';
import { getStorage } from 'firebase-admin/storage';
import * as dotenv from 'dotenv';
import * as path from 'path';

dotenv.config();

// Note: You must provide a service account JSON file to run this script safely in production
// Usage: export GOOGLE_APPLICATION_CREDENTIALS="path/to/serviceAccountKey.json" before running

const app = initializeApp({
  projectId: process.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: process.env.VITE_FIREBASE_STORAGE_BUCKET
});

const db = getFirestore(app);
const storage = getStorage(app);
const bucket = storage.bucket();

async function uploadBase64(base64Str: string, destPath: string): Promise<string> {
  const matches = base64Str.match(/^data:(.+);base64,(.+)$/);
  if (!matches || matches.length !== 3) {
    throw new Error('Invalid base64 string');
  }
  
  const mimeType = matches[1];
  const base64Data = matches[2];
  const buffer = Buffer.from(base64Data, 'base64');
  
  const file = bucket.file(destPath);
  await file.save(buffer, {
    metadata: { contentType: mimeType }
  });
  
  await file.makePublic(); // Or handle signed URLs based on your access pattern
  return `https://storage.googleapis.com/${bucket.name}/${destPath}`;
}

async function migrateUsers() {
  console.log("Migrating users...");
  const snapshot = await db.collection('users').get();
  for (const doc of snapshot.docs) {
    const data = doc.data();
    if (data.photoURL && data.photoURL.startsWith('data:')) {
      console.log(`Migrating avatar for user ${doc.id}`);
      try {
        const url = await uploadBase64(data.photoURL, `users/${doc.id}/avatar.jpg`);
        await doc.ref.update({ photoURL: url });
      } catch (e) {
        console.error(`Failed to migrate user ${doc.id}`, e);
      }
    }
  }
}

async function migrateInventory() {
  console.log("Migrating inventory...");
  const snapshot = await db.collection('inventory').get();
  for (const doc of snapshot.docs) {
    const data = doc.data();
    if (data.photos && Array.isArray(data.photos)) {
      let changed = false;
      const newPhotos = [];
      for (let i = 0; i < data.photos.length; i++) {
        const p = data.photos[i];
        if (typeof p === 'string' && p.startsWith('data:')) {
          console.log(`Migrating photo ${i} for inventory ${doc.id}`);
          try {
            const url = await uploadBase64(p, `inventory/${doc.id}/photo_${Date.now()}_${i}.jpg`);
            newPhotos.push(url);
            changed = true;
          } catch (e) {
            console.error(`Failed to migrate inventory photo ${doc.id}`, e);
            newPhotos.push(p);
          }
        } else {
          newPhotos.push(p);
        }
      }
      if (changed) {
        await doc.ref.update({ photos: newPhotos });
      }
    }
  }
}

async function migrateBorrowRecords() {
  console.log("Migrating borrow records...");
  const snapshot = await db.collection('borrow_records').get();
  for (const doc of snapshot.docs) {
    const data = doc.data();
    let docChanged = false;
    
    // Migrate return photos
    if (data.returnPhotos && Array.isArray(data.returnPhotos)) {
      const newReturnPhotos = [];
      for (let i = 0; i < data.returnPhotos.length; i++) {
        const p = data.returnPhotos[i];
        if (typeof p === 'string' && p.startsWith('data:')) {
          try {
            const url = await uploadBase64(p, `borrow_records/${doc.id}/return_${Date.now()}_${i}.jpg`);
            newReturnPhotos.push(url);
            docChanged = true;
          } catch (e) {
            newReturnPhotos.push(p);
          }
        } else {
          newReturnPhotos.push(p);
        }
      }
      if (docChanged) data.returnPhotos = newReturnPhotos;
    }

    // Migrate items photos
    if (data.items && Array.isArray(data.items)) {
      for (let itemIndex = 0; itemIndex < data.items.length; itemIndex++) {
        const item = data.items[itemIndex];
        
        for (const photoType of ['materialPhotos', 'stockPhotos']) {
          if (item[photoType] && Array.isArray(item[photoType])) {
            const newPhotos = [];
            for (let i = 0; i < item[photoType].length; i++) {
              const p = item[photoType][i];
              if (typeof p === 'string' && p.startsWith('data:')) {
                console.log(`Migrating ${photoType} ${i} for record ${doc.id} item ${itemIndex}`);
                try {
                  const url = await uploadBase64(p, `borrow_records/${doc.id}/${itemIndex}/${photoType.replace('Photos', '')}_${Date.now()}_${i}.jpg`);
                  newPhotos.push(url);
                  docChanged = true;
                } catch (e) {
                  newPhotos.push(p);
                }
              } else {
                newPhotos.push(p);
              }
            }
            item[photoType] = newPhotos;
          }
        }
      }
    }

    if (docChanged) {
      await doc.ref.update({
        returnPhotos: data.returnPhotos,
        items: data.items
      });
    }
  }
}

async function run() {
  await migrateUsers();
  await migrateInventory();
  await migrateBorrowRecords();
  console.log("Migration complete.");
}

run().catch(console.error);
