import { initializeApp } from 'firebase/app';
import { getFirestore, collection, getDocs, updateDoc, doc, runTransaction } from 'firebase/firestore';
import * as dotenv from 'dotenv';
import { readFileSync } from 'fs';

dotenv.config();

const config = JSON.parse(readFileSync('./firebase-applet-config.json', 'utf8'));

const app = initializeApp(config);
const db = getFirestore(app);

async function fixRequestNumbers() {
  console.log("Starting to fix request numbers...");
  
  const borrowsSnapshot = await getDocs(collection(db, 'borrows'));
  const year = new Date().getFullYear();
  const counterRef = doc(db, 'counters', `borrow_request_${year}`);

  let count = 0;

  for (const borrowDoc of borrowsSnapshot.docs) {
    const data = borrowDoc.data();
    if (!data.requestNumber) {
      try {
        const requestNumber = await runTransaction(db, async (transaction) => {
          const counterDoc = await transaction.get(counterRef);
          let newSequence = 1;
          if (counterDoc.exists()) {
            newSequence = (counterDoc.data().sequence || 0) + 1;
            transaction.update(counterRef, { sequence: newSequence });
          } else {
            transaction.set(counterRef, { sequence: newSequence });
          }
          return `BR${year}-${String(newSequence).padStart(4, '0')}`;
        });

        await updateDoc(doc(db, 'borrows', borrowDoc.id), {
          requestNumber
        });
        console.log(`Updated ${borrowDoc.id} with ${requestNumber}`);
        count++;
      } catch (err) {
        console.error("Error updating", borrowDoc.id, err);
      }
    }
  }

  console.log(`Done. Updated ${count} records.`);
  process.exit(0);
}

fixRequestNumbers();
