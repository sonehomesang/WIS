import { initializeApp } from 'firebase/app';
import { getFirestore, collection, getDocs } from 'firebase/firestore';
import { readFileSync } from 'fs';

const fbConfig = JSON.parse(readFileSync('./firebase-applet-config.json', 'utf8'));
const app = initializeApp(fbConfig);
const db = getFirestore(app, fbConfig.firestoreDatabaseId);

async function main() {
  const usersRef = collection(db, 'users');
  const snapshot = await getDocs(usersRef);
  const emails: Record<string, any[]> = {};
  
  for (const item of snapshot.docs) {
    const data = item.data();
    console.log(`User: ${item.id} - ${data.email} - isPreCreated: ${data.isPreCreated} - status: ${data.status}`);
    if (!emails[data.email]) emails[data.email] = [];
    emails[data.email].push({ id: item.id, ...data });
  }
}
main();
