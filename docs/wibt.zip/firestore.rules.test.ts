import { initializeTestEnvironment, RulesTestEnvironment, assertFails, assertSucceeds } from '@firebase/rules-unit-testing';
import { beforeAll, afterAll, beforeEach, describe, it } from 'vitest';
import { readFileSync } from 'fs';
import { resolve } from 'path';

let testEnv: RulesTestEnvironment;

beforeAll(async () => {
  // Load rules
  const rules = readFileSync(resolve(__dirname, 'firestore.rules'), 'utf8');
  testEnv = await initializeTestEnvironment({
    projectId: 'demo-project-security-test',
    firestore: {
      rules,
    },
  });
});

afterAll(async () => {
  await testEnv.cleanup();
});

beforeEach(async () => {
  await testEnv.clearFirestore();
});

describe('Firestore Security Rules', () => {
  // 1. User Profile - Role Spoof (Update)
  it('should deny normal user from updating their role to admin', async () => {
    // Setup initial data
    await testEnv.withSecurityRulesDisabled(async (context) => {
      await context.firestore().collection('users').doc('user1').set({ email: 'user1@test.com', role: 'user' });
    });

    const user1 = testEnv.authenticatedContext('user1', { email: 'user1@test.com' });
    const user1Db = user1.firestore();

    await assertFails(user1Db.collection('users').doc('user1').update({ role: 'admin', email: 'user1@test.com' }));
  });

  // 2. User Profile - Cross-User (Update)
  it('should deny normal user from updating another user', async () => {
    await testEnv.withSecurityRulesDisabled(async (context) => {
      await context.firestore().collection('users').doc('user2').set({ email: 'user2@test.com', role: 'user' });
    });

    const user1 = testEnv.authenticatedContext('user1', { email: 'user1@test.com' });
    await assertFails(user1.firestore().collection('users').doc('user2').update({ name: 'Hacked' }));
  });

  // 3. Borrow Record - Identity Spoof (Create)
  it('should deny user creating borrow record for another user', async () => {
    const user1 = testEnv.authenticatedContext('user1', { email: 'user1@test.com' });
    await assertFails(user1.firestore().collection('borrow_records').doc('b1').set({ 
      borrowerEmail: 'user2@test.com', status: 'active', items: [], borrowDate: '2023-01-01', plannedReturnDate: '2023-01-02', periodDays: 1, borrowType: 'new_inventory' 
    }));
  });

  // 3b. Borrow Record - Update permissions
  describe('Borrow Record Updates', () => {
    beforeEach(async () => {
      await testEnv.withSecurityRulesDisabled(async (context) => {
        await context.firestore().collection('borrow_records').doc('br1').set({
          borrowerEmail: 'borrower@test.com',
          managerEmail: 'manager@test.com',
          approverEmail: 'approver@test.com',
          status: 'active',
          items: [],
          borrowDate: '2023-01-01',
          plannedReturnDate: '2023-01-02',
          periodDays: 1,
          borrowType: 'new_inventory'
        });
      });
    });

    it('should allow borrower to update', async () => {
      const db = testEnv.authenticatedContext('borrower', { email: 'borrower@test.com' }).firestore();
      await assertSucceeds(db.collection('borrow_records').doc('br1').update({ status: 'returned' }));
    });

    it('should allow manager to update', async () => {
      const db = testEnv.authenticatedContext('manager', { email: 'manager@test.com' }).firestore();
      await assertSucceeds(db.collection('borrow_records').doc('br1').update({ status: 'returned' }));
    });

    it('should allow approver to update', async () => {
      const db = testEnv.authenticatedContext('approver', { email: 'approver@test.com' }).firestore();
      await assertSucceeds(db.collection('borrow_records').doc('br1').update({ status: 'returned' }));
    });

    it('should deny arbitrary user from updating', async () => {
      const db = testEnv.authenticatedContext('random', { email: 'random@test.com' }).firestore();
      await assertFails(db.collection('borrow_records').doc('br1').update({ status: 'returned' }));
    });

    it('should deny borrower from changing borrowerEmail', async () => {
      const db = testEnv.authenticatedContext('borrower', { email: 'borrower@test.com' }).firestore();
      await assertFails(db.collection('borrow_records').doc('br1').update({ status: 'returned', borrowerEmail: 'other@test.com' }));
    });
  });

  // 4. Counters - Sequence Validation
  describe('Counters Updates (Sequence Validation)', () => {
    beforeEach(async () => {
      await testEnv.withSecurityRulesDisabled(async (context) => {
        await context.firestore().collection('counters').doc('c1').set({ sequence: 5 });
      });
    });

    it('should allow create only if sequence is 1', async () => {
      const db = testEnv.authenticatedContext('user1').firestore();
      await assertSucceeds(db.collection('counters').doc('c2').set({ sequence: 1 }));
      await assertFails(db.collection('counters').doc('c3').set({ sequence: 5 }));
    });

    it('should allow update only if sequence increments exactly by 1', async () => {
      const db = testEnv.authenticatedContext('user1').firestore();
      await assertSucceeds(db.collection('counters').doc('c1').update({ sequence: 6 }));
    });

    it('should deny update if sequence jumps by more than 1', async () => {
      const db = testEnv.authenticatedContext('user1').firestore();
      await assertFails(db.collection('counters').doc('c1').update({ sequence: 10 }));
    });
    
    it('should deny update if sequence stays the same', async () => {
      const db = testEnv.authenticatedContext('user1').firestore();
      await assertFails(db.collection('counters').doc('c1').update({ sequence: 5 }));
    });
  });

  // 5. Inventory Item - Unauth (Create)
  it('should deny normal user from creating inventory item', async () => {
    const user1 = testEnv.authenticatedContext('user1');
    await assertFails(user1.firestore().collection('inventory').doc('item1').set({ 
      id: 'item1', name: 'Item', quantity: 1, minQuantity: 0, status: 'available' 
    }));
  });

  // 5. Inventory Item - Unauth (Update)
  it('should deny normal user from updating inventory item quantity', async () => {
    await testEnv.withSecurityRulesDisabled(async (context) => {
      await context.firestore().collection('inventory').doc('item1').set({ 
        id: 'item1', name: 'Item', quantity: 5, minQuantity: 0, status: 'available' 
      });
    });

    const user1 = testEnv.authenticatedContext('user1');
    await assertFails(user1.firestore().collection('inventory').doc('item1').update({ quantity: 1 }));
  });

  // 6. Notification - Cross-User (Create)
  it('should deny user sending notification as another user (Wait, in our current rule, anyone can create notifications but let\'s verify)', async () => {
    // Current Rule: allow create: if ...
    const user1 = testEnv.authenticatedContext('user1');
    await assertFails(user1.firestore().collection('notifications').doc('notif1').set({ 
      userId: 'user2', title: 'Fake', read: false, type: 'info', message: 'test' 
    }));
  });
});
