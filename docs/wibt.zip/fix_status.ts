import { initializeApp } from 'firebase/app';
import { getFirestore, collection, getDocs, updateDoc, doc } from 'firebase/firestore';
import { readFileSync } from 'fs';

const fbConfig = JSON.parse(readFileSync('./firebase-applet-config.json', 'utf8'));
const app = initializeApp(fbConfig);
const db = getFirestore(app, fbConfig.firestoreDatabaseId);

async function main() {
  const usersRef = collection(db, 'users');
  const snapshot = await getDocs(usersRef);
  
  for (const item of snapshot.docs) {
    const data = item.data();
    
    let updates: any = {};
    if (data.status === undefined && !data.isPreCreated) {
       updates.status = 'active';
    }
    if (data.isPreCreated === undefined) {
       updates.isPreCreated = false;
    }
    
    if (Object.keys(updates).length > 0) {
       await updateDoc(doc(db, 'users', item.id), updates);
       console.log(`Updated ${data.email} with ${JSON.stringify(updates)}`);
    }
  }
}
main();
