# Setting up Super Admin

To grant super-admin access outside of the hardcoded email fallback, you must set a custom user claim on the account via the Firebase CLI or an Admin SDK script.

Run the following command using the Firebase CLI (replace `<uid>` with the user's Firebase Auth UID):

```bash
firebase auth:set-custom-user-claims <uid> '{"superAdmin": true}'
```

Once the claim is applied to the live account, you should edit `firestore.rules` to remove the fallback `khamsone.peng@gmail.com` check for better security.
