/// <reference types="vite/client" />
import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { initializeFirestore, getFirestore } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';
const firebaseConfig = {
  apiKey: "AIzaSyCf3bE1utuPUB-yHamuABhvRgpQZDXddS4",
  authDomain: "gen-lang-client-0884542009.firebaseapp.com",
  projectId: "gen-lang-client-0884542009",
  storageBucket: "gen-lang-client-0884542009.firebasestorage.app",
  messagingSenderId: "545288463274",
  appId: "1:545288463274:web:0990772cea6614559381d3",
};

const app = initializeApp(firebaseConfig);

// Connect to the 'wibt-prod' database where the data is stored
// Add experimentalForceLongPolling to handle corporate firewalls throwing "client is offline"
export const db = initializeFirestore(app, {
  experimentalForceLongPolling: true
}, 'wibt-prod');
export const auth = getAuth(app);
export const storage = getStorage(app);
