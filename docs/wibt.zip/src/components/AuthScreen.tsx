import React, { useState } from 'react';
import { signInWithEmailAndPassword, createUserWithEmailAndPassword, sendPasswordResetEmail } from 'firebase/auth';
import { auth, db } from '../firebase';
import { doc, getDoc, setDoc, query, collection, where, getDocs, deleteDoc, addDoc, serverTimestamp } from 'firebase/firestore';
import { motion, AnimatePresence } from 'motion/react';
import { LogIn, UserPlus, Loader2, AlertCircle, Eye, EyeOff } from 'lucide-react';
import { cn } from '../lib/utils';

export function AuthScreen() {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  

  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const validatePassword = (pass: string) => {
    if (pass.length < 8) return false;
    if (!/[a-z]/.test(pass)) return false;
    if (!/[A-Z]/.test(pass)) return false;
    if (!/[0-9]/.test(pass)) return false;
    if (!/[!@#$%^&*(),.?":{}|<>]/.test(pass)) return false;
    return true;
  };

  const handleForgotPassword = async () => {
    if (!email) {
      setError('Please enter your email address first to reset password.');
      return;
    }
    setIsLoading(true);
    setError('');
    try {
      await sendPasswordResetEmail(auth, email);
      alert('Password reset email sent! Please check your inbox.');
    } catch (err: any) {
      if (err.code === 'auth/invalid-credential' || err.code === 'auth/user-not-found') {
         setError('ບໍ່ພົບອີເມລນີ້ໃນລະບົບ (Email not found).');
      } else {
         setError(err.message || 'Failed to send password reset email.');
         console.error(err);
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');

    try {
      const trimmedEmail = email.trim();
      const emailLower = trimmedEmail.toLowerCase();
      if (!emailLower.endsWith('@namtheun2.com') && emailLower !== 'khamsone.peng@gmail.com') {
         throw new Error('Access is restricted to @namtheun2.com emails only.');
      }

      if (isLogin) {
        await signInWithEmailAndPassword(auth, trimmedEmail, password);
      } else {
        if (!validatePassword(password)) {
          throw new Error('Password must be at least 8 characters long and contain a lowercase letter, uppercase letter, number, and symbol.');
        }

        const userCredential = await createUserWithEmailAndPassword(auth, email, password);
        const fbUser = userCredential.user;
        
        // After creating auth account, we check if they are in "users" collection (pre-created). 
        const usersRef = collection(db, 'users');
        const q = query(usersRef, where('email', '==', email.toLowerCase()), where('isPreCreated', '==', true));
        const querySnapshot = await getDocs(q);
        
        const userData = {
            email: email.toLowerCase(),
            name: '',
            displayName: '',
            isPreCreated: false,
        };

        if (!querySnapshot.empty) {
            const oldDoc = querySnapshot.docs[0];
            const oldData = oldDoc.data();
            
            // Delete all previous records for this email (since they must be pre-created invites)
            for (const docSnapshot of querySnapshot.docs) {
               await deleteDoc(docSnapshot.ref);
            }
            
            await setDoc(doc(db, 'users', fbUser.uid), {
                ...oldData,
                ...userData,
                role: oldData.role || 'user', // preserve 'admin' or 'viewer'
                status: 'active'
            });
        } else {
            await setDoc(doc(db, 'users', fbUser.uid), {
                ...userData,
                role: 'user', // default role
                status: 'pending', // requires approval
                createdAt: new Date()
            });
            
            // Notify Admin via In-App Notification (Sent to ALL admins)
            await addDoc(collection(db, 'notifications'), {
                userId: 'admin',
                title: 'New User Registration (ມີຜູ້ໃຊ້ງານໃໝ່ສະໝັກ)',
                message: `ອີເມລ (Email): ${userData.email}\nກະລຸນາກວດສອບ ແລະ ອະນຸມັດຫຼັງຈາກຜູ້ໃຊ້ປ້ອນຂໍ້ມູນສຳເລັດ.`,
                read: false,
                createdAt: serverTimestamp(),
                type: 'info'
            });

            // Fetch adminWhatsApp from settings, default to 8562059682000
            let adminPhone = '8562059682000';
            try {
                const settingsDoc = await getDoc(doc(db, 'settings', 'workflow'));
                if (settingsDoc.exists() && settingsDoc.data().adminWhatsApp) {
                    adminPhone = settingsDoc.data().adminWhatsApp;
                }
            } catch (e) {
                console.error("Failed to fetch workflow settings", e);
            }
            const text = encodeURIComponent(`📢 ສະບາຍດີ Admin,\n\nມີຜູ້ໃຊ້ງານໃໝ່ສະໝັກເຂົ້າລະບົບ (New User Registration).\n\nອີເມລ (Email): ${userData.email}\n\nກະລຸນາລໍຖ້າຜູ້ໃຊ້ງານປ້ອນຂໍ້ມູນສ່ວນຕົວໃຫ້ຄົບກ່ອນ ຈຶ່ງສາມາດອະນຸມັດໄດ້ (Please wait for the user to complete their profile before approving).`);
            window.open(`https://wa.me/${adminPhone}?text=${text}`, '_blank');
        }
      }
    } catch (err: any) {
      if (err.code === 'auth/too-many-requests') {
         setError('ບັນຊີຖືກຈຳກັດການເຂົ້າສູ່ລະບົບຊົ່ວຄາວ ເນື່ອງຈາກໃສ່ລະຫັດຜິດຫຼາຍຄັ້ງ ກະລຸນາລໍຖ້າຄ່ອຍລອງໃໝ່. (Too many failed attempts — try again later.)');
      } else if (err.code === 'auth/email-already-in-use') {
         setError('ອີເມລນີ້ມີໃນລະບົບແລ້ວ ກະລຸນາລັອກອິນ (Email already registered, please login).');
      } else if (err.code === 'auth/weak-password') {
         setError('ລະຫັດຜ່ານອ່ອນເກີນໄປ (Password is too weak).');
      } else if (
        err.code === 'auth/invalid-credential' ||
        err.code === 'auth/invalid-login-credentials' ||
        err.code === 'auth/user-not-found' ||
        err.code === 'auth/wrong-password' ||
        err.message?.includes('invalid-credential') ||
        err.message?.includes('invalid-login-credentials')
      ) {
         setError('ອີເມລ ຫຼື ລະຫັດຜ່ານບັນຊີ ບໍ່ຖືກຕ້ອງ (Invalid email or password).');
      } else {
         setError(err.message || 'An error occurred during authentication.');
         console.error(err);
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-50 overflow-y-auto overflow-x-hidden flex items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white p-8 md:p-10 rounded-3xl shadow-xl max-w-md w-full my-auto"
      >
        <div className="text-center space-y-2 mb-8">
          <div className="w-16 h-16 bg-indigo-600 rounded-2xl flex items-center justify-center text-white text-3xl font-bold mx-auto shadow-lg shadow-indigo-200 mb-6">W</div>
          <h1 className="text-2xl pt-2 font-bold tracking-tight text-slate-900 leading-snug">
            {isLogin ? 'Welcome' : 'Create an account'}
          </h1>
          <p className="text-sm font-medium text-slate-500">
            Warehouse Inventory Borrowing and Tracking
          </p>
        </div>

        {error && (
            <div className="mb-6 p-4 rounded-xl bg-red-50 text-red-600 flex items-start gap-3 border border-red-100">
                <AlertCircle size={20} className="shrink-0 mt-0.5" />
                <p className="text-xs font-medium leading-relaxed">{error}</p>
            </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-4">
            <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">Email Address <span className="normal-case font-normal">(ອີເມລ ນໍ້າເທີນທີ່ທ່ານໃຊ້ຢູ່)</span></label>
                <input 
                    type="email" 
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 transition-all outline-none text-sm"
                    placeholder="Enter your email"
                />
            </div>



            <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">Password <span className="normal-case font-normal">(ປະກອບດ້ວຍ ອັກສອນແບບພິມໃຫຍ່, ນ້ອຍ, ສັນຍາລັກ, ໂຕເລກ ລວມ 8 ໂຕ, ຕົວຢ່າງ: Test123$)</span></label>
                <div className="relative">
                    <input 
                        type={showPassword ? "text" : "password"} 
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                        minLength={6}
                        className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 transition-all outline-none text-sm pr-12"
                        placeholder="Enter your password"
                    />
                    <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 focus:outline-none p-1 rounded-full hover:bg-slate-100 transition-colors"
                    >
                        {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                    </button>
                </div>
            </div>
          </div>

          <button 
            type="submit"
            disabled={isLoading}
            className="w-full flex items-center justify-center gap-2 bg-indigo-600 text-white p-3.5 rounded-xl hover:bg-indigo-700 transition-all font-semibold shadow-md shadow-indigo-200 mt-6 disabled:opacity-70 disabled:cursor-not-allowed"
          >
            {isLoading ? <Loader2 size={20} className="animate-spin" /> : (isLogin ? <LogIn size={20} /> : <UserPlus size={20} />)}
            {isLogin ? 'Sign In' : 'Create Account'}
          </button>
        </form>

        <div className="mt-6 text-center space-y-3">
            {isLogin && (
                <p className="text-sm">
                    <button 
                        type="button" 
                        onClick={handleForgotPassword}
                        className="font-medium text-slate-500 hover:text-indigo-600 hover:underline transition-colors"
                    >
                        Forgot your password?
                    </button>
                </p>
            )}
            <p className="text-sm text-slate-500">
                {isLogin ? "Don't have an account?" : "Already have an account?"}
                <button 
                    type="button" 
                    onClick={() => {
                        setIsLogin(!isLogin);
                        setError('');
                    }} 
                    className="ml-2 font-bold text-indigo-600 hover:text-indigo-700 hover:underline"
                >
                    {isLogin ? 'Sign up' : 'Sign in'}
                </button>
            </p>
        </div>
      </motion.div>
    </div>
  );
}
