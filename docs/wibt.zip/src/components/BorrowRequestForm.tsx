import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { X, User, Package, ArrowLeftRight, Search, Plus, Trash2, Camera, Image as ImageIcon } from 'lucide-react';
import { collection, query, where, getDocs, limit, addDoc, setDoc, serverTimestamp, doc, runTransaction } from 'firebase/firestore';
import { ref, uploadString, getDownloadURL } from 'firebase/storage';
import { db, storage } from '../firebase';
import { Unit, Department, InventoryItem, BorrowedItem, WorkflowSettings } from '../types';
import { cn } from '../lib/utils';

interface BorrowRequestFormProps {
  user: any;
  units: Unit[];
  departments: Department[];
  appUsers?: any[];
  workflowSettings: WorkflowSettings;
  onClose: () => void;
  onSuccess: () => void;
}

export function BorrowRequestForm({ user, units, departments, appUsers = [], workflowSettings, onClose, onSuccess }: BorrowRequestFormProps) {
  const [borrowType, setBorrowType] = useState<'new_inventory' | 'deposited_tools' | 'others'>('new_inventory');
  const [items, setItems] = useState<BorrowedItem[]>([{ materialId: '', materialDescription: '', borrowQty: 1, materialPhotos: [] }]);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<InventoryItem[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [activeItemIndex, setActiveItemIndex] = useState<number | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [loadingStatus, setLoadingStatus] = useState<string>('ກະ​ລຸ​ນາ​ລໍ​ຖ້າ​ບຶດ​ໜຶ່ງ (Saving your request, please wait)');
  const [submitError, setSubmitError] = useState<string | null>(null);

  const handleSearch = async (queryText: string) => {
    setSearchQuery(queryText);
    if (queryText.length < 2) {
      setSearchResults([]);
      return;
    }
    setIsSearching(true);
    try {
      // Simple prefix search on ID
      const q = query(
        collection(db, 'inventory'),
        where('id', '>=', queryText),
        where('id', '<=', queryText + '\uf8ff'),
        limit(5)
      );
      const snapshot = await getDocs(q);
      const results = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as InventoryItem));
      setSearchResults(results);
    } catch (error) {
      console.error("Search failed:", error);
    } finally {
      setIsSearching(false);
    }
  };

  const selectItem = (item: InventoryItem, index: number) => {
    const newItems = [...items];
    newItems[index] = {
      ...newItems[index],
      materialId: item.id,
      materialDescription: item.name,
      stockPhotos: item.photos || [],
    };
    setItems(newItems);
    setActiveItemIndex(null);
    setSearchQuery('');
    setSearchResults([]);
  };

  const addItem = () => {
    setItems([...items, { materialId: '', materialDescription: '', borrowQty: 1, materialPhotos: [] }]);
  };

  const removeItem = (index: number) => {
    if (items.length > 1) {
      setItems(items.filter((_, i) => i !== index));
    }
  };

  const updateItem = (index: number, field: keyof BorrowedItem, value: any) => {
    const newItems = [...items];
    newItems[index] = { ...newItems[index], [field]: value };
    setItems(newItems);
  };

  const handleImageUpload = async (index: number, e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;
    
    const remainingSlots = 2 - items[index].materialPhotos.length;
    const filesToProcess = Array.from(files).slice(0, remainingSlots);
    
    const base64Promises = filesToProcess.map((file: File) => {
      return new Promise<string>((resolve) => {
        const reader = new FileReader();
        reader.onload = (ev) => {
          const img = new Image();
          img.onload = () => {
            const canvas = document.createElement('canvas');
            let width = img.width;
            let height = img.height;
            const MAX_DIMENSION = 800;
            
            if (width > height && width > MAX_DIMENSION) {
              height *= MAX_DIMENSION / width;
              width = MAX_DIMENSION;
            } else if (height > MAX_DIMENSION) {
              width *= MAX_DIMENSION / height;
              height = MAX_DIMENSION;
            }
            
            canvas.width = width;
            canvas.height = height;
            const ctx = canvas.getContext('2d');
            if (ctx) {
              ctx.drawImage(img, 0, 0, width, height);
              resolve(canvas.toDataURL('image/jpeg', 0.8));
            } else {
              resolve(ev.target?.result as string);
            }
          };
          img.onerror = () => resolve(ev.target?.result as string);
          if (ev.target?.result) {
            img.src = ev.target.result as string;
          } else {
            resolve('');
          }
        };
        reader.readAsDataURL(file);
      });
    });
    const newPhotos = await Promise.all(base64Promises);
    updateItem(index, 'materialPhotos', [...items[index].materialPhotos, ...newPhotos]);
    e.target.value = ''; // Reset input
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!user) return;
    
    if (isSubmitting) return;
    setSubmitError(null);
    setIsSubmitting(true);
    setLoadingStatus("ກຳລັງກະກຽມຂໍ້ມູນ (Preparing data)...");

    const formData = new FormData(e.currentTarget);
    const managerId = workflowSettings.requireManagerAcknowledge ? (formData.get('manager') as string) : '';
    const approverId = workflowSettings.requireWhApprover ? (formData.get('approver') as string) : '';
    const managerUser = managerId ? appUsers.find(u => u.id === managerId) : null;
    const approverUser = approverId ? appUsers.find(u => u.id === approverId) : null;

    const sanitizedItems = items.filter(item => item.materialId || item.materialDescription).map(item => {
      const p1 = Array.isArray(item.materialPhotos) ? item.materialPhotos.filter(p => typeof p === 'string' && p.trim() !== '') : [];
      const p2 = Array.isArray(item.stockPhotos) ? item.stockPhotos.filter(p => typeof p === 'string' && p.trim() !== '') : [];
      return {
        materialId: item.materialId ? String(item.materialId) : '',
        materialDescription: item.materialDescription ? String(item.materialDescription) : '',
        borrowQty: Number(item.borrowQty) || 1,
        materialPhotos: p1,
        stockPhotos: p2
      };
    });

    try {
      const timeoutPromise = <T,>(ms: number, message: string): Promise<T> => 
        new Promise((_, reject) => setTimeout(() => reject(new Error(message)), ms));

      setLoadingStatus("ກຳລັງອັບໂຫຼດຮູບພາບ (Uploading images)...");
      const docRef = doc(collection(db, 'borrow_records'));
      const recordId = docRef.id;

      const uploadTask = Promise.all(sanitizedItems.map(async (item, itemIndex) => {
        const uploadPhotos = async (photos: string[], folder: string) => {
          return await Promise.all(photos.map(async (p, pIndex) => {
            if (p.startsWith('data:')) {
              const r = ref(storage, `borrow_records/${recordId}/${itemIndex}/${folder}_${pIndex}.jpg`);
              await uploadString(r, p, 'data_url');
              return await getDownloadURL(r);
            }
            return p;
          }));
        };

        const materialPhotos = await uploadPhotos(item.materialPhotos, 'material');
        const stockPhotos = await uploadPhotos(item.stockPhotos, 'stock');

        return { ...item, materialPhotos, stockPhotos };
      }));

      const itemsWithStorageUrls = await Promise.race([
        uploadTask,
        timeoutPromise<any>(30000, "ການອັບໂຫຼດຮູບພາບໃຊ້ເວລາດົນເກີນໄປ. ກະລຸນາກວດສອບອິນເຕີເນັດຂອງທ່ານ (Image upload timed out. Please check your internet connection).")
      ]);

      setLoadingStatus("ກຳລັງສ້າງເລກທີບິນ (Generating request number)...");
      const year = new Date().getFullYear();
      const counterRef = doc(db, 'counters', `borrow_request_${year}`);
      
      const requestNumberTask = runTransaction(db, async (transaction) => {
        const counterDoc = await transaction.get(counterRef);
        let newSequence = 1;
        if (counterDoc.exists()) {
          newSequence = (counterDoc.data().sequence || 0) + 1;
          transaction.update(counterRef, { sequence: newSequence });
        } else {
          transaction.set(counterRef, { sequence: newSequence });
        }
        return `BR${year}-${String(newSequence).padStart(4, '0')}`;
      });

      const requestNumber = await Promise.race([
        requestNumberTask,
        timeoutPromise<string>(15000, "ການດຶງເລກທີບິນໃຊ້ເວລາດົນເກີນໄປ (Getting request sequence timed out). ເຄືອຂ່າຍອາດຈະມີບັນຫາ.")
      ]);

      setLoadingStatus("ກຳລັງບັນທຶກຂໍ້ມູນເຂົ້າລະບົບ (Saving record to database)...");
      const newRequest = {
        requestNumber,
        borrowerEmail: user.email || '',
        borrowerPhone: user.phone || '',
        borrowerUnitId: user.unitId || '',
        borrowerDepartmentId: user.departmentId || '',
        borrowType: String(borrowType || ''),
        borrowTypeOthersDetail: borrowType === 'others' && formData.get('borrowTypeOthersDetail') ? String(formData.get('borrowTypeOthersDetail')) : '',
        items: itemsWithStorageUrls,
        borrowDate: new Date().toISOString(),
        purpose: formData.get('purpose') ? String(formData.get('purpose')) : '',
        periodDays: Number(formData.get('period')) || 1,
        plannedReturnDate: new Date(Date.now() + (Number(formData.get('period')) || 1) * 24 * 60 * 60 * 1000).toISOString(),
        managerAcknowledge: managerUser?.name || managerUser?.email || managerId || '',
        managerEmail: managerUser?.email || '',
        managerPhone: managerUser?.phone || '',
        whApprover: approverUser?.name || approverUser?.email || approverId || '',
        approverEmail: approverUser?.email || '',
        approverPhone: approverUser?.phone || '',
        takingConfirmation: false,
        overdueDays: 0,
        borrowerReturnAcknowledge: false,
        whReturnAcknowledge: false,
        status: 'active',
        createdAt: serverTimestamp(),
      };

      const timeoutPromiseStr = <T,>(ms: number, message: string): Promise<T> => 
        new Promise((_, reject) => setTimeout(() => reject(new Error(message)), ms));
        
      await Promise.race([
        setDoc(docRef, newRequest),
        timeoutPromiseStr<void>(15000, "ບັນທຶກຂໍ້ມູນເຂົ້າຖານຂໍ້ມູນລົ້ມເຫຼວ ເນື່ອງຈາກການເຊື່ອມຕໍ່ຊ້າ (Saving record timed out. Network might be unstable).")
      ]);
      
      setLoadingStatus("ກຳລັງສົ່ງແຈ້ງເຕືອນ (Sending notification)...");
      // Send Confirmation Message to Borrower
      const itemsList = newRequest.items.map(i => `- ${i.materialDescription} (x${i.borrowQty})`).join('\n');
      
      try {
        await Promise.race([
          addDoc(collection(db, 'notifications'), {
            userId: newRequest.borrowerEmail,
            title: 'ການຢືນຢັນການຢືມເຄຶ່ອງ / Borrowing Confirmation',
            message: `ຂໍ້ຄວາມຢືນຢັນ ການຢືມເຄື່ອງຂອງທ່ານ ບິນເລກທີ ${requestNumber} ໄດ້ຖືກບັນທຶກແລ້ວ.\n\nລາຍການເຄື່ອງທີ່ຢືມ:\n${itemsList}\n\nວັນທີຢືມ: ${new Date().toLocaleDateString()}\nຈຸດປະສົງ: ${newRequest.purpose}\n\nຖ້າທ່ານມີຂໍ້ສົງໃສ, ກະລຸນາຕິດຕໍ່ພະນັກງານສາງ.`,
            read: false,
            createdAt: serverTimestamp(),
            type: 'info',
            linkToRecordId: docRef.id
          }),
          timeoutPromiseStr<void>(10000, "ການສົ່ງແຈ້ງເຕືອນໃຊ້ເວລາດົນເກີນໄປ")
        ]);
      } catch (notifErr) {
        console.warn("Notification failed, but record is saved:", notifErr);
      }

      onSuccess();
    } catch (error: any) {
      console.error("Failed to submit request:", error);
      setSubmitError(error.message || String(error));
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={() => !isSubmitting && onClose()}
        className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm"
      />
      <motion.form 
        onSubmit={handleSubmit}
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 20 }}
        className="bg-white w-full max-w-4xl max-h-[90vh] rounded-3xl shadow-2xl overflow-hidden flex flex-col relative z-10"
      >
        {isSubmitting ? (
          <div className="flex flex-col items-center justify-center p-12 h-64 text-center">
            <div className="w-12 h-12 border-4 border-indigo-200 border-t-indigo-600 rounded-full animate-spin mb-4" />
            <h3 className="text-lg font-bold text-slate-800">{loadingStatus.split(' (')[0]}</h3>
            <p className="text-sm text-slate-500 mt-2">{loadingStatus}</p>
          </div>
        ) : (
          <>
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-white sticky top-0 z-10">
              <h2 className="text-xl font-bold">New Borrowing Request</h2>
              <button type="button" onClick={() => !isSubmitting && onClose()} disabled={isSubmitting} className="p-2 hover:bg-slate-100 rounded-full transition-colors disabled:opacity-50">
                <X size={20} />
              </button>
            </div>
        
        <div className="flex-1 overflow-y-auto p-8 custom-scrollbar space-y-10">
          {submitError && (
            <div className="bg-rose-50 text-rose-700 p-4 rounded-xl border border-rose-200 text-sm font-medium mb-4 flex flex-col gap-1">
              <span className="font-bold">ເກີດຂໍ້ຜິດພາດ (Error):</span>
              <span>{submitError}</span>
            </div>
          )}

          {/* Borrowing Type */}
          <section className="space-y-4">
            <div className="flex items-center gap-2 text-indigo-600">
              <Package size={20} />
              <h3 className="font-bold uppercase tracking-wider text-sm">Borrowing Type</h3>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <label className={cn(
                "flex items-center p-4 border rounded-xl cursor-pointer transition-all",
                borrowType === 'new_inventory' ? "border-indigo-600 bg-indigo-50" : "border-slate-200 hover:bg-slate-50"
              )}>
                <input type="radio" name="borrowType" value="new_inventory" checked={borrowType === 'new_inventory'} onChange={() => setBorrowType('new_inventory')} className="hidden" />
                <span className={cn("text-sm font-medium", borrowType === 'new_inventory' ? "text-indigo-700" : "text-slate-700")}>
                  ຢືມເຄື່ອງໃໝ່ ຢູ່ໃນ Inventory Item ໄປໃຊ້ແລ້ວ ເອົາກັບມາສົ່ງ
                </span>
              </label>
              <label className={cn(
                "flex items-center p-4 border rounded-xl cursor-pointer transition-all",
                borrowType === 'deposited_tools' ? "border-indigo-600 bg-indigo-50" : "border-slate-200 hover:bg-slate-50"
              )}>
                <input type="radio" name="borrowType" value="deposited_tools" checked={borrowType === 'deposited_tools'} onChange={() => setBorrowType('deposited_tools')} className="hidden" />
                <span className={cn("text-sm font-medium", borrowType === 'deposited_tools' ? "text-indigo-700" : "text-slate-700")}>
                  ຢືມເຄື່ອງມື, ເຄື່ອງອຸປະກອນ, ເຄື່ອງຈັກທີ່ຝາກໄວ້ ໃຊ້ແລ້ວ ເອົາກັບມາສົ່ງ
                </span>
              </label>
              <label className={cn(
                "flex items-start p-4 border rounded-xl cursor-pointer transition-all relative h-full",
                borrowType === 'others' ? "border-indigo-600 bg-indigo-50" : "border-slate-200 hover:bg-slate-50"
              )}>
                <input type="radio" name="borrowType" value="others" checked={borrowType === 'others'} onChange={() => setBorrowType('others')} className="hidden" />
                <div className="flex flex-col w-full h-full">
                  <span className={cn("text-sm font-medium", borrowType === 'others' ? "text-indigo-700" : "text-slate-700")}>
                    ອື່ນໆ
                  </span>
                  {borrowType === 'others' && (
                    <textarea 
                      name="borrowTypeOthersDetail"
                      className="w-full mt-2 bg-white border border-indigo-200 rounded-lg p-2 text-sm outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 resize-none h-16 shadow-sm"
                      placeholder="ລະບຸລາຍລະອຽດ..."
                      onClick={(e) => e.stopPropagation()}
                      required
                    />
                  )}
                </div>
              </label>
            </div>
          </section>

          {/* Material Information */}
          <section className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-indigo-600">
                <Package size={20} />
                <h3 className="font-bold uppercase tracking-wider text-sm">Material Information</h3>
              </div>
              <button type="button" onClick={addItem} className="flex items-center gap-1 text-sm font-bold text-indigo-600 hover:text-indigo-700">
                <Plus size={16} /> Add Item
              </button>
            </div>
            
            <div className="space-y-6">
              {items.map((item, index) => (
                <div key={index} className="p-4 border border-slate-200 rounded-2xl bg-slate-50/50 relative">
                  {items.length > 1 && (
                    <button type="button" onClick={() => removeItem(index)} className="absolute -top-3 -right-3 p-2 bg-white border border-slate-200 text-red-500 rounded-full hover:bg-red-50 shadow-sm transition-colors">
                      <Trash2 size={14} />
                    </button>
                  )}
                  <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
                    <div className="space-y-1 md:col-span-4 relative">
                      <label className="text-xs font-bold text-slate-500 uppercase">
                        Material ID {borrowType !== 'new_inventory' && <span className="text-[10px] text-slate-400 font-normal lowercase">(Optional)</span>}
                      </label>
                      <div className="relative">
                        <input 
                          type="text" 
                          value={item.materialId}
                          onChange={(e) => {
                            updateItem(index, 'materialId', e.target.value);
                            if (borrowType === 'new_inventory') {
                              setActiveItemIndex(index);
                              handleSearch(e.target.value);
                            }
                          }}
                          onFocus={() => { if (borrowType === 'new_inventory') setActiveItemIndex(index); }}
                          placeholder={borrowType === 'new_inventory' ? "Search or enter ID" : "Optional Material ID (Free text)"} 
                          className="w-full p-3 pl-10 bg-white border border-slate-200 rounded-xl outline-none focus:border-indigo-500 transition-all" 
                          required={borrowType === 'new_inventory'} 
                        />
                        <Search size={16} className="absolute left-3 top-3.5 text-slate-400" />
                      </div>
                      
                      {/* Search Dropdown */}
                      {activeItemIndex === index && searchQuery.length >= 2 && borrowType === 'new_inventory' && (
                        <div className="absolute top-full left-0 right-0 mt-2 bg-white border border-slate-200 rounded-xl shadow-xl z-50 overflow-hidden">
                          {isSearching ? (
                            <div className="p-4 text-center text-sm text-slate-500">Searching...</div>
                          ) : searchResults.length > 0 ? (
                            <ul className="max-h-60 overflow-y-auto">
                              {searchResults.map(result => (
                                <li 
                                  key={result.id} 
                                  onClick={() => selectItem(result, index)}
                                  className="p-3 hover:bg-slate-50 cursor-pointer border-b border-slate-100 last:border-0"
                                >
                                  <div className="font-bold text-sm text-slate-900">{result.id}</div>
                                  <div className="text-xs text-slate-500 truncate">{result.name}</div>
                                </li>
                              ))}
                            </ul>
                          ) : (
                            <div className="p-4 text-center text-sm text-slate-500">No items found</div>
                          )}
                        </div>
                      )}
                    </div>
                    <div className="space-y-1 md:col-span-6">
                      <label className="text-xs font-bold text-slate-500 uppercase">Description</label>
                      <input 
                        type="text" 
                        value={item.materialDescription}
                        onChange={(e) => updateItem(index, 'materialDescription', e.target.value)}
                        placeholder="Item description" 
                        className="w-full p-3 bg-white border border-slate-200 rounded-xl outline-none focus:border-indigo-500 transition-all" 
                        required 
                      />
                    </div>
                    <div className="space-y-1 md:col-span-2">
                      <label className="text-xs font-bold text-slate-500 uppercase">Quantity</label>
                      <input 
                        type="number" 
                        min="1"
                        value={item.borrowQty}
                        onChange={(e) => updateItem(index, 'borrowQty', Number(e.target.value))}
                        placeholder="1" 
                        className="w-full p-3 bg-white border border-slate-200 rounded-xl outline-none focus:border-indigo-500 transition-all" 
                        required 
                      />
                    </div>
                    
                    {/* Photo Upload Section */}
                    <div className="md:col-span-12 space-y-2 mt-2">
                      <label className="text-xs font-bold text-slate-500 uppercase">Photos (Max 2 images per item)</label>
                      <div className="flex flex-wrap gap-2">
                        {item.materialPhotos.map((photo, pIdx) => (
                          <div key={pIdx} className="relative w-16 h-16 rounded-xl overflow-hidden border border-slate-200">
                            <img src={photo} alt="" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                            <button 
                              type="button" 
                              onClick={() => {
                                const newPhotos = [...item.materialPhotos];
                                newPhotos.splice(pIdx, 1);
                                updateItem(index, 'materialPhotos', newPhotos);
                              }}
                              className="absolute top-0 right-0 bg-red-500 text-white w-5 h-5 flex items-center justify-center rounded-bl-xl text-xs hover:bg-red-600 transition-colors"
                            >
                              <X size={12} />
                            </button>
                          </div>
                        ))}
                        {item.materialPhotos.length < 2 && (
                          <div className="flex gap-2">
                            <label className="w-16 h-16 border-2 border-dashed border-slate-300 rounded-xl flex flex-col items-center justify-center text-slate-500 hover:text-indigo-600 hover:border-indigo-300 hover:bg-indigo-50 cursor-pointer transition-all">
                              <Camera size={20} />
                              <span className="text-[10px] font-medium mt-1">Camera</span>
                              <input 
                                type="file" 
                                accept="image/*" 
                                capture="environment"
                                multiple={false}
                                className="hidden" 
                                onChange={(e) => handleImageUpload(index, e)}
                              />
                            </label>
                            <label className="w-16 h-16 border-2 border-dashed border-slate-300 rounded-xl flex flex-col items-center justify-center text-slate-500 hover:text-indigo-600 hover:border-indigo-300 hover:bg-indigo-50 cursor-pointer transition-all">
                              <ImageIcon size={20} />
                              <span className="text-[10px] font-medium mt-1">Gallery</span>
                              <input 
                                type="file" 
                                accept="image/*" 
                                multiple 
                                className="hidden" 
                                onChange={(e) => handleImageUpload(index, e)}
                              />
                            </label>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </section>

          {/* Purposes & Approval */}
          <section className="space-y-4">
            <div className="flex items-center gap-2 text-indigo-600">
              <ArrowLeftRight size={20} />
              <h3 className="font-bold uppercase tracking-wider text-sm">Purposes & Approval</h3>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-500 uppercase">Purpose</label>
                <input name="purpose" type="text" placeholder="Reason for borrowing" className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-indigo-500 transition-all" required />
              </div>
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-500 uppercase">Period (Days)</label>
                <input name="period" type="number" placeholder="7" className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-indigo-500 transition-all" required />
              </div>
              {workflowSettings.requireManagerAcknowledge && (
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-500 uppercase">Acknowledge (Manager)</label>
                  <select name="manager" defaultValue={user?.managerId || ''} className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-indigo-500 transition-all" required>
                    <option value="">Select Manager</option>
                    {appUsers.filter((u) => u.role === 'acknowledge' || u.role === 'admin' || u.role === 'user').map(u => (
                      <option key={u.id} value={u.id}>{u.name || u.email}</option>
                    ))}
                  </select>
                </div>
              )}
              {workflowSettings.requireWhApprover && (
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-500 uppercase">WH Approver</label>
                  <select name="approver" className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-indigo-500 transition-all" required>
                    <option value="">Select Approver</option>
                    {appUsers.filter((u) => u.role === 'approver' || u.role === 'admin').map(u => (
                      <option key={u.id} value={u.id}>{u.name || u.email}</option>
                    ))}
                  </select>
                </div>
              )}
            </div>
          </section>
        </div>
        
        <div className="p-6 border-t border-slate-100 bg-slate-50 flex items-center justify-end gap-3 sticky bottom-0 z-10">
          <button type="button" onClick={onClose} disabled={isSubmitting} className="px-6 py-2.5 text-slate-600 font-bold hover:bg-slate-200 rounded-xl transition-all disabled:opacity-50">Cancel</button>
          <button type="submit" disabled={isSubmitting} className="px-8 py-2.5 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 disabled:opacity-50 transition-all shadow-lg shadow-indigo-200 inline-flex items-center gap-2">
            {isSubmitting ? (
              <>
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                ກຳລັງບັນທຶກ... (Saving...)
              </>
            ) : (
              'Submit Request'
            )}
          </button>
        </div>
          </>
        )}
      </motion.form>
    </div>
  );
}
