import React, { useState, useEffect } from 'react';
import { doc, updateDoc, getDocs, collection } from 'firebase/firestore';
import { db } from '../firebase';
import { Unit, Department } from '../types';
import { Loader2 } from 'lucide-react';

interface Props {
  userUid: string;
  userEmail: string;
  defaultName?: string;
  onComplete: () => void;
}

const MOCK_UNITS: Unit[] = [
  { id: 'HAU', name: 'Human Resource and Administration' },
  { id: 'ENG', name: 'Engineering' },
];

const MOCK_DEPARTMENTS: Department[] = [
  { id: 'FMU', name: 'FMU', unitId: 'HAU' },
  { id: 'MTN-PL', name: 'MTN-PL', unitId: 'ENG' },
  { id: 'MTN-CV', name: 'MTN-CV', unitId: 'ENG' },
  { id: 'MTN-EL', name: 'MTN-EL', unitId: 'ENG' },
  { id: 'MTN-EM', name: 'MTN-EM', unitId: 'ENG' },
  { id: 'MTN-SC', name: 'MTN-SC', unitId: 'ENG' },
  { id: 'MTN-ME', name: 'MTN-ME', unitId: 'ENG' },
  { id: 'MTN-TL', name: 'MTN-TL', unitId: 'ENG' },
  { id: 'OP-HM', name: 'OP-HM', unitId: 'ENG' },
  { id: 'OP-SCO', name: 'OP-SCO', unitId: 'ENG' },
  { id: 'OP-DW', name: 'OP-DW', unitId: 'ENG' },
];

export function ProfileCompletionScreen({ userUid, userEmail, defaultName, onComplete }: Props) {
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [phone, setPhone] = useState('');
  const [unitId, setUnitId] = useState('');
  const [departmentId, setDepartmentId] = useState('');
  
  const [units, setUnits] = useState<Unit[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    // Populate name if available
    if (defaultName && defaultName !== 'Google User' && (!firstName && !lastName)) {
      const parts = defaultName.split(' ');
      if (parts.length > 1) {
        setFirstName(parts[0]);
        setLastName(parts.slice(1).join(' '));
      } else {
        setFirstName(defaultName);
      }
    }
    
    // Fetch units and departments
    const fetchOrg = async () => {
      try {
        const uSnap = await getDocs(collection(db, 'units'));
        let finalUnits = uSnap.docs.map(d => ({ id: d.id, ...d.data() } as Unit));
        if (finalUnits.length === 0) finalUnits = MOCK_UNITS;
        setUnits(finalUnits);

        const dSnap = await getDocs(collection(db, 'departments'));
        let finalDepts = dSnap.docs.map(d => ({ id: d.id, ...d.data() } as Department));
        if (finalDepts.length === 0) finalDepts = MOCK_DEPARTMENTS;
        setDepartments(finalDepts);
      } catch (err) {
        console.error("Failed to load units/departments, using mocks", err);
        setUnits(MOCK_UNITS);
        setDepartments(MOCK_DEPARTMENTS);
      }
    };
    fetchOrg();
  }, [defaultName]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    try {
      const name = `${firstName} ${lastName}`.trim();
      await updateDoc(doc(db, 'users', userUid), {
        name,
        displayName: name,
        phone,
        unitId,
        departmentId
      });

      onComplete();
    } catch (err) {
      console.error(err);
      alert("Failed to update profile.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-50 overflow-y-auto flex items-center justify-center p-4">
      <div className="bg-white p-8 md:p-10 rounded-3xl shadow-xl max-w-md w-full my-auto">
        <div className="text-center space-y-2 mb-8">
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            Complete Your Profile
          </h1>
          <p className="text-sm text-slate-500">
            Please fill in your details to continue accessing WIBT
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">First Name</label>
              <input 
                type="text" 
                value={firstName}
                onChange={(e) => setFirstName(e.target.value)}
                required
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 transition-all outline-none text-sm"
                placeholder="First Name"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">Family Name</label>
              <input 
                type="text" 
                value={lastName}
                onChange={(e) => setLastName(e.target.value)}
                required
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 transition-all outline-none text-sm"
                placeholder="Last Name"
              />
            </div>
          </div>

          <div>
             <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">Mobile Phone (WhatsApp)</label>
             <input 
                type="text" 
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                required
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 transition-all outline-none text-sm"
                placeholder="Ex: 59682000 or 020..."
             />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">Unit</label>
              <select 
                value={unitId}
                onChange={(e) => setUnitId(e.target.value)}
                required
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-indigo-500 transition-all outline-none text-sm"
              >
                <option value="">Select Unit</option>
                {units.map((u) => (
                  <option key={u.id} value={u.id}>{u.name}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">Department</label>
              <select 
                value={departmentId}
                onChange={(e) => setDepartmentId(e.target.value)}
                required
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-indigo-500 transition-all outline-none text-sm"
              >
                <option value="">Select Department</option>
                {departments.map((d) => (
                  <option key={d.id} value={d.id}>{d.name}</option>
                ))}
              </select>
            </div>
          </div>

          <button 
            type="submit"
            disabled={isLoading}
            className="w-full flex items-center justify-center gap-2 bg-indigo-600 text-white p-3.5 rounded-xl hover:bg-indigo-700 transition-all font-semibold shadow-md shadow-indigo-200 mt-6 disabled:opacity-70 disabled:cursor-not-allowed"
          >
            {isLoading ? <Loader2 size={20} className="animate-spin" /> : null}
            Complete Registration
          </button>
        </form>
      </div>
    </div>
  );
}
