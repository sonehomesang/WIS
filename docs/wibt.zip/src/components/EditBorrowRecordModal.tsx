import React, { useState, useRef } from 'react';
import { BorrowRecord, BorrowedItem } from '../types';
import { updateDoc, doc, collection, addDoc } from 'firebase/firestore';
import { db, storage } from '../firebase';
import { X, Trash2, Camera, User, Package, CalendarClock, Settings2 } from 'lucide-react';
import { ref, uploadString, getDownloadURL } from 'firebase/storage';

export function EditBorrowRecordModal({
  record,
  onClose,
  onUpdate,
  currentUserEmail
}: {
  record: BorrowRecord;
  onClose: () => void;
  onUpdate: () => void;
  currentUserEmail?: string;
}) {
  const [formData, setFormData] = useState<BorrowRecord>({
    ...record,
    borrowerEmail: record.borrowerEmail || '',
    borrowerPhone: record.borrowerPhone || '',
    borrowerUnitId: record.borrowerUnitId || '',
    borrowerDepartmentId: record.borrowerDepartmentId || '',
    borrowType: record.borrowType || 'others',
    purpose: record.purpose || '',
    periodDays: record.periodDays || 0,
    plannedReturnDate: record.plannedReturnDate || '',
    status: record.status || 'active',
    borrowDate: record.borrowDate || '',
    finalReturnDate: record.finalReturnDate || '',
    returnQty: record.returnQty || 0,
    condition: record.condition || '',
    returnRemarks: record.returnRemarks || '',
    additionalInfo: record.additionalInfo || '',
    items: record.items || [],
    returnPhotos: record.returnPhotos || []
  });

  const [saving, setSaving] = useState(false);
  const [activeTab, setActiveTab] = useState<'info' | 'items' | 'status' | 'advanced'>('info');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const uploadPhotos = async (photos: string[] | undefined, pathPrefix: string) => {
        if (!photos) return [];
        return await Promise.all(photos.map(async (p, i) => {
          if (p.startsWith('data:')) {
            const r = ref(storage, `${pathPrefix}_${Date.now()}_${i}.jpg`);
            await uploadString(r, p, 'data_url');
            return await getDownloadURL(r);
          }
          return p;
        }));
      };

      const newReturnPhotos = await uploadPhotos(formData.returnPhotos, `borrow_records/${record.id}/admin_edit_return`);
      
      const newItems = await Promise.all(formData.items.map(async (item, idx) => {
        const itemPhotos = await uploadPhotos(item.materialPhotos, `borrow_records/${record.id}/admin_edit_item_${idx}`);
        return { ...item, materialPhotos: itemPhotos };
      }));

      const finalDataToSave = {
        ...formData,
        returnPhotos: newReturnPhotos,
        items: newItems
      };

      await updateDoc(doc(db, 'borrow_records', record.id), finalDataToSave);
      
      if (currentUserEmail) {
        await addDoc(collection(db, 'activity_logs'), {
          action: 'admin_edit_record',
          user: currentUserEmail,
          timestamp: new Date().toISOString(),
          details: `Admin edited borrowing record ${record.requestNumber || record.id}.`
        });
      }
      
      onUpdate();
      onClose();
    } catch (err: any) {
      console.error(err);
      alert('Failed to update record: ' + err.message);
    } finally {
      setSaving(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    if (type === 'checkbox') {
      const checked = (e.target as HTMLInputElement).checked;
      setFormData(prev => ({ ...prev, [name]: checked }));
    } else if (type === 'number') {
      setFormData(prev => ({ ...prev, [name]: Number(value) }));
    } else {
      setFormData(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleReturnPhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const remainingSlots = 3 - (formData.returnPhotos?.length || 0);
      const filesToProcess = Array.from(e.target.files).slice(0, remainingSlots) as File[];
      
      filesToProcess.forEach(file => {
        const reader = new FileReader();
        reader.onloadend = () => {
          setFormData(prev => ({
            ...prev,
            returnPhotos: [...(prev.returnPhotos || []), reader.result as string]
          }));
        };
        reader.readAsDataURL(file);
      });
    }
  };

  const handleRemoveReturnPhoto = (index: number) => {
    setFormData(prev => {
      const newPhotos = [...(prev.returnPhotos || [])];
      newPhotos.splice(index, 1);
      return { ...prev, returnPhotos: newPhotos };
    });
  };

  const handleItemPhotoUpload = (itemIndex: number, e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const item = formData.items[itemIndex];
      const remainingSlots = 3 - (item.materialPhotos?.length || 0);
      const filesToProcess = Array.from(e.target.files).slice(0, remainingSlots) as File[];
      
      filesToProcess.forEach(file => {
        const reader = new FileReader();
        reader.onloadend = () => {
          setFormData(prev => {
            const newItems = [...prev.items];
            newItems[itemIndex] = {
              ...newItems[itemIndex],
              materialPhotos: [...(newItems[itemIndex].materialPhotos || []), reader.result as string]
            };
            return { ...prev, items: newItems };
          });
        };
        reader.readAsDataURL(file);
      });
    }
  };

  const handleRemoveItemPhoto = (itemIndex: number, photoIndex: number) => {
    setFormData(prev => {
      const newItems = [...prev.items];
      const newPhotos = [...(newItems[itemIndex].materialPhotos || [])];
      newPhotos.splice(photoIndex, 1);
      newItems[itemIndex] = { ...newItems[itemIndex], materialPhotos: newPhotos };
      return { ...prev, items: newItems };
    });
  };

  const fileInputRef = useRef<HTMLInputElement>(null);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm" onClick={onClose} />
      <div className="bg-white rounded-3xl w-full max-w-2xl max-h-[90vh] overflow-hidden flex flex-col relative z-10 shadow-xl">
        <div className="flex items-center justify-between p-6 border-b border-slate-100 shrink-0">
          <h2 className="text-xl font-bold">Edit Borrowing Record</h2>
          <button onClick={onClose} className="p-2 hover:bg-slate-100 rounded-full shrink-0">
            <X size={20} />
          </button>
        </div>
        <div className="p-0 border-b border-slate-100 flex overflow-x-auto custom-scrollbar shrink-0">
          <button onClick={() => setActiveTab('info')} className={`px-6 py-4 text-sm font-bold border-b-2 whitespace-nowrap ${activeTab === 'info' ? 'border-indigo-600 text-indigo-600' : 'border-transparent text-slate-500 hover:text-slate-700 hover:bg-slate-50'}`}>Basic Info</button>
          <button onClick={() => setActiveTab('items')} className={`px-6 py-4 text-sm font-bold border-b-2 whitespace-nowrap ${activeTab === 'items' ? 'border-indigo-600 text-indigo-600' : 'border-transparent text-slate-500 hover:text-slate-700 hover:bg-slate-50'}`}>Items & Photos</button>
          <button onClick={() => setActiveTab('status')} className={`px-6 py-4 text-sm font-bold border-b-2 whitespace-nowrap ${activeTab === 'status' ? 'border-indigo-600 text-indigo-600' : 'border-transparent text-slate-500 hover:text-slate-700 hover:bg-slate-50'}`}>Status & Returns</button>
          <button onClick={() => setActiveTab('advanced')} className={`px-6 py-4 text-sm font-bold border-b-2 whitespace-nowrap ${activeTab === 'advanced' ? 'border-indigo-600 text-indigo-600' : 'border-transparent text-slate-500 hover:text-slate-700 hover:bg-slate-50'}`}>Advanced</button>
        </div>
        <div className="p-6 overflow-y-auto custom-scrollbar flex-1 bg-slate-50/50">
          <form id="edit-record-form" onSubmit={handleSubmit} className="space-y-6">
            
            {activeTab === 'info' && (
              <div className="space-y-6">
                <div className="bg-white p-5 rounded-2xl border border-slate-200">
                  <h3 className="font-bold text-slate-800 mb-4 flex items-center gap-2"><User size={16} className="text-indigo-500"/> User Information</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Borrower Email</label>
                      <input name="borrowerEmail" value={formData.borrowerEmail || ''} onChange={handleChange} className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:border-indigo-500 outline-none text-sm" />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Borrower Phone</label>
                      <input name="borrowerPhone" value={formData.borrowerPhone || ''} onChange={handleChange} className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:border-indigo-500 outline-none text-sm" />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Unit ID</label>
                      <input name="borrowerUnitId" value={formData.borrowerUnitId || ''} onChange={handleChange} className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:border-indigo-500 outline-none text-sm" />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Dept ID</label>
                      <input name="borrowerDepartmentId" value={formData.borrowerDepartmentId || ''} onChange={handleChange} className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:border-indigo-500 outline-none text-sm" />
                    </div>
                  </div>
                </div>

                <div className="bg-white p-5 rounded-2xl border border-slate-200">
                  <h3 className="font-bold text-slate-800 mb-4 flex items-center gap-2"><CalendarClock size={16} className="text-indigo-500"/> Borrowing Details</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Borrow Type</label>
                      <select name="borrowType" value={formData.borrowType || ''} onChange={handleChange} className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:border-indigo-500 outline-none text-sm">
                        <option value="new_inventory">New Inventory</option>
                        <option value="deposited_tools">Deposited Tools</option>
                        <option value="others">Others</option>
                      </select>
                    </div>
                    {formData.borrowType === 'others' ? (
                      <div>
                        <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Borrow Type Detail (Others)</label>
                        <input name="borrowTypeOthersDetail" value={formData.borrowTypeOthersDetail || ''} onChange={handleChange} className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:border-indigo-500 outline-none text-sm" />
                      </div>
                    ) : <div />}
                    <div>
                      <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Borrow Date</label>
                      <input type="text" name="borrowDate" value={formData.borrowDate || ''} onChange={handleChange} className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:border-indigo-500 outline-none text-sm" />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Planned Return Date</label>
                      <input type="text" name="plannedReturnDate" value={formData.plannedReturnDate || ''} onChange={handleChange} className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:border-indigo-500 outline-none text-sm" />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Period Days</label>
                      <input type="number" name="periodDays" value={formData.periodDays || ''} onChange={handleChange} className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:border-indigo-500 outline-none text-sm" />
                    </div>
                    <div className="col-span-2">
                      <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Purpose</label>
                      <textarea name="purpose" value={formData.purpose || ''} onChange={handleChange} className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:border-indigo-500 outline-none text-sm" rows={2} />
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'items' && (
              <div className="space-y-4">
                {formData.items.map((item, idx) => (
                  <div key={idx} className="bg-white p-5 rounded-2xl border border-slate-200">
                    <h3 className="font-bold text-slate-800 mb-4 flex items-center gap-2"><Package size={16} className="text-indigo-500"/> Item #{idx + 1}</h3>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Material ID</label>
                        <input 
                          type="text" 
                          value={item.materialId}
                          onChange={e => {
                            const newItems = [...formData.items];
                            newItems[idx].materialId = e.target.value;
                            setFormData({...formData, items: newItems});
                          }}
                          className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg text-sm outline-none"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Borrow Qty</label>
                        <input 
                          type="number" 
                          value={item.borrowQty}
                          onChange={e => {
                            const newItems = [...formData.items];
                            newItems[idx].borrowQty = Number(e.target.value);
                            setFormData({...formData, items: newItems});
                          }}
                          className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg text-sm outline-none"
                        />
                      </div>
                      <div className="sm:col-span-2">
                        <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Material Description</label>
                        <textarea 
                          value={item.materialDescription}
                          onChange={e => {
                            const newItems = [...formData.items];
                            newItems[idx].materialDescription = e.target.value;
                            setFormData({...formData, items: newItems});
                          }}
                          className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg text-sm outline-none" rows={2}
                        />
                      </div>
                      <div className="sm:col-span-2">
                        <label className="block text-[10px] font-bold text-slate-500 uppercase mb-2">Item Photos</label>
                        <input 
                          type="file" 
                          id={`item-photo-${idx}`}
                          className="hidden" 
                          accept="image/*" 
                          multiple 
                          onChange={(e) => handleItemPhotoUpload(idx, e)}
                        />
                        <div className="flex flex-wrap gap-3">
                          {(item.materialPhotos || []).map((photo, pIdx) => (
                            <div key={pIdx} className="relative w-24 h-24 rounded-xl border border-slate-200 overflow-hidden group">
                              <img src={photo} alt="" className="w-full h-full object-cover" />
                              <button type="button" onClick={() => handleRemoveItemPhoto(idx, pIdx)} className="absolute top-1 right-1 p-1.5 bg-white/90 hover:bg-red-50 text-red-600 rounded-lg shadow opacity-0 group-hover:opacity-100 transition-opacity">
                                <Trash2 size={14} />
                              </button>
                            </div>
                          ))}
                          {(!item.materialPhotos || item.materialPhotos.length < 3) && (
                            <button type="button" onClick={() => document.getElementById(`item-photo-${idx}`)?.click()} className="w-24 h-24 rounded-xl border-2 border-dashed border-slate-300 hover:border-indigo-500 hover:bg-indigo-50 flex flex-col items-center justify-center text-slate-400 hover:text-indigo-600 transition-colors">
                              <Camera size={20} />
                              <span className="text-[10px] font-bold mt-1">Add Photo</span>
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {activeTab === 'status' && (
              <div className="space-y-6">
                <div className="bg-white p-5 rounded-2xl border border-slate-200">
                  <h3 className="font-bold text-slate-800 mb-4 flex items-center gap-2"><Settings2 size={16} className="text-indigo-500"/> Current Status</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Status</label>
                      <select name="status" value={formData.status || ''} onChange={handleChange} className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:border-indigo-500 outline-none text-sm">
                        <option value="pending_approval">Pending Approval</option>
                        <option value="active">Active (In Use)</option>
                        <option value="overdue">Overdue</option>
                        <option value="returned">Returned</option>
                        <option value="deactivated">Deactivated</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Overdue Days</label>
                      <input type="number" name="overdueDays" value={formData.overdueDays || 0} onChange={handleChange} className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:border-indigo-500 outline-none text-sm" />
                    </div>
                  </div>
                </div>

                <div className="bg-white p-5 rounded-2xl border border-slate-200">
                  <h3 className="font-bold text-slate-800 mb-4">Return Details</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Final Return Date</label>
                      <input type="text" name="finalReturnDate" value={formData.finalReturnDate || ''} onChange={handleChange} className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:border-indigo-500 outline-none text-sm" />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Return Qty</label>
                      <input type="number" name="returnQty" value={formData.returnQty || ''} onChange={handleChange} className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:border-indigo-500 outline-none text-sm" />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Condition</label>
                      <select name="condition" value={formData.condition || ''} onChange={handleChange} className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:border-indigo-500 outline-none text-sm">
                        <option value="">-</option>
                        <option value="Good">Good</option>
                        <option value="Damaged">Damaged</option>
                        <option value="Lost">Lost</option>
                      </select>
                    </div>
                    <div className="col-span-2">
                      <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Return Remarks</label>
                      <input name="returnRemarks" value={formData.returnRemarks || ''} onChange={handleChange} className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:border-indigo-500 outline-none text-sm" />
                    </div>

                    <div className="col-span-2 mt-4">
                      <label className="block text-[10px] font-bold text-slate-500 uppercase mb-2">Return Photos</label>
                      <input 
                        type="file" 
                        id={`return-photo-upload`}
                        className="hidden" 
                        accept="image/*" 
                        multiple 
                        onChange={handleReturnPhotoUpload}
                      />
                      <div className="flex flex-wrap gap-3">
                        {(formData.returnPhotos || []).map((photo, pIdx) => (
                          <div key={pIdx} className="relative w-24 h-24 rounded-xl border border-slate-200 overflow-hidden group">
                            <img src={photo} alt="" className="w-full h-full object-cover" />
                            <button type="button" onClick={() => handleRemoveReturnPhoto(pIdx)} className="absolute top-1 right-1 p-1.5 bg-white/90 hover:bg-red-50 text-red-600 rounded-lg shadow opacity-0 group-hover:opacity-100 transition-opacity">
                              <Trash2 size={14} />
                            </button>
                          </div>
                        ))}
                        {(!formData.returnPhotos || formData.returnPhotos.length < 3) && (
                          <button type="button" onClick={() => document.getElementById('return-photo-upload')?.click()} className="w-24 h-24 rounded-xl border-2 border-dashed border-slate-300 hover:border-indigo-500 hover:bg-indigo-50 flex flex-col items-center justify-center text-slate-400 hover:text-indigo-600 transition-colors">
                            <Camera size={20} />
                            <span className="text-[10px] font-bold mt-1">Add Photo</span>
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'advanced' && (
              <div className="space-y-6">
                <div className="bg-white p-5 rounded-2xl border border-slate-200">
                  <h3 className="font-bold text-slate-800 mb-4">Acknowledgments & Approvals</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Manager Acknowledge</label>
                      <input name="managerAcknowledge" value={formData.managerAcknowledge || ''} onChange={handleChange} className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:border-indigo-500 outline-none text-sm" />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-500 uppercase mb-1">WH Approver</label>
                      <input name="whApprover" value={formData.whApprover || ''} onChange={handleChange} className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:border-indigo-500 outline-none text-sm" />
                    </div>
                    <div className="col-span-2">
                       <label className="flex items-center gap-2 p-3 bg-slate-50 rounded-xl border border-slate-200 cursor-pointer">
                          <input type="checkbox" name="takingConfirmation" checked={formData.takingConfirmation || false} onChange={handleChange} className="w-4 h-4 text-indigo-600" />
                          <span className="text-sm font-bold text-slate-700">Taking Confirmation (User took items)</span>
                       </label>
                    </div>
                    <div className="col-span-2">
                       <label className="flex items-center gap-2 p-3 bg-slate-50 rounded-xl border border-slate-200 cursor-pointer">
                          <input type="checkbox" name="borrowerReturnAcknowledge" checked={formData.borrowerReturnAcknowledge || false} onChange={handleChange} className="w-4 h-4 text-indigo-600" />
                          <span className="text-sm font-bold text-slate-700">Borrower Return Acknowledge (User sent return)</span>
                       </label>
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Borrower Return Date</label>
                      <input type="text" name="borrowerReturnDate" value={formData.borrowerReturnDate || ''} onChange={handleChange} className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:border-indigo-500 outline-none text-sm" />
                    </div>
                    <div className="col-span-2 mt-2">
                       <label className="flex items-center gap-2 p-3 bg-slate-50 rounded-xl border border-slate-200 cursor-pointer">
                          <input type="checkbox" name="whReturnAcknowledge" checked={formData.whReturnAcknowledge || false} onChange={handleChange} className="w-4 h-4 text-indigo-600" />
                          <span className="text-sm font-bold text-slate-700">WH Return Acknowledge (Admin accepted return)</span>
                       </label>
                    </div>
                  </div>
                </div>

                <div className="bg-white p-5 rounded-2xl border border-slate-200">
                  <h3 className="font-bold text-slate-800 mb-4">Extensions & Tracking</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Extension Status</label>
                      <select name="extensionStatus" value={formData.extensionStatus || ''} onChange={handleChange} className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:border-indigo-500 outline-none text-sm">
                        <option value="">None</option>
                        <option value="pending">Pending</option>
                        <option value="approved">Approved</option>
                        <option value="rejected">Rejected</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Extension Date</label>
                      <input type="text" name="extensionDate" value={formData.extensionDate || ''} onChange={handleChange} className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:border-indigo-500 outline-none text-sm" />
                    </div>
                    <div className="col-span-2">
                      <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Extension Request</label>
                      <textarea name="extensionRequest" value={formData.extensionRequest || ''} onChange={handleChange} className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:border-indigo-500 outline-none text-sm" rows={2} />
                    </div>
                    <div className="col-span-2">
                      <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Reminding Message</label>
                      <textarea name="remindingMessage" value={formData.remindingMessage || ''} onChange={handleChange} className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:border-indigo-500 outline-none text-sm" rows={2} />
                    </div>
                  </div>
                </div>

                <div className="bg-white p-5 rounded-2xl border border-slate-200">
                  <h3 className="font-bold text-slate-800 mb-4">Admin Notes</h3>
                  <div className="grid grid-cols-1 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Additional Information (Admin Notes)</label>
                      <textarea name="additionalInfo" value={formData.additionalInfo || ''} onChange={handleChange} placeholder="Add any notes, logs, or extra info..." className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:border-indigo-500 outline-none text-sm" rows={3}></textarea>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </form>
        </div>
        <div className="p-6 border-t border-slate-100 bg-slate-50 flex justify-end gap-3">
          <button type="button" onClick={onClose} className="px-6 py-2.5 text-sm font-bold text-slate-600 hover:bg-slate-200 bg-slate-100 rounded-xl transition-colors">
            Cancel
          </button>
          <button disabled={saving} form="edit-record-form" type="submit" className="px-6 py-2.5 text-sm font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl transition-colors flex items-center">
            {saving ? 'Saving...' : 'Save Changes'}
          </button>
        </div>
      </div>
    </div>
  );
}
