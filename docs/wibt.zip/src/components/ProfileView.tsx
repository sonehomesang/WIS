import React, { useState } from 'react';
import { User as UserIcon, Mail, Phone, Building, Briefcase, Camera, Package, AlertTriangle, CheckCircle2, LogOut, Image as ImageIcon, Calendar } from 'lucide-react';
import { updateDoc, doc } from 'firebase/firestore';
import { ref, uploadString, getDownloadURL } from 'firebase/storage';
import { db, storage } from '../firebase';
import { Unit, Department, BorrowRecord } from '../types';
import { format, parseISO } from 'date-fns';
import { cn } from '../lib/utils';

export function ProfileView({ userDoc, user, units, departments, userBorrows = [], appUsers = [], onLogout }: { userDoc: any, user: any, units: Unit[], departments: Department[], userBorrows?: BorrowRecord[], appUsers?: any[], onLogout?: () => void }) {
  const [isEditing, setIsEditing] = useState(false);
  const [name, setName] = useState(userDoc?.name || userDoc?.displayName || '');
  const [phone, setPhone] = useState(userDoc?.phone || '');
  const [unitId, setUnitId] = useState(userDoc?.unitId || '');
  const [departmentId, setDepartmentId] = useState(userDoc?.departmentId || '');
  const [managerId, setManagerId] = useState(userDoc?.managerId || '');
  const [avatar, setAvatar] = useState(userDoc?.photoURL || user?.photoURL || '');
  const [isLoading, setIsLoading] = useState(false);

  const handleSave = async () => {
    if (!user) return;
    setIsLoading(true);
    try {
      let finalAvatarUrl = avatar;
      if (avatar.startsWith('data:')) {
        const avatarRef = ref(storage, `users/${user.uid}/avatar.jpg`);
        await uploadString(avatarRef, avatar, 'data_url');
        finalAvatarUrl = await getDownloadURL(avatarRef);
      }

      await updateDoc(doc(db, 'users', user.uid), {
        name,
        phone,
        unitId,
        departmentId,
        managerId,
        photoURL: finalAvatarUrl
      });
      setIsEditing(false);
    } catch (error) {
      console.error("Error updating profile:", error);
      alert("Failed to update profile.");
    } finally {
      setIsLoading(false);
    }
  };

  const unitName = units.find(u => u.id === (isEditing ? unitId : userDoc?.unitId))?.name || 'Unknown Unit';
  const deptName = departments.find(d => d.id === (isEditing ? departmentId : userDoc?.departmentId))?.name || 'Unknown Department';

  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;
  const totalPages = Math.ceil(userBorrows.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const currentBorrows = userBorrows.slice(startIndex, startIndex + itemsPerPage);

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = (event) => {
      if (event.target?.result) {
        const img = new globalThis.Image();
        img.onload = () => {
          const canvas = document.createElement('canvas');
          let width = img.width;
          let height = img.height;
          const MAX_DIMENSION = 800;
          
          if (width > height && width > MAX_DIMENSION) {
            height *= MAX_DIMENSION / width;
            width = MAX_DIMENSION;
          } else if (height > MAX_DIMENSION) {
            width *= MAX_DIMENSION / height;
            height = MAX_DIMENSION;
          }
          
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          if (ctx) {
            ctx.drawImage(img, 0, 0, width, height);
            setAvatar(canvas.toDataURL('image/jpeg', 0.8));
          } else {
            setAvatar(event.target?.result as string);
          }
        };
        img.src = event.target.result as string;
      }
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div className="bg-white rounded-3xl p-8 border border-slate-200 shadow-sm relative overflow-hidden">
        <div className="absolute top-0 left-0 right-0 h-32 bg-gradient-to-r from-indigo-500 to-purple-600"></div>
        
        <div className="relative pt-16 flex flex-col sm:flex-row items-center sm:items-end gap-6">
          <div className="relative group">
            <div className="w-32 h-32 rounded-full overflow-hidden border-4 border-white bg-slate-100 shadow-md">
              {avatar ? (
                <img src={avatar} alt="Profile" className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-slate-400 bg-slate-100">
                  <UserIcon size={48} />
                </div>
              )}
            </div>
            {isEditing && (
              <div className="absolute -bottom-2 -right-12 flex items-center gap-1 bg-white p-1 rounded-full shadow-md border border-slate-200">
                <label className="bg-indigo-50 text-indigo-600 p-2 rounded-full cursor-pointer hover:bg-indigo-100 transition-colors" title="Take Photo">
                  <Camera size={16} />
                  <input type="file" accept="image/*" capture="user" className="hidden" onChange={handlePhotoUpload} />
                </label>
                <label className="bg-indigo-50 text-indigo-600 p-2 rounded-full cursor-pointer hover:bg-indigo-100 transition-colors" title="Upload Image">
                  <ImageIcon size={16} />
                  <input type="file" accept="image/*" className="hidden" onChange={handlePhotoUpload} />
                </label>
              </div>
            )}
          </div>
          
          <div className="flex-1 text-center sm:text-left mb-2">
            {isEditing ? (
              <input 
                type="text" 
                value={name}
                onChange={e => setName(e.target.value)}
                className="text-2xl font-bold text-slate-900 border-b-2 border-indigo-500 outline-none bg-transparent w-full sm:w-auto text-center sm:text-left"
                placeholder="Full Name"
              />
            ) : (
              <h2 className="text-3xl font-bold text-slate-900">
                {(() => {
                  const fullName = userDoc?.name || userDoc?.displayName || 'Unknown User';
                  if (fullName === 'Unknown User') return fullName;
                  const parts = fullName.trim().split(/\s+/);
                  if (parts.length > 1) {
                    return `${parts[0]} ${parts[parts.length - 1][0]}.`;
                  }
                  return fullName;
                })()}
              </h2>
            )}
            <p className="text-slate-500 font-medium">{userDoc?.role === 'admin' ? 'Administrator' : 'Standard User'}</p>
          </div>
          
          <div className="mb-2">
             {!isEditing ? (
               <button onClick={() => setIsEditing(true)} className="px-6 py-2 bg-slate-100 text-slate-700 font-bold rounded-xl hover:bg-slate-200 transition-colors">
                 Edit Profile
               </button>
             ) : (
               <div className="flex gap-2">
                 <button onClick={() => setIsEditing(false)} className="px-4 py-2 bg-slate-100 text-slate-700 font-bold rounded-xl hover:bg-slate-200 transition-colors">
                   Cancel
                 </button>
                 <button onClick={handleSave} disabled={isLoading} className="px-6 py-2 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 transition-colors disabled:opacity-50">
                   {isLoading ? 'Saving...' : 'Save'}
                 </button>
               </div>
             )}
          </div>
        </div>

        <div className="mt-12 grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
             <div className="flex items-center gap-4 text-slate-700 bg-slate-50 p-4 rounded-2xl">
               <div className="bg-white p-2 rounded-xl shadow-sm text-indigo-500"><Mail size={20} /></div>
               <div className="flex-1">
                 <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Email Address</p>
                 <p className="font-medium truncate">{user?.email}</p>
               </div>
             </div>
             
             <div className="flex items-center gap-4 text-slate-700 bg-slate-50 p-4 rounded-2xl">
               <div className="bg-white p-2 rounded-xl shadow-sm text-indigo-500"><Phone size={20} /></div>
               <div className="flex-1">
                 <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Phone (WhatsApp)</p>
                 {isEditing ? (
                   <input type="tel" value={phone} onChange={e => setPhone(e.target.value)} className="w-full bg-transparent outline-none font-medium text-slate-900 border-b border-indigo-200 focus:border-indigo-500" placeholder="Ex: 59682..." />
                 ) : (
                   <p className="font-medium">{userDoc?.phone || 'Not set'}</p>
                 )}
               </div>
             </div>
          </div>
          
          <div className="space-y-4">
             <div className="flex items-center gap-4 text-slate-700 bg-slate-50 p-4 rounded-2xl">
               <div className="bg-white p-2 rounded-xl shadow-sm text-indigo-500"><Building size={20} /></div>
               <div className="flex-1">
                 <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Unit</p>
                 {isEditing ? (
                   <select value={unitId} onChange={e => setUnitId(e.target.value)} className="w-full bg-transparent outline-none font-medium text-slate-900 border-b border-indigo-200 focus:border-indigo-500">
                     <option value="">Select Unit</option>
                     {units.map(u => <option key={u.id} value={u.id}>{u.name}</option>)}
                   </select>
                 ) : (
                   <p className="font-medium">{userDoc?.unitId ? unitName : 'Not set'}</p>
                 )}
               </div>
             </div>
             
             <div className="flex items-center gap-4 text-slate-700 bg-slate-50 p-4 rounded-2xl">
               <div className="bg-white p-2 rounded-xl shadow-sm text-indigo-500"><Briefcase size={20} /></div>
               <div className="flex-1">
                 <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Department</p>
                 {isEditing ? (
                   <select value={departmentId} onChange={e => setDepartmentId(e.target.value)} className="w-full bg-transparent outline-none font-medium text-slate-900 border-b border-indigo-200 focus:border-indigo-500">
                     <option value="">Select Department</option>
                     {departments.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
                   </select>
                 ) : (
                   <p className="font-medium">{userDoc?.departmentId ? deptName : 'Not set'}</p>
                 )}
               </div>
             </div>

             <div className="flex items-center gap-4 text-slate-700 bg-slate-50 p-4 rounded-2xl">
               <div className="bg-white p-2 rounded-xl shadow-sm text-emerald-500"><UserIcon size={20} /></div>
               <div className="flex-1">
                 <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Line Manager / Approver</p>
                 {isEditing ? (
                   <select value={managerId} onChange={e => setManagerId(e.target.value)} className="w-full bg-transparent outline-none font-medium text-slate-900 border-b border-indigo-200 focus:border-indigo-500">
                     <option value="">Select Manager</option>
                     {appUsers.filter((u) => u.role === 'acknowledge' || u.role === 'admin' || u.role === 'user').map(u => (
                       <option key={u.id} value={u.id}>{u.name || u.email}</option>
                     ))}
                   </select>
                 ) : (
                   <p className="font-medium">{userDoc?.managerId ? (appUsers.find(u => u.id === userDoc.managerId)?.name || 'Unknown') : 'Not set'}</p>
                 )}
               </div>
             </div>
          </div>
        </div>
      </div>

      {onLogout && (
        <div className="md:hidden mt-8 mb-12">
          <button 
            onClick={onLogout}
            className="w-full flex items-center justify-center gap-2 bg-red-50 text-red-600 p-4 rounded-2xl hover:bg-red-100 transition-all font-bold"
          >
            <LogOut size={20} />
            Sign Out
          </button>
        </div>
      )}
    </div>
  );
}
