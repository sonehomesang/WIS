import React, { useState, useEffect } from 'react';
import { collection, query, orderBy, onSnapshot, limit, doc, setDoc, deleteDoc } from 'firebase/firestore';
import { db } from '../firebase';
import { format } from 'date-fns';
import { Trash2, AlertCircle, RotateCcw } from 'lucide-react';

interface DeletedLog {
  id: string;
  type: string;
  recordId: string;
  deletedBy: string;
  reason: string;
  deletedAt: any;
  originalData?: any;
}

export function DeletedLogsView() {
  const [logs, setLogs] = useState<DeletedLog[]>([]);
  const [loading, setLoading] = useState(true);

  const [error, setError] = useState<string | null>(null);
  const [isRestoring, setIsRestoring] = useState(false);

  useEffect(() => {
    const q = query(collection(db, 'deleted_logs'), orderBy('deletedAt', 'desc'), limit(100));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as DeletedLog));
      setLogs(data);
      setLoading(false);
      setError(null);
    }, (err) => {
      console.error("Deleted logs error:", err);
      setError("You do not have permission to view deleted logs, or the Firestore rules for 'deleted_logs' have not been deployed yet.");
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const handleRestore = async (log: DeletedLog) => {
    if (log.type !== 'borrow_record' && log.type !== 'inventory_item') {
      alert("ການກູ້ຄືນ (Restore) ຮອງຮັບສະເພາະບາງປະເພດເທົ່ານັ້ນ.");
      return;
    }
    if (!log.originalData || Object.keys(log.originalData).length === 0) {
      alert("ບໍ່ມີຂໍ້ມູນເດີມ (Original Data) ສຳລັບກູ້ຄືນ.");
      return;
    }
    
    if (confirm(`ທ່ານແນ່ໃຈບໍ່ວ່າຕ້ອງການກູ້ຄືນຂໍ້ມູນນີ້ (Restore this ${log.type.replace('_', ' ')})?`)) {
      setIsRestoring(true);
      try {
        const collectionName = log.type === 'borrow_record' ? 'borrow_records' : 'inventory';
        await setDoc(doc(db, collectionName, log.recordId), log.originalData);
        await deleteDoc(doc(db, 'deleted_logs', log.id));
        alert('กູ້ຄືນຂໍ້ມູນສຳເລັດແລ້ວ! (Restore successful!)');
      } catch (e: any) {
        console.error(e);
        alert(`Failed to restore: ${e.message}`);
      } finally {
        setIsRestoring(false);
      }
    }
  };

  if (loading) {
    return <div className="p-8 text-center text-slate-500 flex flex-col items-center">
       <div className="w-8 h-8 border-4 border-indigo-200 border-t-indigo-600 rounded-full animate-spin mb-4" />
       Loading delete logs...
    </div>;
  }

  if (error) {
    return (
      <div className="p-8 text-center">
        <div className="bg-rose-50 text-rose-700 p-6 rounded-2xl border border-rose-200 inline-block max-w-2xl">
          <AlertCircle className="mx-auto h-12 w-12 text-rose-500 mb-4" />
          <h3 className="text-lg font-bold mb-2">Access Denied</h3>
          <p>{error}</p>
          <p className="mt-4 text-xs text-rose-500 font-mono text-left bg-white p-3 rounded-xl border border-rose-100 overflow-auto max-h-64">
            <strong>Admin Action Required:</strong><br />
            Please update your Firebase Firestore Security Rules in the Firebase Console and change the <code>deleted_logs</code> and <code>borrow_records</code> (delete) policies to use <code>isAdmin()</code> instead of <code>isSuperAdmin()</code>.
            <br /><br />
            <code>
              match /borrow_records/&#123;recordId&#125; &#123;<br />
              &nbsp;&nbsp;...<br />
              &nbsp;&nbsp;allow delete: if isAdmin() && isValidId(recordId);<br />
              &#125;<br /><br />
              match /deleted_logs/&#123;logId&#125; &#123;<br />
              &nbsp;&nbsp;allow list, get: if isAdmin();<br />
              &nbsp;&nbsp;allow create: if isAdmin();<br />
              &nbsp;&nbsp;allow update, delete: if false;<br />
              &#125;
            </code>
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="bg-rose-50 border border-rose-100 rounded-2xl p-4 flex items-start gap-4">
        <AlertCircle className="text-rose-600 shrink-0 mt-0.5" />
        <div>
          <h3 className="font-bold text-rose-900">ບັນທຶກການລຶບຂໍ້ມູນ (Deletion Audit Trail)</h3>
          <p className="text-sm text-rose-700 mt-1">
            This module stores a 100-record history of records and inventory items deleted by administrators.
          </p>
        </div>
      </div>

      <div className="bg-white rounded-3xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 text-xs uppercase tracking-wider font-bold">
                <th className="px-6 py-4">Date/Time</th>
                <th className="px-6 py-4">Deleted By</th>
                <th className="px-6 py-4">Type</th>
                <th className="px-6 py-4">Record ID</th>
                <th className="px-6 py-4">Reason</th>
                <th className="px-6 py-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {logs.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-6 py-12 text-center text-slate-400 italic">No deletion records found.</td>
                </tr>
              ) : (
                logs.map(log => (
                  <tr key={log.id} className="hover:bg-slate-50/50 transition-colors">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <p className="text-xs font-medium text-slate-900">{log.deletedAt?.toDate ? format(log.deletedAt.toDate(), "dd MMM, yyyy HH:mm") : 'N/A'}</p>
                    </td>
                    <td className="px-6 py-4">
                      <p className="text-xs font-medium text-slate-700">{log.deletedBy}</p>
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-slate-100 text-slate-600">
                        {log.type.replace('_', ' ')}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <p className="text-xs font-mono text-slate-500">{log.recordId}</p>
                    </td>
                    <td className="px-6 py-4">
                      <p className="text-sm text-slate-900">{log.reason}</p>
                    </td>
                    <td className="px-6 py-4 text-right">
                      {log.originalData && Object.keys(log.originalData).length > 0 && (
                        <button
                          onClick={() => handleRestore(log)}
                          disabled={isRestoring}
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-emerald-700 bg-emerald-50 hover:bg-emerald-100 rounded-lg transition-colors disabled:opacity-50"
                          title="Restore this record"
                        >
                          <RotateCcw size={14} />
                          Restore
                        </button>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
