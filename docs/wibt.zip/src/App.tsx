/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  LayoutDashboard, 
  Package, 
  ArrowLeftRight, 
  History, 
  Settings, 
  Users,
  Menu, 
  X, 
  Search, 
  Bell, 
  User,
  Plus,
  Filter,
  ArrowUpRight,
  ArrowDownLeft,
  AlertTriangle,
  CheckCircle2,
  Clock,
  LogOut,
  LogIn,
  Trash2,
  Edit3,
  Eye,
  EyeOff,
  Download,
  Upload,
  Building2,
  Hash,
  Send,
  Check,
  Edit2,
  Columns,
  ArrowUp,
  ArrowDown,
  GripVertical,
  KeyRound,
  Star,
  RefreshCw,
  AlertCircle,
  PowerOff,
  Camera,
  Image as ImageIcon,
  PackageCheck,
  CalendarClock
} from 'lucide-react';
import { cn } from './lib/utils';
import { InventoryItem, BorrowRecord, ActivityLog, ItemStatus, Unit, Department, AppNotification, NotificationSettings, WorkflowSettings } from './types';
import { ProfileView } from './components/ProfileView';
import { BorrowRequestForm } from './components/BorrowRequestForm';
import { format, isAfter, parseISO, differenceInDays, subDays, startOfDay } from 'date-fns';
import { DeletedLogsView } from './components/DeletedLogsView';
import { AuthScreen } from './components/AuthScreen';
import { ProfileCompletionScreen } from './components/ProfileCompletionScreen';
import { EditBorrowRecordModal } from './components/EditBorrowRecordModal';

function PendingApprovalScreen({ onSignOut, userName, userEmail }: { onSignOut: () => void, userName?: string, userEmail?: string }) {
  const notifyAdmin = (phone: string) => {
    const text = encodeURIComponent(`📢 ສະບາຍດີ Admin,\n\nມີຜູ້ໃຊ້ງານໃໝ່ຂໍອະນຸມັດເຂົ້າລະບົບ (New User Registration).\n\nຊື່ (Name): ${userName || 'ບໍ່ລະບຸ'}\nອີເມລ (Email): ${userEmail || 'ບໍ່ລະບຸ'}\n\nກະລຸນາເຂົ້າລະບົບເພື່ອອະນຸມັດ (Please approve in the system).`);
    window.open(`https://wa.me/85620${phone}?text=${text}`, '_blank');
  };

  return (
    <div className="fixed inset-0 flex items-center justify-center bg-slate-50 p-4 overflow-y-auto">
      <div className="bg-white p-8 md:p-10 rounded-3xl shadow-xl max-w-md w-full text-center my-auto">
        <div className="w-16 h-16 bg-amber-100 rounded-2xl flex items-center justify-center text-amber-600 mx-auto mb-6">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-8 h-8">
            <circle cx="12" cy="12" r="10"></circle>
            <polyline points="12 6 12 12 16 14"></polyline>
          </svg>
        </div>
        <h1 className="text-2xl font-bold tracking-tight text-slate-900 mb-2">
          Pending Approval
        </h1>
        <p className="text-slate-500 mb-6 leading-relaxed text-sm">
          Your account has been successfully created and is waiting for administrator approval. You will have access once your account is activated.
        </p>

        <div className="bg-slate-50 p-4 rounded-2xl mb-8 border border-slate-100">
           <p className="text-xs font-bold text-slate-500 uppercase mb-3">Notify Admins to Approve</p>
           <div className="grid grid-cols-2 gap-3">
              <button 
                onClick={() => notifyAdmin('59682000')}
                className="flex flex-col items-center justify-center gap-1.5 bg-[#25D366] text-white p-2.5 rounded-xl hover:bg-[#1ebd5b] transition-all shadow-sm"
              >
                <div className="flex items-center gap-1.5"><Send size={14} className="shrink-0" /> Admin 1</div>
                <span className="text-[10px] bg-white/20 px-1.5 py-0.5 rounded">59682000</span>
              </button>
              <button 
                onClick={() => notifyAdmin('22611079')}
                className="flex flex-col items-center justify-center gap-1.5 bg-[#25D366] text-white p-2.5 rounded-xl hover:bg-[#1ebd5b] transition-all shadow-sm"
              >
                <div className="flex items-center gap-1.5"><Send size={14} className="shrink-0" /> Admin 2</div>
                <span className="text-[10px] bg-white/20 px-1.5 py-0.5 rounded">22611079</span>
              </button>
           </div>
        </div>

        <button 
          onClick={onSignOut}
          className="w-full flex items-center justify-center gap-2 bg-slate-100 text-slate-700 p-3.5 rounded-xl hover:bg-slate-200 transition-all font-semibold"
        >
          <LogOut size={18} />
          Sign Out
        </button>
      </div>
    </div>
  );
}

import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  PieChart,
  Pie,
  Cell
} from 'recharts';
import { auth, db, storage } from './firebase';
import { 
  onAuthStateChanged, 
  signInWithPopup, 
  GoogleAuthProvider, 
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  sendPasswordResetEmail,
  signOut,
  User as FirebaseUser
} from 'firebase/auth';
import { read, utils } from 'xlsx';
import { 
  collection, 
  onSnapshot, 
  addDoc, 
  updateDoc,
  serverTimestamp, 
  query, 
  orderBy,
  limit,
  startAfter,
  where,
  getDocs,
  getCountFromServer,
  getAggregateFromServer,
  sum,
  count,
  doc,
  getDocFromServer,
  deleteDoc,
  getDoc,
  setDoc,
  writeBatch,
  increment
} from 'firebase/firestore';
import { ref, uploadString, getDownloadURL } from 'firebase/storage';

const processImageFiles = async (files: FileList | File[], remainingSlots: number): Promise<string[]> => {
  const filesToProcess = Array.from(files).slice(0, remainingSlots);
  const base64Promises = filesToProcess.map((file: File) => {
    return new Promise<string>((resolve) => {
      const reader = new FileReader();
      reader.onload = (ev) => {
        const img = new Image();
        img.onload = () => {
          const canvas = document.createElement('canvas');
          let width = img.width;
          let height = img.height;
          const MAX_DIMENSION = 1600;
          
          if (width > height && width > MAX_DIMENSION) {
            height *= MAX_DIMENSION / width;
            width = MAX_DIMENSION;
          } else if (height > MAX_DIMENSION) {
            width *= MAX_DIMENSION / height;
            height = MAX_DIMENSION;
          }
          
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          if (ctx) {
            ctx.drawImage(img, 0, 0, width, height);
            resolve(canvas.toDataURL('image/jpeg', 0.95));
          } else {
            resolve(ev.target?.result as string);
          }
        };
        img.onerror = () => resolve(ev.target?.result as string);
        if (ev.target?.result) {
          img.src = ev.target.result as string;
        } else {
          resolve('');
        }
      };
      reader.readAsDataURL(file);
    });
  });
  return await Promise.all(base64Promises);
};

// Mock Data
const MOCK_UNITS: Unit[] = [
  { id: 'HAU', name: 'Human Resource and Administration' },
  { id: 'ENG', name: 'Engineering' },
];

const MOCK_DEPARTMENTS: Department[] = [
  { id: 'FMU', name: 'FMU', unitId: 'HAU' },
  { id: 'MTN-PL', name: 'MTN-PL', unitId: 'ENG' },
  { id: 'MTN-CV', name: 'MTN-CV', unitId: 'ENG' },
  { id: 'MTN-EL', name: 'MTN-EL', unitId: 'ENG' },
  { id: 'MTN-EM', name: 'MTN-EM', unitId: 'ENG' },
  { id: 'MTN-SC', name: 'MTN-SC', unitId: 'ENG' },
  { id: 'MTN-ME', name: 'MTN-ME', unitId: 'ENG' },
  { id: 'MTN-TL', name: 'MTN-TL', unitId: 'ENG' },
  { id: 'OP-HM', name: 'OP-HM', unitId: 'ENG' },
  { id: 'OP-SCO', name: 'OP-SCO', unitId: 'ENG' },
  { id: 'OP-DW', name: 'OP-DW', unitId: 'ENG' },
];

type View = 'dashboard' | 'inventory' | 'borrowing' | 'history' | 'users' | 'settings' | 'messages' | 'profile' | 'deleted_logs';

const ConfirmModal = ({ 
  isOpen, 
  title, 
  message, 
  requireReason,
  onConfirm, 
  onCancel 
}: { 
  isOpen: boolean; 
  title: string; 
  message: string; 
  requireReason?: boolean;
  onConfirm: (reason?: string) => void; 
  onCancel: () => void; 
}) => {
  const [reason, setReason] = useState('');
  
  if (!isOpen) return null;
  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[100] p-4">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-md overflow-hidden">
        <div className="p-6">
          <h3 className="text-xl font-bold text-gray-900 mb-2">{title}</h3>
          <p className="text-gray-600 mb-4">{message}</p>
          {requireReason && (
            <div className="mt-4">
              <label className="text-sm font-bold text-gray-700 block mb-2">ເຫດຜົນການລຶບ (Reason for deletion)</label>
              <textarea
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                className="w-full border border-gray-300 rounded-lg p-3 text-sm focus:border-rose-500 outline-none"
                placeholder="ບອກເຫດຜົນໃນການລຶບ..."
                required
              />
            </div>
          )}
        </div>
        <div className="px-6 py-4 bg-gray-50 flex justify-end gap-3">
          <button
            onClick={onCancel}
            className="px-4 py-2 text-gray-700 font-medium hover:bg-gray-200 rounded-xl transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={() => onConfirm(requireReason ? reason : undefined)}
            disabled={requireReason ? reason.trim().length === 0 : false}
            className="px-4 py-2 bg-rose-600 text-white font-medium hover:bg-rose-700 rounded-xl transition-colors shadow-sm shadow-rose-200 disabled:opacity-50"
          >
            Confirm Delete
          </button>
        </div>
      </div>
    </div>
  );
};

export const formatUserName = (emailOrName: string, users?: any[]) => {
  if (!emailOrName) return '';
  
  // Try to find full name from users array
  let fullName = emailOrName;
  if (users) {
    const foundUser = users.find(u => u.email === emailOrName || u.name === emailOrName);
    if (foundUser?.name) {
      fullName = foundUser.name;
    }
  }

  // If it still looks like an email and we couldn't find a name
  if (fullName.includes('@') && fullName === emailOrName) {
    const namePart = fullName.split('@')[0];
    const parts = namePart.split(/[\.\-_]/);
    if (parts.length > 1) {
       return `${parts[0].charAt(0).toUpperCase() + parts[0].slice(1).toLowerCase()} ${parts[1].charAt(0).toUpperCase()}`;
    }
    return parts[0].charAt(0).toUpperCase() + parts[0].slice(1).toLowerCase();
  }
  
  // Try to format existing name
  const parts = fullName.trim().split(/\s+/);
  if (parts.length > 1) {
    const firstName = parts[0];
    // Find first non-empty word after first name for last name Initial
    let lastInitial = '';
    for (let i = 1; i < parts.length; i++) {
        if(parts[i].length > 0) {
            lastInitial = parts[i].charAt(0).toUpperCase();
            break; // take first letter of the next word
        }
    }
    return `${firstName} ${lastInitial}`;
  }
  return fullName;
};

export default function App() {
  const [borrowStatusFilter, setBorrowStatusFilter] = useState('');
  const [borrowSelectedRecordId, setBorrowSelectedRecordId] = useState('');

  const [activeView, setActiveView] = useState<View>('dashboard');
  const [isSidebarOpen, setIsSidebarOpen] = useState(window.innerWidth >= 768);
  const [searchQuery, setSearchQuery] = useState('');
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [isItemFormOpen, setIsItemFormOpen] = useState(false);
  const [selectedItem, setSelectedItem] = useState<InventoryItem | null>(null);
  const [itemFormPhotos, setItemFormPhotos] = useState<string[]>([]);
  const [isImporting, setIsImporting] = useState(false);
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [currentUserDoc, setCurrentUserDoc] = useState<any>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [isSuperAdmin, setIsSuperAdmin] = useState(false);
  const [isAuthReady, setIsAuthReady] = useState(false);
  const [itemsPerPage, setItemsPerPage] = useState(() => {
    const saved = localStorage.getItem('itemsPerPage');
    const parsed = saved !== null ? parseInt(saved, 10) : 10;
    return isNaN(parsed) || parsed < 5 ? 10 : parsed;
  });

  const handleItemsPerPageChange = (newVal: number) => {
    setItemsPerPage(newVal);
    localStorage.setItem('itemsPerPage', newVal.toString());
  };

  // Firestore State
  const [units, setUnits] = useState<Unit[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [borrowRecords, setBorrowRecords] = useState<BorrowRecord[]>([]);
  const [activityLogs, setActivityLogs] = useState<ActivityLog[]>([]);
  const [appUsers, setAppUsers] = useState<any[]>([]);
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [notificationSettings, setNotificationSettings] = useState<NotificationSettings>({ daysBeforeReminder: 1 });
  const [workflowSettings, setWorkflowSettings] = useState<WorkflowSettings>({ requireManagerAcknowledge: true, requireWhApprover: true });
  const [showNotifications, setShowNotifications] = useState(false);
  const [notificationToDelete, setNotificationToDelete] = useState<AppNotification | null>(null);
  const [deleteReason, setDeleteReason] = useState("");
  const longPressTimerRef = useRef<NodeJS.Timeout | null>(null);
  const isLongPressRef = useRef(false);
  const notificationsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (notificationsRef.current && !notificationsRef.current.contains(event.target as Node)) {
        setShowNotifications(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      // ປ້ອງກັນບໍ່ໃຫ້ຜູ້ໃຊ້ຈາກແອັບອື່ນ (ເຊັ່ນ MOST ທີ່ໃຊ້ເບີໂທ) ເຂົ້າໃຊ້ WIBT
      if (user && !user.email) {
        await signOut(auth);
        setUser(null);
        alert('ແອັບນີ້ຮອງຮັບສະເພາະຜູ້ໃຊ້ທີ່ລົງທະບຽນດ້ວຍອີເມລເທົ່ານັ້ນ. ກະລຸນາໃຊ້ແອັບໃຫ້ຖືກຕ້ອງ.');
        return;
      }

      if (user && user.email) {
        const emailLower = user.email.toLowerCase();
        if (!emailLower.endsWith('@namtheun2.com') && emailLower !== 'khamsone.peng@gmail.com') {
          await signOut(auth);
          setUser(null);
          alert('Access restricted to @namtheun2.com accounts.');
          return;
        }
      }

      setUser(user);
      if (user) {
        try {
          // Ensure user document exists
          const userRef = doc(db, 'users', user.uid);
          let userDoc = await getDoc(userRef);
          
          if (!userDoc.exists()) {
            let initialRole = user.email?.toLowerCase() === 'khamsone.peng@gmail.com' ? 'super_admin' : 'user';
            let initialStatus = 'pending';
            
            // Try to find if user was pre-created
            if (initialRole !== 'super_admin') {
              try {
                const q = query(collection(db, 'users'), where('email', '==', user.email), where('isPreCreated', '==', true));
                const querySnapshot = await getDocs(q);
                
                if (!querySnapshot.empty) {
                  initialRole = querySnapshot.docs[0].data().role;
                  initialStatus = 'active'; // Pre-invited gets active
                  
                  // Delete all pre-created documents for this email to avoid duplicate listings
                  for (const d of querySnapshot.docs) {
                     await deleteDoc(d.ref);
                  }
                }
              } catch (e) {
                console.error("Failed to check pre-created users:", e);
              }
            } else {
              initialStatus = 'active'; // Super admins get active
            }

            await setDoc(userRef, {
              email: user.email,
              displayName: user.displayName || '',
              name: user.displayName || '',
              role: initialRole,
              status: initialStatus,
              createdAt: serverTimestamp()
            }, { merge: true });
            
            userDoc = await getDoc(userRef);
          } else if (user.email?.toLowerCase() === 'khamsone.peng@gmail.com' && userDoc.data()?.role !== 'super_admin') {
            await updateDoc(userRef, { role: 'super_admin', status: 'active' });
            userDoc = await getDoc(userRef);
          }

          // Setup real-time listener for current user
          const unsubCurrentUser = onSnapshot(userRef, (docSnap) => {
             if (docSnap.exists()) {
                setCurrentUserDoc(docSnap.data());
             }
          }, (error) => {
             console.warn("Could not listen to current user doc:", error);
          });

          // Store cleanup safely. We can't return from the inner block cleanly for unsubscribe, but we could assign to a ref
          // Or just let it live until user signs out.
          const globalUnsub = (window as any).__currentUserUnsub;
          if (globalUnsub) globalUnsub();
          (window as any).__currentUserUnsub = unsubCurrentUser;

          // Super admin check
          const dbRole = userDoc.exists() ? userDoc.data()?.role : 'user';
          if (user.email?.toLowerCase() === 'khamsone.peng@gmail.com' || dbRole === 'super_admin') {
            setIsSuperAdmin(true);
            setIsAdmin(true);
          } else {
            setIsSuperAdmin(false);
            setIsAdmin(dbRole === 'admin');
          }
        } catch (error) {
          console.error("Error handling user login:", error);
          // Fallback for super admin even if Firestore fails
          if (user.email === 'khamsone.peng@gmail.com') {
            setIsSuperAdmin(true);
            setIsAdmin(true);
          } else {
            setIsSuperAdmin(false);
            setIsAdmin(false);
          }
        }
      } else {
        setIsAdmin(false);
        setCurrentUserDoc(null);
        const globalUnsub = (window as any).__currentUserUnsub;
        if (globalUnsub) { 
           globalUnsub();
           (window as any).__currentUserUnsub = null;
        }
      }
      setIsAuthReady(true);
    });
    return () => unsubscribe();
  }, []);

  // Idle timeout auto-logout
  useEffect(() => {
    if (!user) return;
    
    let lastActivity = Date.now();
    const IDLE_TIMEOUT = 3 * 60 * 1000; // 3 minutes

    const handleUserActivity = () => {
      lastActivity = Date.now();
    };

    // Check periodically instead of resetting timer on every event
    const checkIdle = setInterval(() => {
      if (Date.now() - lastActivity > IDLE_TIMEOUT) {
        clearInterval(checkIdle);
        signOut(auth).catch(console.error);
        alert("ເຊດຊັນໝົດອາຍຸ (Session has expired due to inactivity). ຂອບໃຈທີ່ໃຊ້ງານ.");
      }
    }, 60000); // Check every 60 seconds (1 minute) instead of 10s

    // Listen to user events
    window.addEventListener('mousemove', handleUserActivity, { passive: true });
    window.addEventListener('keydown', handleUserActivity, { passive: true });
    window.addEventListener('touchstart', handleUserActivity, { passive: true });
    window.addEventListener('scroll', handleUserActivity, { passive: true });
    window.addEventListener('click', handleUserActivity, { passive: true });

    return () => {
      clearInterval(checkIdle);
      window.removeEventListener('mousemove', handleUserActivity);
      window.removeEventListener('keydown', handleUserActivity);
      window.removeEventListener('touchstart', handleUserActivity);
      window.removeEventListener('scroll', handleUserActivity);
      window.removeEventListener('click', handleUserActivity);
    };
  }, [user]);

  useEffect(() => {
    if (!isAuthReady || !user) return;

    // Test Connection
    const testConnection = async () => {
      try {
        await getDocFromServer(doc(db, 'test', 'connection'));
      } catch (error) {
        if(error instanceof Error && error.message.includes('the client is offline')) {
          console.error("Please check your Firebase configuration. ");
        }
      }
    };
    testConnection();

    // Listen to Units
    const unsubUnits = onSnapshot(collection(db, 'units'), (snapshot) => {
      let data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Unit));
      if (data.length === 0) data = MOCK_UNITS;
      setUnits(data);
    }, (error) => handleFirestoreError(error, 'LIST', 'units'));

    // Listen to Departments
    const unsubDepts = onSnapshot(collection(db, 'departments'), (snapshot) => {
      let data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Department));
      if (data.length === 0) data = MOCK_DEPARTMENTS;
      setDepartments(data);
    }, (error) => handleFirestoreError(error, 'LIST', 'departments'));

    // Listen to Borrow Records
    const unsubBorrows = onSnapshot(collection(db, 'borrow_records'), (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as BorrowRecord));
      setBorrowRecords(data);
    }, (error) => handleFirestoreError(error, 'LIST', 'borrow_records'));

    const unsubActivity = onSnapshot(collection(db, 'activity_logs'), (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as ActivityLog));
      // Sort by timestamp descending
      data.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
      setActivityLogs(data);
    }, (error) => handleFirestoreError(error, 'LIST', 'activity_logs'));

    // Listen to Users (For everyone to select managers/approvers)
    const unsubUsers = onSnapshot(collection(db, 'users'), (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setAppUsers(data);
    }, (error) => handleFirestoreError(error, 'LIST', 'users'));

    return () => {
      unsubUnits();
      unsubDepts();
      unsubBorrows();
      unsubActivity();
      unsubUsers();
    };
  }, [isAuthReady, user]);

  useEffect(() => {
    if (!isAuthReady || !user) return;
    
    // Listen to Notifications
    // Keep the array length constant to prevent Firebase SDK internal assertion error (ID: ca9)
    const notificationTargets = [
      user.uid,
      user.email?.toLowerCase() || 'NO_EMAIL',
      isAdmin ? 'admin' : 'NO_ADMIN'
    ];
    
    // Ensure uniqueness manually without changing length (though Firebase might complain about duplicates, it is fine to have dummy strings)
    // Actually, Firebase 'in' max is 10, duplicates are fine.
    const unsubNotifications = onSnapshot(
      query(collection(db, 'notifications'), where('userId', 'in', notificationTargets)), 
      (snapshot) => {
        const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as AppNotification));
        // Filter out 'admin' notifications if the user is not an admin
        const filteredData = isAdmin ? data : data.filter(n => n.userId !== 'admin');
        setNotifications(filteredData.sort((a, b) => b.createdAt?.toMillis() - a.createdAt?.toMillis()));
      }, 
      (error) => handleFirestoreError(error, 'LIST', 'notifications')
    );

    // Listen to Notification Settings
    const unsubSettings = onSnapshot(doc(db, 'settings', 'notifications'), (docSnap) => {
      if (docSnap.exists()) {
        setNotificationSettings(docSnap.data() as NotificationSettings);
      } else if (isAdmin) {
        setDoc(doc(db, 'settings', 'notifications'), { daysBeforeReminder: 1 }).catch(() => {});
      }
    }, (error) => {
      console.warn("Could not listen to notifications settings:", error);
    });

    // Listen to Workflow Settings
    const unsubWorkflowSettings = onSnapshot(doc(db, 'settings', 'workflow'), (docSnap) => {
      if (docSnap.exists()) {
        setWorkflowSettings(docSnap.data() as WorkflowSettings);
      } else if (isAdmin) {
        setDoc(doc(db, 'settings', 'workflow'), { requireManagerAcknowledge: true, requireWhApprover: true }).catch(() => {});
      }
    }, (error) => {
      console.warn("Could not listen to workflow settings:", error);
    });

    return () => {
      unsubNotifications();
      unsubSettings();
      unsubWorkflowSettings();
    };
  }, [isAuthReady, user, isAdmin]);

  const [stats, setStats] = useState<{
    totalItems: number;
    totalQuantity: number;
    lowStock: number;
    activeBorrows: number;
    overdue: number;
    pieData: { name: string; value: number; color: string; }[];
    error?: string;
  }>({
    totalItems: 0,
    totalQuantity: 0,
    lowStock: 0,
    activeBorrows: 0,
    overdue: 0,
    pieData: [
      { name: 'Available', value: 0, color: '#4f46e5' },
      { name: 'Borrowed', value: 0, color: '#f59e0b' },
      { name: 'Maintenance', value: 0, color: '#ef4444' },
    ]
  });

  useEffect(() => {
    if (!isAuthReady || !user) return;

    let isFetching = false;
    let isMounted = true;

    const fetchStats = async () => {
      if (isFetching || !isMounted) return;
      isFetching = true;
      try {
        const [
          invAgg,
          availableCount,
          borrowedCount,
          maintenanceCount,
          lowStockCount,
          activeBorrowsCount,
          overdueBorrowsCount
        ] = await Promise.all([
          getAggregateFromServer(collection(db, 'inventory'), {
            totalItems: count(),
            totalQuantity: sum('quantity')
          }),
          getCountFromServer(query(collection(db, 'inventory'), where('status', '==', 'available'))),
          getCountFromServer(query(collection(db, 'inventory'), where('status', '==', 'borrowed'))),
          getCountFromServer(query(collection(db, 'inventory'), where('status', '==', 'maintenance'))),
          getCountFromServer(query(collection(db, 'inventory'), where('status', '==', 'low-stock'))),
          getCountFromServer(query(collection(db, 'borrow_records'), where('status', '==', 'active'))),
          getCountFromServer(query(collection(db, 'borrow_records'), where('status', '==', 'overdue')))
        ]);

        if (!isMounted) return;

        setStats({
          totalItems: invAgg.data().totalItems,
          totalQuantity: invAgg.data().totalQuantity,
          lowStock: lowStockCount.data().count,
          activeBorrows: activeBorrowsCount.data().count + overdueBorrowsCount.data().count,
          overdue: overdueBorrowsCount.data().count,
          pieData: [
            { name: 'Available', value: availableCount.data().count, color: '#4f46e5' },
            { name: 'Borrowed', value: borrowedCount.data().count, color: '#f59e0b' },
            { name: 'Maintenance', value: maintenanceCount.data().count, color: '#ef4444' },
          ]
        });
      } catch (error: any) {
        if (!isMounted) return;
        // Suppress expected offline errors or connection issues to prevent console spam
        if (error?.message?.includes('offline') || error?.message?.includes('network-request-failed') || error?.message?.includes('Connection failed') || error?.code === 'unavailable') {
          console.warn("Could not fetch latest stats. Retrying later...");
        } else if (error?.message?.includes('Missing or insufficient permissions') || error?.code === 'permission-denied') {
          console.warn("Could not fetch stats: Missing permissions. Please update your Firestore security rules.");
          setStats(prev => ({ 
            ...prev, 
            error: "You do not have permission to fetch warehouse statistics, or your Firestore security rules need to be updated to allow aggregations (count/sum) on 'inventory' and 'borrow_records' collections."
          }));
        } else {
          console.error("Failed to fetch stats:", error);
        }
      } finally {
        isFetching = false;
      }
    };

    fetchStats();
    // Refresh stats every 5 minutes (300,000ms) to reduce background load and prevent flickering
    const interval = setInterval(fetchStats, 300000);
    return () => {
      isMounted = false;
      clearInterval(interval);
    };
  }, [isAuthReady, user]);

  const handleLogin = async () => {
    const provider = new GoogleAuthProvider();
    try {
      const result = await signInWithPopup(auth, provider);
      if (result.user && result.user.email) {
        const emailLower = result.user.email.toLowerCase();
        if (!emailLower.endsWith('@namtheun2.com') && emailLower !== 'khamsone.peng@gmail.com') {
          await signOut(auth);
          alert('Access restricted to @namtheun2.com accounts.');
        }
      }
    } catch (error: any) {
      if (error.code !== 'auth/popup-closed-by-user' && error.code !== 'auth/cancelled-popup-request') {
        if (error.code === 'auth/invalid-credential' || error.message?.includes('invalid-credential')) {
           alert('ອີເມລ ຫຼື ລະຫັດຜ່ານບັນຊີ ບໍ່ຖືກຕ້ອງ (Invalid email or password).');
        } else {
           console.error("Login failed:", error);
           alert(error.message || 'Login failed');
        }
      }
    }
  };

  const handleLogout = async () => {
    try {
      await signOut(auth);
    } catch (error) {
      console.error("Logout failed:", error);
    }
  };

  const handleForceSync = async () => {
    if ('serviceWorker' in navigator) {
      try {
        const regs = await navigator.serviceWorker.getRegistrations();
        for (const reg of regs) {
          await reg.unregister();
        }
      } catch (e) {
        console.error('Error unregistering SW', e);
      }
    }
    if ('caches' in window) {
      try {
        const keys = await caches.keys();
        for (const key of keys) {
          await caches.delete(key);
        }
      } catch (e) {
        console.error('Error clearing caches', e);
      }
    }
    window.location.reload();
  };

  const handleFirestoreError = (error: any, operation: string, path: string) => {
    // If we get permission denied on newly added collections, it means the user's remote rules are outdated
    const msg = error?.message || String(error);
    if (msg.includes('Missing or insufficient permissions')) {
      console.warn(`Firestore permission denied on ${path}. Rules needs update in Firebase Console.`);
      return;
    }
    
    const errInfo = {
      error: msg,
      operation,
      path,
      authInfo: {
        uid: auth.currentUser?.uid,
        email: auth.currentUser?.email,
        emailVerified: auth.currentUser?.emailVerified
      }
    };
    console.error(`Firestore Error [${operation}] on [${path}]:`, JSON.stringify(errInfo));
  };

  const logActivity = async (action: string, details: string) => {
    const userEmail = user?.email || auth.currentUser?.email;
    if (!userEmail) return;
    try {
      await addDoc(collection(db, 'activity_logs'), {
        action,
        user: userEmail,
        timestamp: new Date().toISOString(),
        details
      });
    } catch (e: any) {
      console.warn("Could not log activity:", e.message);
    }
  };

  const handleUpdateUserRole = async (userId: string, role: 'super_admin' | 'admin' | 'user' | 'approver' | 'acknowledge') => {
    try {
      let reason = '';
      try { reason = window.prompt(`ທ່ານກຳລັງປ່ຽນສິດຜູ້ໃຊ້ເປັນ "${role}". ກະລຸນາປ້ອນເຫດຜົນ / Reason for changing role:`) || ''; } catch(e) {}
      
      if (!reason || reason.trim() === '') {
        reason = "Admin fast role update";
      }
      
      const userDoc = appUsers.find(u => u.id === userId);
      await updateDoc(doc(db, 'users', userId), { role });
      
      await logActivity('Update User Role', `ປ່ຽນສິດຂອງ ${userDoc?.email} ເປັນ ${role} ຍ້ອນ: ${reason}`);
      alert(`User role updated to ${role}`);
    } catch (error) {
      console.error("Failed to update user role:", error);
      alert("Failed to update user role. Check permissions.");
    }
  };

  const handleAddUnit = async (id: string, name: string) => {
    try {
      await setDoc(doc(db, 'units', id), { id, name });
    } catch (error) {
      console.error("Failed to add unit:", error);
    }
  };

  const handleUpdateUnit = async (id: string, name: string) => {
    try {
      await updateDoc(doc(db, 'units', id), { name });
    } catch (error) {
      console.error("Failed to update unit:", error);
    }
  };

  const handleDeleteUnit = async (id: string) => {
    if (!isSuperAdmin) return;
    setConfirmDialog({
      isOpen: true,
      title: 'Delete Unit',
      message: 'Delete this unit?',
      onConfirm: async () => {
        setConfirmDialog(null);
        try {
          await deleteDoc(doc(db, 'units', id));
        } catch (error: any) {
          console.error("Failed to delete unit:", error);
          alert(`Failed to delete unit: ${error.message}`);
          handleFirestoreError(error, 'DELETE', `units/${id}`);
        }
      }
    });
  };

  const handleAddDept = async (id: string, name: string) => {
    try {
      await setDoc(doc(db, 'departments', id), { id, name });
    } catch (error) {
      console.error("Failed to add department:", error);
    }
  };

  const handleUpdateDept = async (id: string, name: string) => {
    try {
      await updateDoc(doc(db, 'departments', id), { name });
    } catch (error) {
      console.error("Failed to update department:", error);
    }
  };

  const handleDeleteDept = async (id: string) => {
    if (!isSuperAdmin) return;
    setConfirmDialog({
      isOpen: true,
      title: 'Delete Department',
      message: 'Delete this department?',
      onConfirm: async () => {
        setConfirmDialog(null);
        try {
          await deleteDoc(doc(db, 'departments', id));
        } catch (error: any) {
          console.error("Failed to delete department:", error);
          alert(`Failed to delete department: ${error.message}`);
          handleFirestoreError(error, 'DELETE', `departments/${id}`);
        }
      }
    });
  };

  const handleSaveItem = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!isAdmin) return;
    const formData = new FormData(e.currentTarget);
    const itemId = formData.get('id') as string;
    
    try {
      const finalId = selectedItem ? selectedItem.id : (itemId || Math.random().toString(36).substr(2, 9).toUpperCase());
      const timeoutPromise = <T,>(ms: number, message: string): Promise<T> => new Promise((_, reject) => setTimeout(() => reject(new Error(message)), ms));
      const uploadPhotos = async (photos: string[]) => {
        return await Promise.all(photos.map(async (p, i) => {
          if (p.startsWith('data:')) {
            const r = ref(storage, `inventory/${finalId}/photo_${Date.now()}_${i}.jpg`);
            await uploadString(r, p, 'data_url');
            return await getDownloadURL(r);
          }
          return p;
        }));
      };
      
      const storagePhotos = await Promise.race([
        uploadPhotos(itemFormPhotos),
        timeoutPromise<string[]>(30000, "ການອັບໂຫຼດຮູບພາບໃຊ້ເວລາດົນເກີນໄປ. ກະລຸນາກວດສອບອິນເຕີເນັດຂອງທ່ານ (Image upload timed out).")
      ]);

      const itemData: any = {
        name: formData.get('name'),
        uom: formData.get('uom'),
        sloc: formData.get('sloc'),
        bin: formData.get('bin'),
        functionalSystem: formData.get('functionalSystem'),
        mfrPartNumber: formData.get('mfrPartNumber'),
        brand: formData.get('brand'),
        category: formData.get('category'),
        quantity: Number(formData.get('quantity')),
        minQuantity: Number(formData.get('minQuantity')),
        description: formData.get('description'),
        status: formData.get('status'),
        lastUpdated: new Date().toISOString(),
        photos: storagePhotos
      };

      if (selectedItem) {
        await updateDoc(doc(db, 'inventory', selectedItem.id), itemData);
        alert('Item updated successfully');
      } else {
        // For new items, use the provided ID or generate one
        await setDoc(doc(db, 'inventory', finalId), { ...itemData, id: finalId });
        alert('Item added successfully');
      }
      setIsItemFormOpen(false);
      setSelectedItem(null);
      setItemFormPhotos([]);
    } catch (error) {
      console.error("Failed to save item:", error);
      alert("Failed to save item. Check permissions.");
    }
  };

  const [isDeletingAll, setIsDeletingAll] = useState(false);
  const [confirmDialog, setConfirmDialog] = useState<{isOpen: boolean, title: string, message: string, requireReason?: boolean, onConfirm: (reason?: string) => void} | null>(null);

  const handleDeleteItem = async (itemId: string) => {
    if (!isSuperAdmin) return;
    setConfirmDialog({
      isOpen: true,
      title: 'Delete Item',
      message: 'Are you sure you want to delete this item? This action cannot be undone.',
      requireReason: true,
      onConfirm: async (reason?: string) => {
        setConfirmDialog(null);
        try {
          // Note: inventory uses getDocs fetching instead of real-time listener for the UI but we can get it from inventory array if it's there
          // Wait, 'inventory' array is not available in App top level scope? (It's not real-time synced here)
          // We'll just store the ID in the log.
          await addDoc(collection(db, 'deleted_logs'), {
            type: 'inventory_item',
            recordId: itemId,
            deletedBy: currentUserDoc?.email || user?.email || 'Unknown',
            reason: reason || 'No reason provided',
            deletedAt: serverTimestamp()
          });
          await deleteDoc(doc(db, 'inventory', itemId));
        } catch (error: any) {
          console.error("Failed to delete item:", error);
          alert(`Failed to delete item: ${error.message}`);
          handleFirestoreError(error, 'DELETE', `inventory/${itemId}`);
        }
      }
    });
  };

  const handleDeleteAllInventory = async () => {
    if (!isSuperAdmin) return;
    setConfirmDialog({
      isOpen: true,
      title: 'Clear All Inventory',
      message: 'Are you sure you want to delete ALL inventory items? This cannot be undone.',
      onConfirm: async () => {
        setConfirmDialog(null);
        setIsDeletingAll(true);
        try {
          const snapshot = await getDocs(collection(db, 'inventory'));
          const allItems = snapshot.docs;
          
          if (allItems.length === 0) {
            setIsDeletingAll(false);
            return;
          }

          const chunks = [];
          for (let i = 0; i < allItems.length; i += 500) {
            chunks.push(allItems.slice(i, i + 500));
          }
          
          for (const chunk of chunks) {
            const currentBatch = writeBatch(db);
            chunk.forEach((docSnap) => {
              currentBatch.delete(docSnap.ref);
            });
            await currentBatch.commit();
          }
          console.log("All inventory items deleted.");
        } catch (error: any) {
          console.error("Failed to delete all items:", error);
          alert(`Failed to delete all items: ${error.message}`);
          handleFirestoreError(error, 'DELETE', 'inventory (batch)');
        } finally {
          setIsDeletingAll(false);
        }
      }
    });
  };

  const handleDeleteBorrowRecord = async (recordId: string) => {
    if (!isAdmin) return;

    const recordToLog = borrowRecords.find(r => r.id === recordId);
    if (recordToLog?.takingConfirmation) {
      alert("ບໍ່ສາມາດລຶບໄດ້ ເນື່ອງຈາກສະຖານະແມ່ນ In Uses ທີ່ຖືກ Confirm ແລ້ວ (Cannot delete because status is In Uses and Confirmed).");
      return;
    }

    setConfirmDialog({
      isOpen: true,
      title: 'Delete Record',
      message: 'Are you sure you want to delete this record?',
      requireReason: true,
      onConfirm: async (reason?: string) => {
        setConfirmDialog(null);
        try {
          const recordToLog = borrowRecords.find(r => r.id === recordId);
          await addDoc(collection(db, 'deleted_logs'), {
            type: 'borrow_record',
            recordId: recordId,
            deletedBy: currentUserDoc?.email || user?.email || 'Unknown',
            reason: reason || 'No reason provided',
            deletedAt: serverTimestamp(),
            originalData: recordToLog || {}
          });
          await deleteDoc(doc(db, 'borrow_records', recordId));
        } catch (error: any) {
          console.error("Failed to delete record:", error);
          alert(`Failed to delete record: ${error.message}`);
          handleFirestoreError(error, 'DELETE', `borrow_records/${recordId}`);
        }
      }
    });
  };

  const handleToggleDeactivate = async (recordId: string, currentStatus: string) => {
    if (!isAdmin) return;
    
    const record = borrowRecords.find(r => r.id === recordId);
    if (record?.takingConfirmation) {
      alert("ບໍ່ສາມາດປ່ຽນສະຖານະໄດ້ ເນື່ອງຈາກສະຖານະແມ່ນ In Uses ທີ່ຖືກ Confirm ແລ້ວ (Cannot deactivate because confirmed).");
      return;
    }

    const newStatus = currentStatus === 'deactivated' ? 'active' : 'deactivated';
    
    try {
      await updateDoc(doc(db, 'borrow_records', recordId), {
        status: newStatus
      });
    } catch (error: any) {
      console.error("Failed to toggle deactivate:", error);
      alert(`Failed to update status: ${error.message}`);
    }
  };

  const processExcelData = async (data: ArrayBuffer) => {
    const workbook = read(data);
    const worksheet = workbook.Sheets[workbook.SheetNames[0]];
    const jsonData = utils.sheet_to_json(worksheet) as any[];

    console.log(`Processing ${jsonData.length} items from Excel...`);
    
    // Firestore batches have a limit of 500 operations
    const CHUNK_SIZE = 500;
    for (let i = 0; i < jsonData.length; i += CHUNK_SIZE) {
      const chunk = jsonData.slice(i, i + CHUNK_SIZE);
      const batch = writeBatch(db);
      
      chunk.forEach((row) => {
        const materialId = (row['Material ID'] || row['id'] || row['Material'] || row['Material Number'])?.toString();
        if (!materialId) return;

        const itemRef = doc(collection(db, 'inventory'), materialId);
        const updatePayload: any = {
          id: materialId,
          name: row['Description'] || row['Long Description'] || row['Material Description'] || row['name'] || 'Unknown Item',
          uom: row['Base Unit'] || row['UoM'] || row['uom'] || 'EA',
          sloc: row['SLOC'] || row['Storage Location'] || row['sloc'] || 'N/A',
          bin: row['Bin'] || row['Bin Location'] || row['bin'] || 'N/A',
          functionalSystem: row['Functional System'] || row['Functional system'] || row['System'] || row['functionalSystem'] || 'N/A',
          mfrPartNumber: row['Mfr. Part Number'] || row['Mfr.Part Number'] || row['Part Number'] || row['mfrPartNumber'] || 'N/A',
          brand: row['Brand'] || row['brand'] || 'N/A',
          category: row['Category'] || row['category'] || 'General',
          status: (row['Status'] || row['status'] || 'available') as ItemStatus,
          lastUpdated: new Date().toISOString(),
          description: row['Long Description'] || row['Description'] || row['Material Description'] || row['description'] || ''
        };

        if (row['Stock'] !== undefined || row['Quantity'] !== undefined || row['quantity'] !== undefined) {
          updatePayload.quantity = Number(row['Stock']) || Number(row['Quantity']) || Number(row['quantity']) || 0;
        } else {
          updatePayload.quantity = increment(0);
        }

        if (row['Min Stock'] !== undefined || row['Min Quantity'] !== undefined || row['minQuantity'] !== undefined) {
          updatePayload.minQuantity = Number(row['Min Stock']) || Number(row['Min Quantity']) || Number(row['minQuantity']) || 0;
        } else {
          updatePayload.minQuantity = increment(0);
        }
        
        if (row['Photos']) {
          updatePayload.photos = row['Photos'].toString().split(',').map((p: string) => p.trim());
        }

        batch.set(itemRef, updatePayload, { merge: true });
      });

      await batch.commit();
      console.log(`Committed batch ${Math.floor(i / CHUNK_SIZE) + 1} of ${Math.ceil(jsonData.length / CHUNK_SIZE)}`);
    }
  };

  const handleImportExcel = async (file: File) => {
    setIsImporting(true);
    try {
      const data = await file.arrayBuffer();
      await processExcelData(data);
    } catch (error) {
      console.error('Error importing excel:', error);
      throw error;
    } finally {
      setIsImporting(false);
    }
  };

  const handleImportFromServerFile = async () => {
    setIsImporting(true);
    try {
      let response = await fetch('/Inventory%20Updates.csv');
      let fileName = 'Inventory Updates.csv';
      
      if (!response.ok) {
        response = await fetch('/Inventory.xlsx');
        fileName = 'Inventory.xlsx';
      }
      
      if (!response.ok) {
        response = await fetch('/Inventory.csv');
        fileName = 'Inventory.csv';
      }
      
      if (!response.ok) throw new Error('File not found on server');
      const data = await response.arrayBuffer();
      
      const workbook = read(data);
      const worksheet = workbook.Sheets[workbook.SheetNames[0]];
      const jsonData = utils.sheet_to_json(worksheet) as any[];
      
      await processExcelData(data);
      alert(`Inventory sync completed! ${jsonData.length} items processed from ${fileName}.`);
    } catch (error) {
      console.error('Error importing from server file:', error);
      alert('Could not find Inventory.xlsx or Inventory.csv on server. Please use the manual upload button.');
    } finally {
      setIsImporting(false);
    }
  };

  const runDailyReminderCheck = async () => {
    if (!isAdmin) return;
    
    let notificationsCreated = 0;
    const now = new Date();
    
    // Get the configured days before reminder (default 1)
    const targetDaysLeft = notificationSettings?.daysBeforeReminder ?? 1;
    
    for (const record of borrowRecords) {
      if (record.status !== 'active' || record.reminderSent) continue;
      
      const borrowDate = new Date(record.borrowDate);
      const plannedReturnDate = new Date(record.plannedReturnDate);
      
      // Calculate days left until return
      const timeLeft = plannedReturnDate.getTime() - now.getTime();
      const daysLeft = Math.ceil(timeLeft / (1000 * 60 * 60 * 24));
      
      if (daysLeft <= targetDaysLeft) {
        try {
          // 1. Notify Admins/Followers
          await addDoc(collection(db, 'notifications'), {
            userId: 'admin',
            title: 'Return Preparation Required',
            message: `Borrowing record for ${formatUserName(record.borrowerEmail, appUsers)} is due in ${daysLeft} days. Please prepare to receive the items.`,
            read: false,
            createdAt: serverTimestamp(),
            type: 'warning',
            linkToRecordId: record.id
          });
          
          // 2. Notify Borrower
          await addDoc(collection(db, 'notifications'), {
            userId: record.borrowerEmail,
            title: 'Items Due Soon',
            message: `Your borrowed items are due in ${daysLeft} days. Please return them or request an extension.`,
            read: false,
            createdAt: serverTimestamp(),
            type: 'warning',
            linkToRecordId: record.id
          });
          
          // Mark as reminder sent
          await updateDoc(doc(db, 'borrow_records', record.id), {
            reminderSent: true
          });
          
          notificationsCreated += 2;
        } catch (error) {
          console.error("Error creating notification:", error);
        }
      }
    }
    
    alert(`Daily check completed. Generated ${notificationsCreated} notifications.`);
  };

  const startLongPress = (notif: AppNotification) => {
    isLongPressRef.current = false;
    if (!notif.createdAt) return;
    
    // allow deleting warning messages if > 30 days
    let notifDate: Date;
    if (notif.createdAt && notif.createdAt.toDate) {
      notifDate = notif.createdAt.toDate();
    } else {
      notifDate = parseISO(notif.createdAt as string);
    }
    
    const ageInDays = (new Date().getTime() - notifDate.getTime()) / (1000 * 60 * 60 * 24);
    if (ageInDays <= 30) return;
    
    if (notif.linkToRecordId) {
      const record = borrowRecords.find(r => r.id === notif.linkToRecordId);
      if (record && record.status !== 'returned') {
        return; // require returned status
      }
    }

    longPressTimerRef.current = setTimeout(() => {
      isLongPressRef.current = true;
      setNotificationToDelete(notif);
    }, 800);
  };

  const cancelLongPress = () => {
    if (longPressTimerRef.current) {
      clearTimeout(longPressTimerRef.current);
      longPressTimerRef.current = null;
    }
  };

  const handleConfirmDeleteNotification = async () => {
    if (!notificationToDelete || !deleteReason.trim()) return;
    try {
      const notifId = notificationToDelete.id;
      await addDoc(collection(db, 'notifications'), {
        userId: 'admin',
        title: 'ການແຈ້ງເຕືອນຖືກລຶບ (Notification Deleted)',
        message: `ບຸກຄົນ: ${user?.email || 'Unknown'}\nຂໍ້ຄວາມທີ່ຖືກລຶບ: "${notificationToDelete.title}"\nເວລາ: ${format(new Date(), 'dd/MM/yyyy HH:mm')}\nເຫດຜົນ: ${deleteReason}`,
        read: false,
        createdAt: serverTimestamp(),
        type: 'info'
      });
      await deleteDoc(doc(db, 'notifications', notifId));
      setNotificationToDelete(null);
      setDeleteReason('');
    } catch (err) {
      console.error(err);
      alert('Failed to delete notification');
    }
  };

  const allNavItems = useMemo(() => [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'profile', label: 'My Profile', icon: User },
    { id: 'inventory', label: 'Inventory', icon: Package },
    { id: 'borrowing', label: 'Borrow/Tracking', icon: ArrowLeftRight },
    { id: 'history', label: 'History Logs', icon: History },
    { id: 'messages', label: 'Messages', icon: Send },
    { id: 'users', label: 'User Management', icon: Users },
    { id: 'deleted_logs', label: 'Delete Logs', icon: Trash2 },
    { id: 'settings', label: 'Settings', icon: Settings }
  ], []);

  const navItems = useMemo(() => isAdmin 
    ? allNavItems 
    : allNavItems.filter(item => ['dashboard', 'borrowing', 'messages', 'profile'].includes(item.id)),
  [isAdmin, allNavItems]);

  if (!isAuthReady) {
    return (
      <div className="fixed inset-0 flex items-center justify-center bg-slate-50">
        <div className="flex flex-col items-center gap-4">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
          <p className="text-sm font-medium text-slate-500">Loading system...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return <AuthScreen />;
  }

  // Ensure user has completed profile
  if (currentUserDoc && (!currentUserDoc.name || !currentUserDoc.phone || !currentUserDoc.unitId || !currentUserDoc.departmentId)) {
    return (
       <ProfileCompletionScreen 
         userUid={user.uid}
         userEmail={user.email || ''}
         defaultName={currentUserDoc.name || currentUserDoc.displayName || user.displayName || ''}
         onComplete={() => {
           // updateDoc will trigger a snapshot re-render and currentUserDoc will update.
         }}
       />
    )
  }

  const isPending = currentUserDoc?.status === 'pending';
  // Super admin bypasses this
  if (isPending && user.email?.toLowerCase() !== 'khamsone.peng@gmail.com') {
    return <PendingApprovalScreen 
             onSignOut={() => signOut(auth)} 
             userName={currentUserDoc?.name || currentUserDoc?.displayName}
             userEmail={user.email || undefined}
           />
  }

  return (
    <div className="flex h-[100dvh] bg-slate-50 text-slate-900 overflow-hidden font-sans relative">

      {/* Delete Notification Modal */}
      <AnimatePresence>
        {notificationToDelete && (
          <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-[70] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-2xl shadow-xl w-full max-w-md overflow-hidden"
            >
              <div className="p-6 border-b border-slate-100 flex items-center gap-3 bg-red-50 text-red-600">
                <Trash2 size={24} />
                <h2 className="text-lg font-bold">ຢືນຢັນການລຶບຂໍ້ຄວາມແຈ້ງເຕືອນ</h2>
              </div>
              <div className="p-6">
                <p className="text-sm text-slate-600 mb-4">
                  ກະລຸນາໃສ່ເຫດຜົນໃນການລຶບຂໍ້ຄວາມແຈ້ງເຕືອນນີ້. ທຸກໆເຫດຜົນຈະຖືກສົ່ງໃຫ້ Admin ເພື່ອກວດສອບ.
                </p>
                <textarea
                  value={deleteReason}
                  onChange={(e) => setDeleteReason(e.target.value)}
                  placeholder="ເຫດຜົນການລຶບ..."
                  className="w-full h-24 p-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:bg-white focus:border-red-300 focus:ring-2 focus:ring-red-100 transition-all outline-none resize-none"
                  autoFocus
                ></textarea>
              </div>
              <div className="p-4 bg-slate-50 border-t border-slate-100 flex justify-end gap-3">
                <button 
                  type="button"
                  onClick={() => {
                    setNotificationToDelete(null);
                    setDeleteReason('');
                  }}
                  className="px-4 py-2 font-semibold text-slate-600 hover:bg-slate-200 rounded-xl transition-all"
                >
                  ຍົກເລີກ (Cancel)
                </button>
                <button 
                  onClick={handleConfirmDeleteNotification}
                  disabled={!deleteReason.trim()}
                  className="px-4 py-2 bg-red-600 font-semibold text-white hover:bg-red-700 rounded-xl transition-all shadow-sm shadow-red-200 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
                >
                  <Trash2 size={16} />
                  ຢືນຢັນລຶບ (Confirm Delete)
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Mobile Overlay */}
      {isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-20 md:hidden"
          onClick={() => setIsSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <motion.aside 
        initial={false}
        animate={{ width: isSidebarOpen ? 260 : 80 }}
        className={cn(
          "bg-white border-r border-slate-200 flex flex-col z-30 h-full fixed md:relative",
          isSidebarOpen ? "translate-x-0" : "-translate-x-full md:translate-x-0",
          "transition-transform duration-300"
        )}
      >
        <div className="p-6 flex items-center justify-between">
          <div className={cn("flex items-center gap-3 overflow-hidden", !isSidebarOpen && "hidden")}>
            <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center text-white font-bold">W</div>
            <span className="font-bold text-xl tracking-tight">WIBT</span>
          </div>
          <button 
            onClick={() => setIsSidebarOpen(!isSidebarOpen)}
            className="p-2 hover:bg-slate-100 rounded-lg transition-colors hidden md:block"
          >
            {isSidebarOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
          <button 
            onClick={() => setIsSidebarOpen(false)}
            className="p-2 hover:bg-slate-100 rounded-lg transition-colors md:hidden"
          >
            <X size={20} />
          </button>
        </div>

        <nav className="flex-1 px-4 space-y-2 mt-4">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => {
                setActiveView(item.id as View);
                if (window.innerWidth < 768) setIsSidebarOpen(false);
              }}
              className={cn(
                "w-full flex items-center gap-4 p-3 rounded-xl transition-all group relative",
                activeView === item.id 
                  ? "bg-indigo-50 text-indigo-600" 
                  : "text-slate-500 hover:bg-slate-100 hover:text-slate-900"
              )}
            >
              <item.icon size={22} className={cn(activeView === item.id ? "text-indigo-600" : "group-hover:scale-110 transition-transform")} />
              {isSidebarOpen && <span className="font-medium">{item.label}</span>}
              {activeView === item.id && (
                <motion.div 
                  layoutId="active-nav"
                  className="absolute left-0 w-1 h-6 bg-indigo-600 rounded-r-full"
                />
              )}
            </button>
          ))}
        </nav>

        <div className="p-4 border-t border-slate-100">
          <div className={cn("flex items-center gap-3 p-2", !isSidebarOpen && "justify-center")}>
            <div className="w-10 h-10 rounded-full bg-slate-200 flex items-center justify-center overflow-hidden shrink-0">
              {currentUserDoc?.photoURL || user?.photoURL ? (
                <img src={currentUserDoc?.photoURL || user?.photoURL} alt={currentUserDoc?.name || user?.displayName || 'User'} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
              ) : (
                <User size={20} className="text-slate-400" />
              )}
            </div>
            {isSidebarOpen && (
              <div className="flex flex-col overflow-hidden flex-1">
                <span className="text-sm font-semibold truncate">
                  {(() => {
                    const fullName = currentUserDoc?.name || user?.displayName || 'Warehouse Admin';
                    if (fullName === 'Warehouse Admin' || fullName === 'User') return fullName;
                    const parts = fullName.trim().split(/\s+/);
                    if (parts.length > 1) {
                      return `${parts[0]} ${parts[parts.length - 1][0]}.`;
                    }
                    return fullName;
                  })()}
                </span>
                <span className="text-xs text-slate-500 truncate">{user?.email}</span>
              </div>
            )}
            {isSidebarOpen && (
              <div className="flex flex-col gap-1 shrink-0">
                <button 
                  onClick={handleForceSync}
                  className="p-2 text-slate-400 hover:text-indigo-500 hover:bg-indigo-50 rounded-lg transition-all"
                  title="Sync App (Clear Cache)"
                >
                  <RefreshCw size={18} />
                </button>
                <button 
                  onClick={handleLogout}
                  className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-all"
                  title="Logout"
                >
                  <LogOut size={18} />
                </button>
              </div>
            )}
          </div>
        </div>
      </motion.aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-2 md:px-6 z-10 shrink-0">
          <div className="flex items-center gap-1.5 md:gap-4 flex-1 min-w-0 max-w-xl">
            <button 
              className="md:hidden p-1.5 text-slate-500 hover:bg-slate-100 rounded-lg shrink-0"
              onClick={() => setIsSidebarOpen(true)}
            >
              <Menu size={20} />
            </button>
            <div className="md:hidden flex items-center gap-2 cursor-pointer shrink-0" onClick={() => setActiveView('profile')}>
              <div className="w-8 h-8 rounded-full bg-slate-200 flex items-center justify-center overflow-hidden shrink-0">
                {currentUserDoc?.photoURL || user?.photoURL ? (
                  <img src={currentUserDoc?.photoURL || user?.photoURL} alt="Profile" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                ) : (
                  <User size={16} className="text-slate-400" />
                )}
              </div>
              <span className="text-sm font-semibold truncate max-w-[90px] xs:max-w-[130px] text-slate-800">
                {(() => {
                  const fullName = currentUserDoc?.name || user?.displayName || 'User';
                  if (fullName === 'User') return fullName;
                  const parts = fullName.trim().split(/\s+/);
                  if (parts.length > 1) {
                    return `${parts[0]} ${parts[parts.length - 1][0]}.`;
                  }
                  return fullName;
                })()}
              </span>
            </div>
            
            <div className="hidden sm:flex flex-col">
              <h1 className="text-xl font-bold tracking-tight text-slate-900">
                {activeView === 'dashboard' && (isAdmin ? 'Warehouse Overview' : 'My Dashboard')}
                {activeView === 'inventory' && 'Inventory Management'}
                {activeView === 'borrowing' && 'Borrowing & Tracking'}
                {activeView === 'history' && 'Activity History'}
                {activeView === 'users' && 'User Management'}
                {activeView === 'deleted_logs' && 'Deleted Records Logs'}
                {activeView === 'settings' && 'System Settings'}
                {activeView === 'messages' && 'All Notifications & Messages'}
                {activeView === 'profile' && 'My Profile'}
              </h1>
              <p className="text-xs text-slate-500">
                {activeView === 'dashboard' && (isAdmin ? 'Real-time tracking and inventory metrics.' : 'Track your borrowed items and make new requests.')}
                {activeView === 'inventory' && 'Manage stock levels, locations, and status.'}
                {activeView === 'borrowing' && 'Monitor active loans and return schedules.'}
                {activeView === 'history' && 'Audit trail of all warehouse operations.'}
                {activeView === 'users' && 'Manage roles, permissions, and invite users.'}
                {activeView === 'deleted_logs' && 'History and reason for deleted records.'}
                {activeView === 'settings' && 'Configure warehouse parameters and organizational units.'}
                {activeView === 'messages' && 'View all system notifications and reminders.'}
                {activeView === 'profile' && 'Manage your personal information and settings.'}
              </p>
            </div>
          </div>
          
          <div className="flex items-center gap-1.5 md:gap-4 shrink-0">
            {isAdmin && (
              <button 
                onClick={runDailyReminderCheck}
                className="hidden md:flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold bg-amber-100 text-amber-700 rounded-lg hover:bg-amber-200 transition-colors"
                title="Simulate daily cron job to check for due items"
              >
                <Clock size={14} />
                Run Daily Check
              </button>
            )}
            
            <button 
              onClick={async (e) => {
                const icon = e.currentTarget.querySelector('svg');
                if (icon) icon.classList.add('animate-spin');
                try {
                  if ('serviceWorker' in navigator) {
                    const registrations = await navigator.serviceWorker.getRegistrations();
                    for (let registration of registrations) {
                      await registration.unregister();
                    }
                  }
                  if ('caches' in window) {
                    const keys = await caches.keys();
                    for (const key of keys) {
                      await caches.delete(key);
                    }
                  }
                } finally {
                  window.location.reload();
                }
              }}
              className="flex items-center gap-1.5 px-2 md:px-3 py-1.5 text-xs font-bold bg-indigo-50 text-indigo-700 rounded-lg hover:bg-indigo-100 transition-colors shrink-0"
              title="Update App"
            >
              <RefreshCw size={16} />
              <span className="hidden sm:inline">Update App</span>
            </button>
            
            <div className="relative shrink-0" ref={notificationsRef}>
              <button 
                onClick={() => setShowNotifications(!showNotifications)}
                className="p-2 text-slate-500 hover:bg-slate-100 rounded-lg relative"
              >
                <Bell size={20} />
                {notifications.filter(n => !n.read).length > 0 && (
                  <span className="absolute top-1.5 right-1.5 w-2.5 h-2.5 bg-red-500 rounded-full border-2 border-white"></span>
                )}
              </button>
              
              <AnimatePresence>
                {showNotifications && (
                  <motion.div 
                    initial={{ opacity: 0, y: 10, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: 10, scale: 0.95 }}
                    className="absolute right-0 mt-2 w-80 bg-white rounded-2xl shadow-xl border border-slate-100 z-50 overflow-hidden"
                  >
                    <div className="p-4 border-b border-slate-100 flex flex-col gap-2 bg-slate-50/50">
                      <div className="flex items-center justify-between">
                        <h3 className="font-bold text-slate-800">Notifications</h3>
                        <span className="text-xs font-bold text-indigo-600 bg-indigo-50 px-2 py-1 rounded-full">
                          {notifications.filter(n => !n.read).length} New
                        </span>
                      </div>
                      {isAdmin && notifications.length > 0 && (
                        <div className="flex justify-between items-center mt-1">
                          <span className="text-[10px] text-slate-400">Long press to delete individual</span>
                          <button 
                            onClick={async () => {
                              if (confirm("ຕ້ອງການລຶບແຈ້ງເຕືອນທັງໝົດ ຫຼື ບໍ່? (Clear all notifications?)")) {
                                try {
                                  const promises = notifications.map(n => deleteDoc(doc(db, 'notifications', n.id)));
                                  await Promise.all(promises);
                                } catch (e) {
                                  console.error("Error clearing notifications", e);
                                }
                              }
                            }}
                            className="text-xs text-red-600 hover:text-red-700 font-bold px-2 py-1 bg-red-50 hover:bg-red-100 rounded transition-colors"
                          >
                            Clear All
                          </button>
                        </div>
                      )}
                    </div>
                    <div className="max-h-[400px] overflow-y-auto custom-scrollbar">
                      {notifications.length === 0 ? (
                        <div className="p-8 text-center text-slate-500 text-sm">
                          No notifications yet.
                        </div>
                      ) : (
                        <div className="divide-y divide-slate-50">
                          {notifications.map(notification => (
                            <div 
                              key={notification.id} 
                              className={cn(
                                "p-4 hover:bg-slate-50 transition-colors cursor-pointer select-none",
                                !notification.read ? "bg-indigo-50/30" : ""
                              )}
                              onMouseDown={() => startLongPress(notification)}
                              onMouseUp={cancelLongPress}
                              onMouseLeave={cancelLongPress}
                              onTouchStart={() => startLongPress(notification)}
                              onTouchEnd={cancelLongPress}
                              onClick={async () => {
                                if (isLongPressRef.current) return;
                                if (!notification.read) {
                                  try {
                                    await updateDoc(doc(db, 'notifications', notification.id), { read: true });
                                  } catch (err) {
                                    console.error("Failed to mark as read", err);
                                  }
                                }
                                if (notification.linkToRecordId) {
                                  setShowNotifications(false);
                                  setActiveView('borrowing');
                                  setBorrowSelectedRecordId(notification.linkToRecordId);
                                }
                              }}
                            >
                              <div className="flex gap-3">
                                <div className={cn(
                                  "w-8 h-8 rounded-full flex items-center justify-center shrink-0 mt-0.5",
                                  notification.type === 'warning' ? "bg-amber-100 text-amber-600" :
                                  notification.type === 'error' ? "bg-red-100 text-red-600" :
                                  "bg-indigo-100 text-indigo-600"
                                )}>
                                  {notification.type === 'warning' ? <AlertTriangle size={14} /> : <Bell size={14} />}
                                </div>
                                <div>
                                  <h4 className={cn("text-sm", !notification.read ? "font-bold text-slate-900" : "font-medium text-slate-700")}>
                                    {notification.title}
                                  </h4>
                                  <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                                    {notification.message}
                                  </p>
                                  <p className="text-[10px] text-slate-400 mt-2 font-medium uppercase tracking-wider">
                                    {notification.createdAt ? format(notification.createdAt.toDate(), 'MMM dd, yyyy HH:mm') : 'Just now'}
                                  </p>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
            
            <div className="h-8 w-px bg-slate-200 mx-1 md:mx-2"></div>
            <button 
              onClick={() => setIsFormOpen(true)}
              className="flex items-center gap-1.5 md:gap-2 bg-indigo-600 text-white px-2.5 md:px-4 py-1.5 md:py-2 rounded-xl hover:bg-indigo-700 transition-all shadow-sm shadow-indigo-200"
            >
              <Plus size={18} />
              <span className="text-sm font-semibold hidden sm:inline">Borrow Request</span>
            </button>
          </div>
        </header>

        {/* View Content */}
        <div className="flex-1 overflow-y-auto p-2 md:p-4 pb-20 md:pb-4 custom-scrollbar">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeView}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
              className="max-w-7xl mx-auto"
            >
              {activeView === 'dashboard' && <DashboardView units={units} departments={departments} stats={stats} isAdmin={isAdmin} appUsers={appUsers} allBorrows={borrowRecords} userBorrows={borrowRecords.filter(r => r.borrowerEmail?.toLowerCase() === user?.email?.toLowerCase())} onNewRequest={() => setIsFormOpen(true)} onNavigate={(view, subParam) => { setActiveView(view as View); if (subParam === 'pending_approval') setBorrowStatusFilter(subParam); }} />}
              {activeView === 'inventory' && (
                <InventoryView 
                  searchQuery={searchQuery}
                  setSearchQuery={setSearchQuery}
                  onImport={handleImportExcel}
                  onImportFromServer={handleImportFromServerFile}
                  isImporting={isImporting}
                  isAdmin={isAdmin}
                  isSuperAdmin={isSuperAdmin}
                  onDelete={handleDeleteItem}
                  onDeleteAll={handleDeleteAllInventory}
                  isDeletingAll={isDeletingAll}
                  itemsPerPage={itemsPerPage}
                  onEdit={(item) => {
                    setSelectedItem(item);
                    setItemFormPhotos(item.photos || []);
                    setIsItemFormOpen(true);
                  }}
                  onAdd={() => {
                    setSelectedItem(null);
                    setItemFormPhotos([]);
                    setIsItemFormOpen(true);
                  }}
                />
              )}
              {activeView === 'borrowing' && (
                <BorrowingView 
                  records={isAdmin ? borrowRecords : borrowRecords.filter(r => r.borrowerEmail?.toLowerCase() === user?.email?.toLowerCase())} 
                  isAdmin={isAdmin}
                  isSuperAdmin={isSuperAdmin}
                  currentUserEmail={user?.email?.toLowerCase() || ''}
                  onDelete={handleDeleteBorrowRecord}
                  onToggleDeactivate={handleToggleDeactivate}
                  onViewMessages={() => setActiveView('messages')}
                  initialStatusFilter={borrowStatusFilter}
                  clearInitialStatusFilter={() => setBorrowStatusFilter('')}
                  initialSelectedRecordId={borrowSelectedRecordId}
                  clearInitialSelectedRecordId={() => setBorrowSelectedRecordId('')}
                  appUsers={appUsers}
                />
              )}
              {activeView === 'history' && <HistoryView logs={activityLogs} />}
              {activeView === 'users' && (
                <UsersView 
                  users={appUsers} 
                  units={units}
                  departments={departments}
                  isSuperAdmin={isSuperAdmin}
                  onUpdateRole={handleUpdateUserRole} 
                  onAddUser={async (userData) => {
                    try {
                      // Check if already invited
                      const existingQ = query(collection(db, 'users'), where('email', '==', userData.email.toLowerCase()));
                      const existingR = await getDocs(existingQ);
                      if (!existingR.empty) {
                        alert("This email is already registered or invited.");
                        return;
                      }

                      await addDoc(collection(db, 'users'), {
                        email: userData.email.toLowerCase(),
                        role: userData.role,
                        firstName: userData.firstName || '',
                        lastName: userData.lastName || '',
                        name: `${userData.firstName || ''} ${userData.lastName || ''}`.trim(),
                        displayName: `${userData.firstName || ''} ${userData.lastName || ''}`.trim(),
                        unitId: userData.unitId || '',
                        departmentId: userData.departmentId || '',
                        createdAt: serverTimestamp(),
                        isPreCreated: true,
                        status: 'active'
                      });
                      
                      const inviteLink = window.location.origin;
                      const subject = encodeURIComponent("Invitation to join the Application");
                      const body = encodeURIComponent(`You have been invited to join the Application as a ${userData.role}.\n\nPlease register here: ${inviteLink}`);
                      window.open(`mailto:${userData.email}?subject=${subject}&body=${body}`, '_blank');
                    } catch (error) {
                      console.error("Failed to add user:", error);
                      alert("Failed to add user.");
                    }
                  }}
                  onDeleteUser={async (id) => {
                    if (!isSuperAdmin) return;
                    
                    if (!window.confirm("ແນ່ໃຈຫລືບໍ່ວ່າຕ້ອງການລຶບຜູ້ໃຊ້ນີ້? / Are you sure you want to delete this user?")) return;
                    
                    let reason = '';
                    try { reason = window.prompt("ກະລຸນາປ້ອນເຫດຜົນໃນການລຶບຜູ້ໃຊ້ / Reason for delete:") || ''; } catch(e) {}
                    if (!reason || reason.trim() === '') {
                      reason = "Deleted by admin";
                    }
                    
                    try {
                      const userDoc = appUsers.find(u => u.id === id);
                      await deleteDoc(doc(db, 'users', id));
                      await logActivity('Delete User', `ລຶບຜູ້ໃຊ້ ${userDoc?.email} ຍ້ອນ: ${reason}`);
                    } catch (error) {
                       alert("Failed to delete user.");
                    }
                  }}
                  onUpdateUser={async (id, data, reason = "Update User Profile") => {
                    try {
                      const userDoc = appUsers.find(u => u.id === id);
                      const oldEmail = userDoc?.email;
                      const newEmail = data.email;
                      let changeDetails = '';
                      if (oldEmail && newEmail && oldEmail !== newEmail) {
                        changeDetails = `ປ່ຽນອີເມລຈາກ ${oldEmail} ເປັນ ${newEmail}. `;
                        
                        // Cascade update borrow_records
                        console.log("Updating borrow_records...");
                        try {
                          const borrowQuery = query(collection(db, 'borrow_records'), where('borrowerEmail', '==', oldEmail));
                          const borrowSnap = await getDocs(borrowQuery);
                          const numBorrows = borrowSnap.docs.length;
                          if (numBorrows > 0) {
                            for (const docSnap of borrowSnap.docs) {
                              await updateDoc(doc(db, 'borrow_records', docSnap.id), { borrowerEmail: newEmail });
                            }
                            changeDetails += `(ອັບເດດ ${numBorrows} ປະຫວັດການຢືມ) `;
                          }
                        } catch (e: any) {
                          console.error("Failed on borrow_records update:", e);
                          throw new Error("borrow_records update failed: " + e.message);
                        }

                        // Cascade update notifications
                        console.log("Updating notifications...");
                        try {
                          const notifQuery = query(collection(db, 'notifications'), where('userId', '==', oldEmail));
                          const notifSnap = await getDocs(notifQuery);
                          const numNotifs = notifSnap.docs.length;
                          if (numNotifs > 0) {
                            for (const docSnap of notifSnap.docs) {
                              await updateDoc(doc(db, 'notifications', docSnap.id), { userId: newEmail });
                            }
                          }
                        } catch (e: any) {
                          console.error("Failed on notifications update:", e);
                          throw new Error("notifications update failed: " + e.message);
                        }
                      }
                      
                      console.log("Updating user document...", id, data);
                      try {
                        await updateDoc(doc(db, 'users', id), data);
                      } catch (e: any) {
                        console.error("Failed on user document update:", e);
                        throw new Error("users document update failed: " + e.message);
                      }
                      
                      console.log("Adding activity log...");
                      try {
                        await logActivity('Update User Profile', `${changeDetails}ເຫດຜົນ: ${reason}`);
                      } catch (e: any) {
                        console.error("Failed to add activity log:", e);
                      }
                      
                      alert("ອັບເດດຂໍ້ມູນສຳເລັດ (Profile updated successfully)!");
                    } catch (e: any) {
                      alert("Failed to update user: " + (e.message || String(e)));
                      console.error("Update User Error:", e);
                    }
                  }}
                  onApproveUser={async (id) => {
                    try {
                      const userDoc = appUsers.find(u => u.id === id);
                      await updateDoc(doc(db, 'users', id), { status: 'active' });
                      await logActivity('Approve User Registration', `ອະນຸມັດຜູ້ໃຊ້ໃໝ່: ${userDoc?.email}`);
                    } catch (e) {
                      console.error("Failed to approve user.", e);
                    }
                  }}
                />
              )}
              {activeView === 'deleted_logs' && <DeletedLogsView />}
              {activeView === 'settings' && (
                <SettingsView 
                  units={units}
                  departments={departments}
                  isSuperAdmin={isSuperAdmin}
                  onAddUnit={handleAddUnit}
                  onUpdateUnit={handleUpdateUnit}
                  onDeleteUnit={handleDeleteUnit}
                  onAddDept={handleAddDept}
                  onUpdateDept={handleUpdateDept}
                  onDeleteDept={handleDeleteDept}
                  itemsPerPage={itemsPerPage}
                  onItemsPerPageChange={handleItemsPerPageChange}
                  notificationSettings={notificationSettings}
                  onUpdateNotificationSettings={async (settings) => {
                    setNotificationSettings(settings); // Optimistic UI
                    await setDoc(doc(db, 'settings', 'notifications'), settings, { merge: true });
                  }}
                  workflowSettings={workflowSettings}
                  onUpdateWorkflowSettings={async (settings) => {
                    setWorkflowSettings(settings);
                    await setDoc(doc(db, 'settings', 'workflow'), settings, { merge: true });
                  }}
                />
              )}
              {activeView === 'messages' && (
                <MessagesView 
                  notifications={notifications} 
                  isAdmin={isAdmin}
                  isSuperAdmin={isSuperAdmin}
                  appUsers={appUsers}
                  onNavigateToRecord={(recordId) => {
                    setActiveView('borrowing');
                    setBorrowSelectedRecordId(recordId);
                  }}
                />
              )}
              {activeView === 'profile' && (
                <ProfileView
                  user={user}
                  userDoc={currentUserDoc}
                  units={units}
                  departments={departments}
                  userBorrows={borrowRecords.filter(r => r.borrowerEmail?.toLowerCase() === user?.email?.toLowerCase())}
                  appUsers={appUsers}
                  onLogout={handleLogout}
                />
              )}
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Bottom Mobile Navigation */}
        <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 z-30 flex items-center justify-around pb-safe">
          {navItems.slice(0, 5).map(item => (
            <button
              key={item.id}
              onClick={() => setActiveView(item.id as View)}
              className={cn(
                "flex flex-col items-center justify-center p-2 min-w-[64px]",
                activeView === item.id ? "text-indigo-600" : "text-slate-500 hover:text-slate-900"
              )}
            >
              <item.icon size={20} className={cn(activeView === item.id && "scale-110 duration-200")} />
              <span className="text-[10px] mt-1 font-medium truncate w-full text-center">{item.label}</span>
            </button>
          ))}
        </div>
      </main>

      {/* Modals */}
      {confirmDialog && (
        <ConfirmModal
          isOpen={confirmDialog.isOpen}
          title={confirmDialog.title}
          message={confirmDialog.message}
          requireReason={confirmDialog.requireReason}
          onConfirm={confirmDialog.onConfirm}
          onCancel={() => setConfirmDialog(null)}
        />
      )}

      {/* Inventory Item Form Modal */}
      <AnimatePresence>
        {isItemFormOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => {
                setIsItemFormOpen(false);
                setSelectedItem(null);
              }}
              className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm"
            />
            <motion.form 
              onSubmit={handleSaveItem}
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="bg-white w-full max-w-2xl max-h-[90vh] rounded-3xl shadow-2xl overflow-hidden flex flex-col relative z-10"
            >
              <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-white shrink-0 z-10">
                <h2 className="text-xl font-bold">{selectedItem ? 'Edit Inventory Item' : 'Add New Inventory Item'}</h2>
                <button type="button" onClick={() => {
                  setIsItemFormOpen(false);
                  setSelectedItem(null);
                }} className="p-2 hover:bg-slate-100 rounded-full transition-colors">
                  <X size={20} />
                </button>
              </div>
              
              <div className="flex-1 overflow-y-auto p-8 custom-scrollbar space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-500 uppercase">Material ID</label>
                    <input name="id" type="text" defaultValue={selectedItem?.id || ''} placeholder="ID-000" className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-indigo-500 transition-all disabled:opacity-50" disabled={!!selectedItem} required />
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-500 uppercase">Material Name</label>
                    <input name="name" type="text" defaultValue={selectedItem?.name || ''} placeholder="Item Name" className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-indigo-500 transition-all" required />
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-500 uppercase">Base Unit (UOM)</label>
                    <input name="uom" type="text" defaultValue={selectedItem?.uom || ''} placeholder="EA, PCS, etc." className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-indigo-500 transition-all" required />
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-500 uppercase">Category</label>
                    <input name="category" type="text" defaultValue={selectedItem?.category || ''} placeholder="General" className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-indigo-500 transition-all" required />
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-500 uppercase">SLOC</label>
                    <input name="sloc" type="text" defaultValue={selectedItem?.sloc || ''} placeholder="WH01" className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-indigo-500 transition-all" required />
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-500 uppercase">Bin Location</label>
                    <input name="bin" type="text" defaultValue={selectedItem?.bin || ''} placeholder="A-01-01" className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-indigo-500 transition-all" required />
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-500 uppercase">Brand</label>
                    <input name="brand" type="text" defaultValue={selectedItem?.brand || ''} placeholder="Brand Name" className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-indigo-500 transition-all" required />
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-500 uppercase">Mfr. Part Number</label>
                    <input name="mfrPartNumber" type="text" defaultValue={selectedItem?.mfrPartNumber || ''} placeholder="PN-000" className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-indigo-500 transition-all" required />
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-500 uppercase">Functional System</label>
                    <input name="functionalSystem" type="text" defaultValue={selectedItem?.functionalSystem || ''} placeholder="System Name" className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-indigo-500 transition-all" required />
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-500 uppercase">Status</label>
                    <select name="status" defaultValue={selectedItem?.status || 'available'} className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-indigo-500 transition-all" required>
                      <option value="available">Available</option>
                      <option value="low-stock">Low Stock</option>
                      <option value="borrowed">Borrowed</option>
                      <option value="maintenance">Maintenance</option>
                    </select>
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-500 uppercase">Current Stock</label>
                    <input name="quantity" type="number" defaultValue={selectedItem?.quantity || 0} className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-indigo-500 transition-all" required />
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-500 uppercase">Min Stock Level</label>
                    <input name="minQuantity" type="number" defaultValue={selectedItem?.minQuantity || 0} className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-indigo-500 transition-all" required />
                  </div>
                </div>
                
                {/* Photo Upload Section */}
                <div className="space-y-2 mt-4">
                  <label className="text-xs font-bold text-slate-500 uppercase">Photos (Max 3 images)</label>
                  <div className="flex flex-wrap gap-2">
                    {itemFormPhotos.map((photo, pIdx) => (
                      <div key={pIdx} className="relative w-20 h-20 rounded-xl overflow-hidden border border-slate-200">
                        <img src={photo} alt="" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                        <button 
                          type="button" 
                          onClick={() => {
                            const newPhotos = [...itemFormPhotos];
                            newPhotos.splice(pIdx, 1);
                            setItemFormPhotos(newPhotos);
                          }}
                          className="absolute top-0 right-0 bg-red-500 text-white w-6 h-6 flex items-center justify-center rounded-bl-xl hover:bg-red-600 transition-colors"
                        >
                          <X size={14} />
                        </button>
                      </div>
                    ))}
                    {itemFormPhotos.length < 3 && (
                      <div className="flex gap-2">
                        <label className="w-20 h-20 border-2 border-dashed border-slate-300 rounded-xl flex flex-col items-center justify-center text-slate-500 hover:text-indigo-600 hover:border-indigo-300 hover:bg-indigo-50 cursor-pointer transition-all">
                          <Camera size={20} />
                          <span className="text-[10px] font-medium mt-1">Camera</span>
                          <input 
                            type="file" 
                            accept="image/*" 
                            capture="environment"
                            className="hidden" 
                            onChange={async (e) => {
                              if (!e.target.files) return;
                              const newPhotos = await processImageFiles(e.target.files, 3 - itemFormPhotos.length);
                              setItemFormPhotos([...itemFormPhotos, ...newPhotos]);
                              e.target.value = ''; // Reset input
                            }}
                          />
                        </label>
                        <label className="w-20 h-20 border-2 border-dashed border-slate-300 rounded-xl flex flex-col items-center justify-center text-slate-500 hover:text-indigo-600 hover:border-indigo-300 hover:bg-indigo-50 cursor-pointer transition-all">
                          <ImageIcon size={20} />
                          <span className="text-[10px] font-medium mt-1">Gallery</span>
                          <input 
                            type="file" 
                            accept="image/*" 
                            multiple 
                            className="hidden" 
                            onChange={async (e) => {
                              if (!e.target.files) return;
                              const newPhotos = await processImageFiles(e.target.files, 3 - itemFormPhotos.length);
                              setItemFormPhotos([...itemFormPhotos, ...newPhotos]);
                              e.target.value = ''; // Reset input
                            }}
                          />
                        </label>
                      </div>
                    )}
                  </div>
                </div>

                <div className="space-y-1 mt-4">
                  <label className="text-xs font-bold text-slate-500 uppercase">Description</label>
                  <textarea name="description" defaultValue={selectedItem?.description || ''} rows={3} className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-indigo-500 transition-all resize-none" placeholder="Item details..."></textarea>
                </div>
              </div>

              <div className="p-6 border-t border-slate-100 bg-slate-50 flex items-center justify-end gap-3">
                <button type="button" onClick={() => {
                  setIsItemFormOpen(false);
                  setSelectedItem(null);
                }} className="px-6 py-2.5 text-slate-600 font-bold hover:bg-slate-100 rounded-xl transition-all">Cancel</button>
                <button type="submit" className="px-8 py-2.5 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-200">
                  {selectedItem ? 'Update Item' : 'Save Item'}
                </button>
              </div>
            </motion.form>
          </div>
        )}
      </AnimatePresence>

      {/* Borrow Request Form Modal */}
      <AnimatePresence>
        {isFormOpen && (
          <BorrowRequestForm 
            user={currentUserDoc}
            units={units}
            departments={departments}
            appUsers={appUsers}
            workflowSettings={workflowSettings}
            onClose={() => setIsFormOpen(false)}
            onSuccess={() => { setIsFormOpen(false); }}
          />
        )}
      </AnimatePresence>
    </div>
  );
}

// --- Sub-Views ---

function DashboardView({ units = [], departments = [], stats, isAdmin, appUsers = [], userBorrows, allBorrows = [], onNewRequest, onNavigate }: { units?: Unit[], departments?: Department[], stats: any, isAdmin: boolean, appUsers?: any[], userBorrows: BorrowRecord[], allBorrows?: BorrowRecord[], onNewRequest: () => void, onNavigate?: (view: string, subParam?: string) => void }) {
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;
  
  const totalPages = Math.ceil(userBorrows.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const currentBorrows = userBorrows.slice(startIndex, startIndex + itemsPerPage);

  const chartData = useMemo(() => {
    if (!isAdmin) return [];
    
    // Get last 7 days including today
    const days = Array.from({ length: 7 }).map((_, i) => subDays(startOfDay(new Date()), 6 - i));
    
    return days.map(day => {
      const dayStr = format(day, 'yyyy-MM-dd');
      
      const borrowsOnDay = allBorrows.filter(record => {
        // match records based on borrowDate
        if (!record.borrowDate) return false;
        try {
          return format(parseISO(record.borrowDate), 'yyyy-MM-dd') === dayStr;
        } catch(e) {
          return record.borrowDate.startsWith(dayStr);
        }
      });
      
      const itemsCount = borrowsOnDay.reduce((acc, curr) => acc + curr.items.reduce((sum, item) => sum + item.borrowQty, 0), 0);
      
      return {
        name: format(day, 'EEE'), // Mon, Tue, etc
        items: itemsCount,
        borrows: borrowsOnDay.length,
      };
    });
  }, [allBorrows, isAdmin]);

  const usersByUnit = useMemo(() => {
    const counts: Record<string, number> = {};
    (appUsers || []).forEach(u => {
      const uId = u.unitId || 'unknown';
      counts[uId] = (counts[uId] || 0) + 1;
    });
    return Object.entries(counts).map(([unitId, count]) => {
      const unit = units.find(unit => unit.id === unitId);
      return {
        name: unit?.name || 'Unknown Unit',
        count
      };
    }).sort((a, b) => b.count - a.count);
  }, [appUsers, units]);

  const topBorrowedItems = useMemo(() => {
    const itemCounts: Record<string, {name: string, count: number}> = {};
    if (!isAdmin) return [];
    
    allBorrows.forEach(record => {
      record.items?.forEach(item => {
        const itemId = item.materialId || 'unknown';
        if (!itemCounts[itemId]) {
          itemCounts[itemId] = { name: item.materialDescription || itemId, count: 0 };
        }
        itemCounts[itemId].count += 1; 
      });
    });
    return Object.values(itemCounts)
      .sort((a, b) => b.count - a.count)
      .slice(0, 10);
  }, [allBorrows, isAdmin]);

  const topBorrowers = useMemo(() => {
    const userCounts: Record<string, {name: string, count: number}> = {};
    if (!isAdmin) return [];

    allBorrows.forEach(record => {
        const key = record.borrowerEmail || 'Unknown';
        if (!userCounts[key]) {
             userCounts[key] = { name: formatUserName(key, appUsers), count: 0 };
        }
        userCounts[key].count += 1;
    });
    return Object.values(userCounts)
      .sort((a, b) => b.count - a.count)
      .slice(0, 10);
  }, [allBorrows, isAdmin, appUsers]);

  if (!isAdmin) {
    return (
      <div className="space-y-6">
        <div className="flex gap-3">
          <button 
            onClick={() => onNavigate?.('inventory')}
            className="flex-1 px-4 py-3 bg-indigo-600 text-white font-bold rounded-2xl flex items-center justify-center gap-2 shadow-sm text-sm"
          >
            <Package size={18} />
            <span className="hidden sm:inline">Browse</span> Items
          </button>
          
          <button 
            onClick={onNewRequest}
            className="flex-1 px-4 py-3 bg-white border border-indigo-200 text-indigo-700 font-bold rounded-2xl flex items-center justify-center gap-2 shadow-sm text-sm"
          >
            <Plus size={18} />
            <span className="hidden sm:inline">Direct</span> Borrow
          </button>
        </div>

        <div className="grid grid-cols-3 gap-3">
          <StatCard title="In Uses" value={userBorrows.filter(r => r.status === 'active').length} icon={Package} color="indigo" onClick={() => onNavigate?.('borrowing')} />
          <StatCard title="Overdue" value={userBorrows.filter(r => r.status === 'overdue').length} icon={AlertTriangle} color="red" onClick={() => onNavigate?.('borrowing')} />
          <StatCard title="Returned" value={userBorrows.filter(r => r.status === 'returned').length} icon={CheckCircle2} color="emerald" onClick={() => onNavigate?.('borrowing')} />
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="p-6 border-b border-slate-100">
            <h3 className="text-lg font-bold">My Recent Borrows</h3>
          </div>
          <div className="p-0">
            {userBorrows.length === 0 ? (
              <div className="p-12 text-center text-slate-500">
                <Package size={48} className="mx-auto mb-4 opacity-20" />
                <p>You haven't borrowed any items yet.</p>
              </div>
            ) : (
              <div className="p-4 grid grid-cols-1 gap-3">
                {currentBorrows.map(record => (
                  <div 
                    key={record.id} 
                    className="bg-white border border-slate-200 shadow-sm rounded-xl p-4 hover:border-indigo-300 hover:shadow-md transition-all cursor-pointer group"
                    onClick={() => onNavigate?.('borrowing')}
                  >
                    <div className="flex flex-col gap-2">
                      <div className="flex justify-between items-start gap-3">
                        <div className="flex-1">
                          <p className="text-xs text-slate-400 uppercase tracking-wider font-bold mb-0.5">ລາຍການຢືມ (Items)</p>
                          <h4 className="font-bold text-slate-900 group-hover:text-indigo-600 transition-colors">
                            {record.items?.map(i => i.materialDescription).join(', ') || 'Unknown Items'}
                          </h4>
                          <p className="text-xs text-slate-500 mt-0.5">
                            Qty: {(record.items?.reduce((acc, i) => acc + i.borrowQty, 0) || 0).toLocaleString()} • {record.purpose}
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="text-xs text-slate-400 uppercase tracking-wider font-bold mb-0.5">ໄອດີ (ID)</p>
                          <span className="font-mono text-xs font-bold text-slate-600 px-2 py-1 bg-slate-100 rounded-md whitespace-nowrap">
                            {record.requestNumber || (record.id ? record.id.slice(0,8).toUpperCase() : 'N/A')}
                          </span>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4 mt-2 pt-3 border-t border-slate-100">
                        <div>
                          <p className="text-xs text-slate-400 uppercase tracking-wider font-bold mb-0.5">ວັນທີຢືມ (Borrow)</p>
                          <p className="text-sm text-slate-700 font-medium">
                            {format(parseISO(record.borrowDate), 'MMM dd, yyyy HH:mm')}
                          </p>
                        </div>
                        <div>
                          <p className="text-xs text-slate-400 uppercase tracking-wider font-bold mb-0.5">ວັນທີສົ່ງຄືນ (Return)</p>
                          <p className={cn("text-sm font-medium", record.status === 'overdue' ? "text-red-600 font-bold" : "text-slate-700")}>
                            {format(parseISO(record.plannedReturnDate), 'MMM dd, yyyy HH:mm')}
                          </p>
                        </div>
                      </div>

                      <div className="mt-2 pt-3 border-t border-slate-100 flex items-center justify-between">
                        <p className="text-xs text-slate-400 uppercase tracking-wider font-bold">ສະຖານະ (Status)</p>
                        <span className={cn(
                          "text-xs px-2.5 py-1 rounded-full font-bold uppercase w-fit inline-flex items-center gap-1.5",
                          record.status === 'deactivated' ? "bg-amber-100 text-amber-700" :
                          (record.borrowerReturnAcknowledge && record.status !== 'returned') ? "bg-orange-100 text-blue-900" :
                          record.status === 'overdue' || (record.status === 'active' && record.plannedReturnDate && new Date() > new Date(record.plannedReturnDate)) ? "bg-red-100 text-red-700" : 
                          record.status === 'active' ? "bg-indigo-100 text-indigo-700" : "bg-emerald-100 text-emerald-700"
                        )}>
                          {record.status === 'returned' && <CheckCircle2 size={12} />}
                          {record.status !== 'returned' && !record.borrowerReturnAcknowledge && <Clock size={12} />}
                          {(record.borrowerReturnAcknowledge && record.status !== 'returned') && <AlertTriangle size={12} />}
                          {(record.borrowerReturnAcknowledge && record.status !== 'returned') ? 'Confirm Return' : record.status === 'active' ? 'In Uses' : record.status.charAt(0).toUpperCase() + record.status.slice(1)}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
            
            {userBorrows.length > 0 && totalPages > 1 && (
              <div className="p-4 border-t border-slate-100 flex items-center justify-between bg-slate-50">
                <button 
                  onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                  disabled={currentPage === 1}
                  className="px-4 py-2 border border-slate-200 bg-white rounded-xl text-sm font-bold text-slate-600 hover:bg-slate-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                >
                  Previous
                </button>
                <span className="text-sm text-slate-500 font-medium">Page {currentPage} of {totalPages}</span>
                <button 
                  onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                  disabled={currentPage === totalPages}
                  className="px-4 py-2 border border-slate-200 bg-white rounded-xl text-sm font-bold text-slate-600 hover:bg-slate-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                >
                  Next
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  const pieData = stats.pieData || [
    { name: 'Available', value: 0, color: '#4f46e5' },
  ];

  const pendingUsersCount = appUsers?.filter(u => u.status === 'pending').length || 0;
  const totalUsersCount = appUsers?.length || 0;
  
  const totalAllBorrows = allBorrows.length;
  const completionReturnedCount = allBorrows.filter(r => r.status === 'returned').length;
  const extendedReturningCount = allBorrows.filter(r => r.extensionRequest).length;
  const pendingBorrowsCount = allBorrows.filter(r => r.status !== 'returned' && !r.takingConfirmation).length;

  return (
    <div className="space-y-4">
      {stats.error && (
        <div className="bg-rose-50 border border-rose-200 text-rose-700 p-4 rounded-xl flex items-start gap-3">
          <AlertCircle className="w-5 h-5 shrink-0 mt-0.5" />
          <div className="text-sm">
            <p className="font-bold">Error loading warehouse statistics</p>
            <p className="mt-1">{stats.error}</p>
          </div>
        </div>
      )}
      
      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <StatCard 
          title="Total Unique Items" 
          value={stats.totalItems.toLocaleString()} 
          icon={Package} 
          trend={`${stats.totalQuantity.toLocaleString()} total units`} 
          color="indigo" 
          onClick={() => onNavigate?.('inventory')}
        />
        <StatCard 
          title="In Uses" 
          value={stats.activeBorrows.toLocaleString()} 
          icon={ArrowLeftRight} 
          trend="Current ongoing" 
          color="amber" 
          onClick={() => onNavigate?.('borrowing')}
        />
        <StatCard 
          title="New Borrowings / Pending" 
          value={pendingBorrowsCount.toLocaleString()} 
          icon={ArrowLeftRight} 
          trend="Needs Approval/Taking" 
          color="blue" 
          isAlert={pendingBorrowsCount > 0}
          onClick={() => onNavigate?.('borrowing', 'pending_approval')}
        />
        <StatCard 
          title="Overdue Items" 
          value={stats.overdue.toLocaleString()} 
          icon={Clock} 
          trend="Requires attention" 
          color="rose" 
          isAlert={stats.overdue > 0}
          onClick={() => onNavigate?.('borrowing')}
        />
        <StatCard 
          title="Total All Borrows" 
          value={totalAllBorrows.toLocaleString()} 
          icon={History} 
          trend="Lifetime records" 
          color="blue" 
          onClick={() => onNavigate?.('borrowing')}
        />
        <StatCard 
          title="Completion Returned" 
          value={completionReturnedCount.toLocaleString()} 
          icon={CheckCircle2} 
          trend="Successfully closed" 
          color="emerald" 
          onClick={() => onNavigate?.('borrowing')}
        />
        <StatCard 
          title="Extended Returning" 
          value={extendedReturningCount.toLocaleString()} 
          icon={AlertTriangle} 
          trend="Requested extensions" 
          color="amber" 
          onClick={() => onNavigate?.('borrowing')}
        />
        <StatCard 
          title="Total Users" 
          value={totalUsersCount.toLocaleString()} 
          icon={Users} 
          trend={`${appUsers?.filter(u => u.status === 'active').length || 0} active`} 
          color="indigo" 
          onClick={() => onNavigate?.('users')}
        />

      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm">
          <h3 className="font-semibold text-sm mb-4">Activity Trends (Last 7 Days)</h3>
          <div className="h-[200px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fill: '#94a3b8', fontSize: 10 }} dy={10} />
                <YAxis axisLine={false} tickLine={false} tick={{ fill: '#94a3b8', fontSize: 10 }} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#fff', borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)', fontSize: '12px' }}
                  cursor={{ fill: '#f8fafc' }}
                />
                <Bar dataKey="items" fill="#4f46e5" radius={[4, 4, 0, 0]} barSize={20} />
                <Bar dataKey="borrows" fill="#94a3b8" radius={[4, 4, 0, 0]} barSize={20} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="flex flex-col gap-4">
          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex flex-col min-h-[300px]">
            <h3 className="font-semibold text-sm mb-4">Inventory by ID Group</h3>
            <div className="flex-1 overflow-y-auto pr-2 space-y-3">
              <div className="grid grid-cols-3 gap-2 px-1 pb-2 border-b border-slate-100 text-xs font-bold text-slate-400 uppercase tracking-wider">
                <div>Prefix</div>
                <div className="text-right">Items</div>
                <div className="text-right">Max ID / Ends With</div>
              </div>
              {[
                { prefix: '2000', count: 79, maxId: '20000222', maxEnd: '0222' },
                { prefix: '2100', count: 28, maxId: '21000028', maxEnd: '0028' },
                { prefix: '2200', count: 227, maxId: '22000232', maxEnd: '0232' },
                { prefix: '2300', count: 6955, maxId: '23006954', maxEnd: '6954' },
                { prefix: '3000', count: 4490, maxId: '30004808', maxEnd: '4808' },
                { prefix: '3100', count: 4996, maxId: '31005266', maxEnd: '5266' },
                { prefix: '3200', count: 2, maxId: '32000112', maxEnd: '0112' },
                { prefix: '3300', count: 1, maxId: '33000000', maxEnd: '0000' },
                { prefix: '3400', count: 384, maxId: '34002154', maxEnd: '2154' }
              ].map((group, idx) => (
                <div key={idx} className="grid grid-cols-3 gap-2 items-center px-1">
                  <span className="text-xs font-bold text-slate-700 bg-slate-50 py-1 px-2 rounded-lg inline-block w-fit">
                    {group.prefix}
                  </span>
                  <div className="text-right">
                    <span className="text-xs font-bold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-full">
                      {group.count.toLocaleString()}
                    </span>
                  </div>
                  <div className="text-right flex flex-col">
                    <span className="text-[10px] text-slate-400 truncate w-full" title={group.maxId}>{group.maxId}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Top Lists Row */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex flex-col min-h-[200px]">
          <h3 className="font-semibold text-sm mb-4">Frequently Borrowed Items</h3>
          <div className="flex-1 overflow-y-auto space-y-3">
            {topBorrowedItems.map((item, idx) => (
              <div key={idx} className="flex items-center justify-between">
                <span className="text-xs text-slate-600 font-medium truncate max-w-[200px]" title={item.name}>{item.name}</span>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded-full">{item.count} ຄັ້ງ</span>
                </div>
              </div>
            ))}
            {topBorrowedItems.length === 0 && (
              <p className="text-sm text-slate-400 text-center py-4">No data available</p>
            )}
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex flex-col min-h-[200px]">
          <h3 className="font-semibold text-sm mb-4">Frequent Borrowers</h3>
          <div className="flex-1 overflow-y-auto space-y-3">
            {topBorrowers.map((user, idx) => (
              <div key={idx} className="flex items-center justify-between">
                <span className="text-xs text-slate-600 font-medium truncate max-w-[200px]" title={user.name}>{user.name}</span>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded-full">{user.count} ຄັ້ງ</span>
                </div>
              </div>
            ))}
            {topBorrowers.length === 0 && (
              <p className="text-sm text-slate-400 text-center py-4">No data available</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function InventoryView({ 
  searchQuery,
  setSearchQuery,
  onImport, 
  onImportFromServer,
  isImporting,
  isAdmin,
  isSuperAdmin,
  onDelete,
  onDeleteAll,
  isDeletingAll,
  onEdit,
  onAdd,
  itemsPerPage
}: { 
  searchQuery: string,
  setSearchQuery: (query: string) => void,
  onImport: (file: File) => Promise<void>,
  onImportFromServer: () => Promise<void>,
  isImporting: boolean,
  isAdmin: boolean,
  isSuperAdmin?: boolean,
  onDelete: (id: string) => Promise<void>,
  onDeleteAll: () => Promise<void>,
  isDeletingAll: boolean,
  onEdit: (item: InventoryItem) => void,
  onAdd: () => void,
  itemsPerPage: number
}) {
  const DEFAULT_COLUMNS = [
    { id: 'material', label: 'Material', visible: true, order: 0, field: 'id' },
    { id: 'photos', label: 'Photos', visible: true, order: 1, field: 'photos' },
    { id: 'description', label: 'Description', visible: true, order: 2, field: 'name' },
    { id: 'baseUnit', label: 'Unit', visible: true, order: 3, field: 'uom' },
    { id: 'slocBin', label: 'SLOC / Bin', visible: true, order: 4, field: 'sloc' },
    { id: 'brandMfr', label: 'Brand / Mfr. Part', visible: true, order: 5, field: 'brand' },
    { id: 'stock', label: 'Stock', visible: true, order: 6, field: 'quantity' },
    { id: 'status', label: 'Status', visible: true, order: 7, field: 'status' },
    { id: 'actions', label: 'Actions', visible: true, order: 8, field: null },
  ];

  const DEFAULT_ITEM_DETAILS_FIELDS = [
    { id: 'id', label: 'Material ID', visible: true, order: 0 },
    { id: 'name', label: 'Name/Description', visible: true, order: 1 },
    { id: 'description', label: 'Long Description', visible: true, order: 2 },
    { id: 'uom', label: 'Unit (UoM)', visible: true, order: 3 },
    { id: 'sloc', label: 'Storage Location (SLOC)', visible: true, order: 4 },
    { id: 'bin', label: 'Bin Location', visible: true, order: 5 },
    { id: 'functionalSystem', label: 'Functional System', visible: true, order: 6 },
    { id: 'brand', label: 'Brand', visible: true, order: 7 },
    { id: 'mfrPartNumber', label: 'Mfr. Part Number', visible: true, order: 8 },
    { id: 'quantity', label: 'Stock Quantity', visible: true, order: 9 },
    { id: 'minQuantity', label: 'Min Stock Quantity', visible: true, order: 10 },
    { id: 'status', label: 'Status', visible: true, order: 11 },
    { id: 'category', label: 'Category', visible: true, order: 12 },
    { id: 'photos', label: 'Photos', visible: true, order: 13 },
  ];

  const [columns, setColumns] = useState(DEFAULT_COLUMNS);
  const [itemDetailsFields, setItemDetailsFields] = useState(DEFAULT_ITEM_DETAILS_FIELDS);
  const [showItemDetailsManager, setShowItemDetailsManager] = useState(false);
  const [sortConfig, setSortConfig] = useState<{key: string; direction: 'asc'|'desc'}>({ key: 'id', direction: 'asc' });
  const [showColumnManager, setShowColumnManager] = useState(false);
  const [showFilters, setShowFilters] = useState(false);
  const [statusFilter, setStatusFilter] = useState<string>('');

  const [viewItem, setViewItem] = useState<InventoryItem | null>(null);
  const [fullscreenPhoto, setFullscreenPhoto] = useState<string | null>(null);

  const handleAddPhotoToViewItem = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files?.length || !viewItem) return;
    const existingPhotos = viewItem.photos || [];
    const remainingSlots = 3 - existingPhotos.length;
    if (remainingSlots <= 0) return;
    
    const newPhotos = await processImageFiles(e.target.files, remainingSlots);
    const updatedPhotos = [...existingPhotos, ...newPhotos];
    
    setViewItem({ ...viewItem, photos: updatedPhotos });
    setItems((prev) => prev.map(item => item.id === viewItem.id ? { ...item, photos: updatedPhotos } : item));
    
    try {
      await setDoc(doc(db, 'inventory', viewItem.id), { photos: updatedPhotos }, { merge: true });
    } catch(error) {
      console.error("Failed to update photos", error);
    }
    e.target.value = '';
  };

  const handleRemovePhotoFromViewItem = async (photoIndex: number) => {
    if (!viewItem) return;
    const newPhotos = [...(viewItem.photos || [])];
    newPhotos.splice(photoIndex, 1);
    
    setViewItem({ ...viewItem, photos: newPhotos });
    setItems((prev) => prev.map(item => item.id === viewItem.id ? { ...item, photos: newPhotos } : item));
    
    try {
      await setDoc(doc(db, 'inventory', viewItem.id), { photos: newPhotos }, { merge: true });
    } catch(error) {
      console.error("Failed to remove photo", error);
    }
  };

  useEffect(() => {
    // Also use local storage as fallback for quicker initial paint if needed, or just let it load
    const saved = localStorage.getItem('inventoryColumns');
    if (saved) {
      try { setColumns(JSON.parse(saved)); } catch (e) {}
    }
    const savedDetailsConfig = localStorage.getItem('itemDetailsConfig');
    if (savedDetailsConfig) {
      try { setItemDetailsFields(JSON.parse(savedDetailsConfig)); } catch (e) {}
    }

    const unsubColumns = onSnapshot(doc(db, 'settings', 'inventoryColumns'), (docSnap) => {
      if (docSnap.exists() && docSnap.data().columns) {
        setColumns(docSnap.data().columns);
        localStorage.setItem('inventoryColumns', JSON.stringify(docSnap.data().columns));
      }
    }, (error) => {
      console.warn("Could not listen to inventory columns settings:", error);
    });

    const unsubDetails = onSnapshot(doc(db, 'settings', 'itemDetailsConfig'), (docSnap) => {
      if (docSnap.exists() && docSnap.data().fields) {
        setItemDetailsFields(docSnap.data().fields);
        localStorage.setItem('itemDetailsConfig', JSON.stringify(docSnap.data().fields));
      }
    }, (error) => {
      console.warn("Could not listen to item details config:", error);
    });

    return () => {
      unsubColumns();
      unsubDetails();
    };
  }, []);

  const handleUpdateColumns = async (newColumns: typeof DEFAULT_COLUMNS) => {
    setColumns(newColumns);
    localStorage.setItem('inventoryColumns', JSON.stringify(newColumns));
    if (isAdmin) {
      try {
        await setDoc(doc(db, 'settings', 'inventoryColumns'), { columns: newColumns }, { merge: true });
      } catch (err) {
        console.error("Failed to save columns config", err);
      }
    }
  };

  const handleUpdateItemDetailsFields = async (newFields: typeof DEFAULT_ITEM_DETAILS_FIELDS) => {
    setItemDetailsFields(newFields);
    localStorage.setItem('itemDetailsConfig', JSON.stringify(newFields));
    if (isAdmin) {
      try {
        await setDoc(doc(db, 'settings', 'itemDetailsConfig'), { fields: newFields }, { merge: true });
      } catch (err) {
        console.error("Failed to save item details config", err);
      }
    }
  };

  const [isExporting, setIsExporting] = useState(false);

  const handleExportCSV = async () => {
    try {
      setIsExporting(true);
      const inventoryRef = collection(db, 'inventory');
      let baseQ: any = inventoryRef;
      
      // If there's an active status filter, apply it
      if (statusFilter) {
         baseQ = query(baseQ, where('status', '==', statusFilter));
      }

      const snapshot = await getDocs(baseQ);
      
      // Setup CSV headers based on ALL available default fields
      const headers = [
        'Material ID', 'Name/Description', 'Long Description', 'Unit', 
        'Storage Location', 'Bin Location', 'Functional System', 
        'Brand', 'Mfr Part Number', 'Stock Quantity', 'Min Quantity', 'Status', 'Category'
      ];
      
      let csvContent = headers.join(',') + '\n';
      
      snapshot.docs.forEach(doc => {
        const item: any = doc.data();
        // Wrap fields in quotes and escape existing quotes
        const row = [
          `"${(item.id || '').toString().replace(/"/g, '""')}"`,
          `"${(item.name || '').toString().replace(/"/g, '""')}"`,
          `"${(item.description || '').toString().replace(/"/g, '""')}"`,
          `"${(item.uom || '').toString().replace(/"/g, '""')}"`,
          `"${(item.sloc || '').toString().replace(/"/g, '""')}"`,
          `"${(item.bin || '').toString().replace(/"/g, '""')}"`,
          `"${(item.functionalSystem || '').toString().replace(/"/g, '""')}"`,
          `"${(item.brand || '').toString().replace(/"/g, '""')}"`,
          `"${(item.mfrPartNumber || '').toString().replace(/"/g, '""')}"`,
          `"${(Number(item.quantity) || 0)}"`,
          `"${(Number(item.minQuantity) || 0)}"`,
          `"${(item.status || '').toString().replace(/"/g, '""')}"`,
          `"${(item.category || '').toString().replace(/"/g, '""')}"`
        ];
        csvContent += row.join(',') + '\n';
      });

      const blob = new Blob([new Uint8Array([0xEF, 0xBB, 0xBF]), csvContent], { type: 'text/csv;charset=utf-8;' });
      const link = document.createElement('a');
      link.href = URL.createObjectURL(blob);
      link.download = `inventory_export_${new Date().toISOString().slice(0, 10)}.csv`;
      link.click();
      URL.revokeObjectURL(link.href);
      
    } catch (error: any) {
      console.error("Export failed:", error);
      alert(`Export failed: ${error.message}`);
    } finally {
      setIsExporting(false);
    }
  };

  const [items, setItems] = useState<InventoryItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [pageCursors, setPageCursors] = useState<any[]>([]);
  const [currentPage, setCurrentPage] = useState(0);
  const [totalPages, setTotalPages] = useState(1);
  const [showStockAndStatus, setShowStockAndStatus] = useState(() => {
    const saved = localStorage.getItem('showStockAndStatus');
    return saved !== null ? JSON.parse(saved) : true;
  });
  const fileInputRef = React.useRef<HTMLInputElement>(null);

  const toggleStockAndStatus = () => {
    const newValue = !showStockAndStatus;
    setShowStockAndStatus(newValue);
    localStorage.setItem('showStockAndStatus', JSON.stringify(newValue));
  };

  const fetchPage = async (pageIndex: number, search: string = '', status: string = '') => {
    setLoading(true);
    try {
      let baseQ = collection(db, 'inventory');
      let q;
      
      if (status) {
         baseQ = query(baseQ, where('status', '==', status)) as any;
      }

      if (search) {
        if (/^\d+$/.test(search)) {
          baseQ = query(baseQ, where('id', '>=', search), where('id', '<=', search + '\uf8ff'), orderBy('id')) as any;
        } else {
          const upperSearch = search.toUpperCase();
          baseQ = query(baseQ, where('name', '>=', upperSearch), where('name', '<=', upperSearch + '\uf8ff'), orderBy('name')) as any;
        }
      } else {
        baseQ = query(baseQ, orderBy(sortConfig.key, sortConfig.direction)) as any;
      }

      if (pageIndex === 0) {
        // Fetch total count for pagination
        try {
          const snapshot = await getCountFromServer(baseQ);
          const total = snapshot.data().count;
          setTotalPages(Math.max(1, Math.ceil(total / itemsPerPage)));
        } catch (e) {
          console.error("Failed to get count", e);
        }
      }

      q = query(baseQ, limit(itemsPerPage));

      if (pageIndex > 0) {
        if (pageCursors[pageIndex - 1]) {
          q = query(baseQ, startAfter(pageCursors[pageIndex - 1]), limit(itemsPerPage));
        } else {
          // We need to fetch the cursor for the previous page
          const cursorQuery = query(baseQ, limit(pageIndex * itemsPerPage));
          const cursorSnapshot = await getDocs(cursorQuery);
          const lastVisible = cursorSnapshot.docs[cursorSnapshot.docs.length - 1];
          q = query(baseQ, startAfter(lastVisible), limit(itemsPerPage));
          
          // Update cursors array
          const newCursors = [...pageCursors];
          newCursors[pageIndex - 1] = lastVisible;
          setPageCursors(newCursors);
        }
      }

      const snapshot = await getDocs(q);
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...(doc.data() as object) } as InventoryItem));
      
      setItems(data);
      
      if (snapshot.docs.length > 0) {
        const newCursors = [...pageCursors];
        newCursors[pageIndex] = snapshot.docs[snapshot.docs.length - 1];
        setPageCursors(newCursors);
      }
    } catch (error) {
      console.error("Failed to fetch inventory:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    // Reset to page 0 when search or sort or status changes
    setCurrentPage(0);
    setPageCursors([]);
    fetchPage(0, searchQuery, statusFilter);
  }, [searchQuery, sortConfig, statusFilter]);

  useEffect(() => {
    // Fetch when page changes, but skip if it's page 0 and we just searched (handled above)
    if (currentPage > 0 || !searchQuery) {
      fetchPage(currentPage, searchQuery, statusFilter);
    }
  }, [currentPage]);

  const handleNextPage = () => {
    if (currentPage < totalPages - 1) {
      setCurrentPage(prev => prev + 1);
    }
  };

  const handlePrevPage = () => {
    if (currentPage > 0) {
      setCurrentPage(prev => prev - 1);
    }
  };

  const handlePageClick = (pageIndex: number) => {
    if (pageIndex !== currentPage && pageIndex >= 0 && pageIndex < totalPages) {
      setCurrentPage(pageIndex);
    }
  };

  const getPageNumbers = () => {
    const pages = [];
    const maxVisiblePages = 5;
    let startPage = Math.max(0, currentPage - Math.floor(maxVisiblePages / 2));
    let endPage = Math.min(totalPages - 1, startPage + maxVisiblePages - 1);

    if (endPage - startPage + 1 < maxVisiblePages) {
      startPage = Math.max(0, endPage - maxVisiblePages + 1);
    }

    for (let i = startPage; i <= endPage; i++) {
      pages.push(i);
    }
    return pages;
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      try {
        await onImport(file);
      } catch (error) {
        alert('Failed to import inventory. Please check the file format.');
      }
    }
  };

  const visibleColumns = [...columns].sort((a,b) => a.order - b.order).filter(c => c.visible);

  const handleSort = (field: string | null) => {
    if (!field) return; 
    setSortConfig(prev => ({
      key: field,
      direction: prev.key === field && prev.direction === 'asc' ? 'desc' : 'asc'
    }));
  };

  const renderCell = (columnId: string, item: InventoryItem) => {
    switch (columnId) {
      case 'material': 
        return (
          <div className="flex flex-col">
            <span className="text-sm font-bold text-slate-900">{item.id}</span>
            <div className="flex flex-col sm:hidden mt-1 opacity-80">
              <span className="text-[9px] text-slate-500 font-medium">{item.sloc}</span>
              <span className="text-[10px] font-bold text-slate-700">{item.bin}</span>
            </div>
          </div>
        );
      case 'photos':
        return (
          <div className="flex -space-x-2 overflow-hidden">
            {item.photos && item.photos.length > 0 ? (
              item.photos.slice(0, 3).map((photo, idx) => (
                <div 
                  key={idx} 
                  className="inline-block h-6 w-6 rounded-md ring-2 ring-white bg-slate-100 overflow-hidden cursor-pointer hover:ring-indigo-300 transition-all z-10 hover:z-20 transform hover:scale-110"
                  onClick={(e) => {
                    e.stopPropagation();
                    setFullscreenPhoto(photo);
                  }}
                >
                  <img src={photo} alt={`Material ${idx + 1}`} className="h-full w-full object-cover" referrerPolicy="no-referrer" />
                </div>
              ))
            ) : (
                <div className="h-6 w-6 rounded-md bg-slate-100 flex items-center justify-center text-slate-400">
                  <Package size={12} />
                </div>
            )}
          </div>
        );
      case 'description':
        return (
          <div className="flex flex-col min-w-[140px] sm:min-w-[200px] whitespace-normal">
            <span className="text-xs font-semibold text-slate-900 leading-tight">{item.name}</span>
            <span className="text-[10px] text-slate-500 mt-1">{item.functionalSystem}</span>
          </div>
        );
      case 'baseUnit':
        return <span className="text-xs text-slate-600 whitespace-nowrap">{item.uom}</span>;
      case 'slocBin':
        return (
          <div className="flex flex-col">
            <span className="text-xs font-medium text-slate-700">{item.sloc}</span>
            <span className="text-[10px] text-slate-600 font-bold">{item.bin}</span>
          </div>
        );
      case 'brandMfr':
        return (
          <div className="flex flex-col">
             <span className="text-xs font-medium text-slate-700">{item.brand}</span>
             <span className="text-[10px] text-slate-400">{item.mfrPartNumber}</span>
          </div>
        );
      case 'stock':
        return (
          <div className="flex items-center gap-2">
            <span className={cn("font-semibold", item.quantity <= item.minQuantity ? "text-red-600" : "text-slate-900")}>
              {item.quantity.toLocaleString()}
            </span>
            <span className="text-xs text-slate-400">/ {item.minQuantity.toLocaleString()} min</span>
          </div>
        );
      case 'status':
        return <StatusBadge status={item.status} />;
      case 'actions':
        return (
          <div className="flex items-center gap-2">
            {isAdmin && (
              <>
                <button onClick={(e) => { e.stopPropagation(); onEdit(item); }} className="text-indigo-600 hover:text-indigo-800 text-xs font-semibold">Edit</button>
                {isSuperAdmin && (
                  <button onClick={(e) => { e.stopPropagation(); onDelete(item.id); }} className="text-rose-600 hover:text-rose-800 p-1 rounded-md hover:bg-rose-50 transition-colors" title="Delete Item">
                    <Trash2 size={14} />
                  </button>
                )}
              </>
            )}
          </div>
        );
      default: return null;
    }
  };

  return (
    <div className="space-y-2">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-2">
        <div className="relative w-full lg:w-[280px] shrink-0">
          <Search className="absolute left-2 top-1/2 -translate-y-1/2 text-slate-400" size={14} />
          <input 
            type="text" 
            placeholder="Search ID or Name..." 
            className="w-full pl-7 pr-3 py-1.5 bg-white border border-slate-200 focus:border-indigo-300 focus:ring-4 focus:ring-indigo-100 rounded-lg transition-all outline-none text-xs"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <div className="flex flex-wrap items-center justify-end gap-1.5 flex-1">
          {isAdmin && (
            <>
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileChange}
                accept=".xlsx, .xls, .csv"
                className="hidden"
              />
              <div className="flex items-center gap-0.5 bg-slate-100 p-0.5 rounded-lg">
                <button 
                  onClick={onAdd}
                  title="Add Item"
                  className="flex items-center justify-center p-1.5 bg-white text-indigo-600 rounded-md hover:bg-indigo-50 transition-all shadow-sm"
                >
                  <Plus size={14} />
                </button>
                <button 
                  onClick={onImportFromServer}
                  disabled={isImporting}
                  title="Import from Server"
                  className="flex items-center justify-center p-1.5 bg-white text-emerald-600 rounded-md hover:bg-emerald-50 transition-all shadow-sm disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isImporting ? (
                    <div className="w-3.5 h-3.5 border-2 border-emerald-600/30 border-t-emerald-600 rounded-full animate-spin" />
                  ) : (
                    <Upload size={14} />
                  )}
                </button>
                {isSuperAdmin && (
                  <button 
                    onClick={onDeleteAll}
                    disabled={isDeletingAll}
                    title="Clear All Inventory"
                    className="flex items-center justify-center p-1.5 bg-white text-rose-600 rounded-md hover:bg-rose-50 transition-all shadow-sm disabled:opacity-50"
                  >
                    <Trash2 size={14} />
                  </button>
                )}
              </div>
              <div className="relative">
                <button 
                  onClick={() => setShowColumnManager(!showColumnManager)}
                  title="Columns"
                  className={cn("flex items-center justify-center p-1.5 border rounded-lg transition-all shadow-sm", showColumnManager ? "bg-indigo-50 border-indigo-200 text-indigo-700" : "bg-white border-slate-200 text-slate-700 hover:bg-slate-50")}
                >
                  <Columns size={14} />
                </button>

                <AnimatePresence>
                  {showColumnManager && (
                    <>
                      <div className="fixed inset-0 z-[40]" onClick={() => setShowColumnManager(false)} />
                      <motion.div
                        initial={{ opacity: 0, y: 10, scale: 0.95 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        exit={{ opacity: 0, y: 10, scale: 0.95 }}
                        className="absolute right-0 top-full mt-2 w-64 bg-white border border-slate-200 shadow-xl rounded-xl z-[45] overflow-hidden"
                      >
                        <div className="p-3 border-b border-slate-100 bg-slate-50">
                          <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider">Manage Columns</h4>
                        </div>
                        <div className="max-h-64 overflow-y-auto p-2 space-y-1">
                          {[...columns].sort((a,b) => a.order - b.order).map((col, index) => (
                            <div key={col.id} className="flex items-center gap-2 p-1.5 hover:bg-slate-50 rounded-lg group">
                              <button 
                                className="cursor-grab text-slate-400 opacity-50 hover:opacity-100"
                                onClick={(e) => {
                                  e.preventDefault();
                                  if (index > 0) {
                                    const newCols = [...columns];
                                    const curr = newCols.find(c => c.id === col.id)!;
                                    const prev = newCols.find(c => c.order === index - 1)!;
                                    curr.order = index - 1;
                                    prev.order = index;
                                    handleUpdateColumns(newCols);
                                  }
                                }}
                              >
                                <ArrowUp size={14} />
                              </button>
                              <button 
                                className="cursor-grab text-slate-400 opacity-50 hover:opacity-100"
                                onClick={(e) => {
                                  e.preventDefault();
                                  if (index < columns.length - 1) {
                                    const newCols = [...columns];
                                    const curr = newCols.find(c => c.id === col.id)!;
                                    const next = newCols.find(c => c.order === index + 1)!;
                                    curr.order = index + 1;
                                    next.order = index;
                                    handleUpdateColumns(newCols);
                                  }
                                }}
                              >
                                <ArrowDown size={14} />
                              </button>
                              <label className="flex items-center gap-2 flex-1 cursor-pointer min-w-0">
                                <input 
                                  type="checkbox" 
                                  checked={col.visible}
                                  onChange={(e) => {
                                    handleUpdateColumns(columns.map(c => c.id === col.id ? { ...c, visible: e.target.checked } : c));
                                  }}
                                  className="rounded text-indigo-600 focus:ring-indigo-500"
                                />
                                <span className="text-xs text-slate-700 font-medium truncate">{col.id === 'baseUnit' ? 'Unit' : col.label}</span>
                              </label>
                            </div>
                          ))}
                        </div>
                      </motion.div>
                    </>
                  )}
                </AnimatePresence>
              </div>
            </>
          )}
          <div className="flex items-center gap-1.5">
            <button 
              onClick={() => setShowFilters(!showFilters)}
              title="Filter" 
              className={cn("flex items-center justify-center p-1.5 border rounded-lg transition-colors shadow-sm", showFilters ? "bg-indigo-50 border-indigo-200 text-indigo-700" : "bg-white border-slate-200 text-slate-700 hover:bg-slate-50")}
            >
              <Filter size={14} />
            </button>
            <button 
              onClick={handleExportCSV}
              disabled={isExporting}
              title="Export" 
              className="flex items-center justify-center p-1.5 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors text-slate-700 shadow-sm disabled:opacity-50"
            >
              {isExporting ? <span className="w-3.5 h-3.5 border-2 border-slate-300 border-t-slate-600 rounded-full animate-spin"></span> : <Download size={14} />}
            </button>
          </div>
        </div>
      </div>

      <AnimatePresence>
        {showFilters && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden"
          >
            <div className="p-3 bg-white border border-slate-200 rounded-xl shadow-sm mb-4 flex flex-wrap gap-3">
              <div className="flex flex-col gap-1 w-full sm:w-auto">
                <label className="text-xs font-semibold text-slate-500 uppercase">Status</label>
                <select 
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                  className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-sm outline-none focus:border-indigo-500 min-w-[150px]"
                >
                  <option value="">All Statuses</option>
                  <option value="available">Available</option>
                  <option value="borrowed">Borrowed</option>
                  <option value="maintenance">Maintenance</option>
                  <option value="low-stock">Low Stock</option>
                </select>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50/50 border-b border-slate-100 whitespace-nowrap">
                {visibleColumns.map((col) => (
                  <th 
                    key={col.id} 
                    className={cn(
                      "px-3 py-2 text-xs font-bold text-slate-700",
                      col.field && "cursor-pointer hover:bg-slate-100 transition-colors",
                      col.id === 'slocBin' && "hidden sm:table-cell"
                    )}
                    onClick={() => handleSort(col.field)}
                  >
                    <div className="flex items-center gap-1">
                      {col.id === 'baseUnit' ? 'Unit' : col.id === 'description' ? 'Description' : col.label}
                      {sortConfig.key === col.field && (
                        <span className="text-indigo-600">
                          {sortConfig.direction === 'asc' ? <ArrowUp size={12} /> : <ArrowDown size={12} />}
                        </span>
                      )}
                    </div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-blue-100">
              {loading ? (
                <tr>
                  <td colSpan={visibleColumns.length} className="px-6 py-12 text-center text-slate-500">
                    <div className="flex flex-col items-center justify-center gap-2">
                      <div className="w-6 h-6 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin"></div>
                      <p>Loading inventory...</p>
                    </div>
                  </td>
                </tr>
              ) : items.length === 0 ? (
                <tr>
                  <td colSpan={visibleColumns.length} className="px-6 py-12 text-center text-slate-500">
                    No items found.
                  </td>
                </tr>
              ) : (
                items.map((item) => (
                  <tr key={item.id} onClick={() => setViewItem(item)} className="hover:bg-slate-50/50 transition-colors group cursor-pointer">
                    {visibleColumns.map(col => (
                      <td key={col.id} className={cn("px-3 py-2", col.id !== 'description' && "whitespace-nowrap", col.id === 'slocBin' && "hidden sm:table-cell")}>
                        {renderCell(col.id, item)}
                      </td>
                    ))}
                  </tr>
                )))}
            </tbody>
          </table>
        </div>
        
        {/* Pagination Footer */}
        <div className="p-2 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-2 bg-slate-50">
          <span className="text-xs text-slate-500 font-medium">
            Page {currentPage + 1} of {totalPages}
          </span>
          <div className="flex flex-wrap items-center justify-center gap-1">
            <button 
              onClick={handlePrevPage}
              disabled={currentPage === 0 || loading}
              className="px-2 py-1 bg-white border border-slate-200 text-slate-700 rounded-md hover:bg-slate-50 transition-all text-xs font-bold disabled:opacity-50 disabled:cursor-not-allowed shadow-sm"
            >
              Previous
            </button>
            
            <div className="hidden sm:flex items-center gap-1">
              {getPageNumbers().map(pageNum => (
                <button
                  key={pageNum}
                  onClick={() => handlePageClick(pageNum)}
                  disabled={loading}
                  className={cn(
                    "w-6 h-6 rounded-md flex items-center justify-center text-xs font-bold transition-all shadow-sm",
                    currentPage === pageNum 
                      ? "bg-indigo-600 text-white border-transparent" 
                      : "bg-white border border-slate-200 text-slate-700 hover:bg-slate-50"
                  )}
                >
                  {pageNum + 1}
                </button>
              ))}
              {totalPages > 5 && currentPage < totalPages - 3 && (
                <span className="text-slate-400 px-1 text-xs">...</span>
              )}
            </div>

            <button 
              onClick={handleNextPage}
              disabled={currentPage >= totalPages - 1 || loading}
              className="px-2 py-1 bg-white border border-slate-200 text-slate-700 rounded-md hover:bg-slate-50 transition-all text-xs font-bold disabled:opacity-50 disabled:cursor-not-allowed shadow-sm"
            >
              Next
            </button>
          </div>
        </div>
      </div>
      
      <AnimatePresence>
        {viewItem && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setViewItem(null)}
              className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="bg-white w-full max-w-2xl max-h-[90vh] rounded-3xl shadow-2xl overflow-hidden flex flex-col relative z-10"
            >
              <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-white shrink-0 z-10">
                <h2 className="text-xl font-bold">Item Details</h2>
                <div className="flex items-center gap-2">
                  {isAdmin && (
                    <div className="relative">
                      <button 
                        type="button" 
                        onClick={() => setShowItemDetailsManager(!showItemDetailsManager)}
                        className={cn("p-2 rounded-full transition-colors", showItemDetailsManager ? "bg-indigo-50 text-indigo-700" : "hover:bg-slate-100")}
                        title="Configure Item Details Layout"
                      >
                        <Columns size={18} />
                      </button>
                      <AnimatePresence>
                        {showItemDetailsManager && (
                          <>
                            <div className="fixed inset-0 z-[60]" onClick={() => setShowItemDetailsManager(false)} />
                            <motion.div
                              initial={{ opacity: 0, y: 10, scale: 0.95 }}
                              animate={{ opacity: 1, y: 0, scale: 1 }}
                              exit={{ opacity: 0, y: 10, scale: 0.95 }}
                              className="absolute right-0 top-full mt-2 w-72 bg-white border border-slate-200 shadow-xl rounded-xl z-[65] overflow-hidden flex flex-col max-h-[60vh] text-left"
                            >
                              <div className="p-3 border-b border-slate-100 bg-slate-50 flex items-center justify-between">
                                <span className="text-xs font-bold text-slate-700 uppercase">Manage Details Layout</span>
                                <button onClick={() => setShowItemDetailsManager(false)} className="text-slate-400 hover:text-slate-600"><X size={14}/></button>
                              </div>
                              <div className="overflow-y-auto p-2 space-y-1">
                                {[...itemDetailsFields].sort((a, b) => a.order - b.order).map((field, index) => (
                                  <div key={field.id} className="flex items-center gap-2 p-2 hover:bg-slate-50 rounded-lg group">
                                    <div className="flex flex-col gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity">
                                      <button 
                                        disabled={index === 0}
                                        className="text-slate-400 hover:text-indigo-600 disabled:opacity-30 disabled:hover:text-slate-400"
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          if (index > 0) {
                                            const newFields = [...itemDetailsFields];
                                            const curr = newFields.find(f => f.id === field.id)!;
                                            const prev = newFields.find(f => f.order === index - 1)!;
                                            curr.order = index - 1;
                                            prev.order = index;
                                            handleUpdateItemDetailsFields(newFields);
                                          }
                                        }}
                                      >
                                        <ArrowUp size={14} />
                                      </button>
                                      <button 
                                        disabled={index === itemDetailsFields.length - 1}
                                        className="text-slate-400 hover:text-indigo-600 disabled:opacity-30 disabled:hover:text-slate-400"
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          if (index < itemDetailsFields.length - 1) {
                                            const newFields = [...itemDetailsFields];
                                            const curr = newFields.find(f => f.id === field.id)!;
                                            const next = newFields.find(f => f.order === index + 1)!;
                                            curr.order = index + 1;
                                            next.order = index;
                                            handleUpdateItemDetailsFields(newFields);
                                          }
                                        }}
                                      >
                                        <ArrowDown size={14} />
                                      </button>
                                    </div>
                                    <label className="flex items-center gap-2 flex-1 cursor-pointer min-w-0">
                                      <input 
                                        type="checkbox" 
                                        checked={field.visible}
                                        onChange={(e) => {
                                          handleUpdateItemDetailsFields(itemDetailsFields.map(f => f.id === field.id ? { ...f, visible: e.target.checked } : f));
                                        }}
                                        className="rounded text-indigo-600 focus:ring-indigo-500"
                                      />
                                      <span className="text-xs text-slate-700 font-medium truncate flex-1">{field.label}</span>
                                    </label>
                                  </div>
                                ))}
                              </div>
                            </motion.div>
                          </>
                        )}
                      </AnimatePresence>
                    </div>
                  )}
                  <button type="button" onClick={() => setViewItem(null)} className="p-2 hover:bg-slate-100 rounded-full transition-colors">
                    <X size={20} />
                  </button>
                </div>
              </div>
              
              <div className="flex-1 overflow-y-auto p-8 custom-scrollbar space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {itemDetailsFields.filter(f => f.visible).sort((a, b) => a.order - b.order).map((field) => {
                    const isFullWidth = field.id === 'description' || field.id === 'photos';
                    return (
                      <div key={field.id} className={cn("space-y-1", isFullWidth ? "col-span-1 md:col-span-2" : "")}>
                        <label className={cn("text-xs font-bold text-slate-500 uppercase", "mb-1 block")}>
                          {field.id === 'photos' ? `Photos (${viewItem.photos?.length || 0}/3)` : field.label}
                        </label>
                        
                        {field.id === 'id' && <div className="font-medium text-slate-900">{viewItem.id}</div>}
                        {field.id === 'name' && <div className="font-medium text-slate-900">{viewItem.name}</div>}
                        {field.id === 'description' && (
                          viewItem.description ? 
                            <div className="text-sm text-slate-700 bg-slate-50 p-3 rounded-xl">{viewItem.description}</div> : 
                            <div className="text-sm italic text-slate-400">No description provided.</div>
                        )}
                        {field.id === 'uom' && <div className="font-medium text-slate-900">{viewItem.uom}</div>}
                        {field.id === 'sloc' && <div className="font-medium text-slate-900">{viewItem.sloc}</div>}
                        {field.id === 'bin' && <div className="font-medium text-slate-900">{viewItem.bin}</div>}
                        {field.id === 'functionalSystem' && <div className="font-medium text-slate-900">{viewItem.functionalSystem || 'N/A'}</div>}
                        {field.id === 'brand' && <div className="font-medium text-slate-900">{viewItem.brand || 'N/A'}</div>}
                        {field.id === 'mfrPartNumber' && <div className="font-medium text-slate-900">{viewItem.mfrPartNumber || 'N/A'}</div>}
                        {field.id === 'quantity' && <div className="font-medium text-slate-900">{viewItem.quantity}</div>}
                        {field.id === 'minQuantity' && <div className="font-medium text-slate-900">{viewItem.minQuantity}</div>}
                        {field.id === 'status' && <div><StatusBadge status={viewItem.status} /></div>}
                        {field.id === 'category' && <div className="font-medium text-slate-900">{viewItem.category || 'N/A'}</div>}
                        
                        {field.id === 'photos' && (
                          <div className="space-y-2 mt-2">
                            <div className="flex items-center">
                              {(!viewItem.photos || viewItem.photos.length < 3) && (
                                <div className="flex gap-2">
                                  <label className="flex items-center gap-1 cursor-pointer text-xs font-bold text-indigo-600 hover:text-indigo-800 transition-colors bg-indigo-50 px-2 py-1 rounded-md">
                                    <Camera size={14} /> Camera
                                    <input 
                                      type="file" 
                                      accept="image/*" 
                                      capture="environment"
                                      className="hidden" 
                                      onChange={handleAddPhotoToViewItem}
                                    />
                                  </label>
                                  <label className="flex items-center gap-1 cursor-pointer text-xs font-bold text-indigo-600 hover:text-indigo-800 transition-colors bg-indigo-50 px-2 py-1 rounded-md">
                                    <ImageIcon size={14} /> Gallery
                                    <input 
                                      type="file" 
                                      accept="image/*" 
                                      multiple 
                                      className="hidden" 
                                      onChange={handleAddPhotoToViewItem}
                                    />
                                  </label>
                                </div>
                              )}
                            </div>
                            {viewItem.photos && viewItem.photos.length > 0 ? (
                              <div className="flex flex-wrap gap-3">
                                {viewItem.photos.map((photo, idx) => (
                                  <div key={idx} className="relative w-24 h-24 rounded-xl border border-slate-200 overflow-hidden bg-slate-100 group">
                                    <img 
                                      src={photo} 
                                      alt={`Material ${idx + 1}`} 
                                      className="w-full h-full object-cover cursor-pointer hover:scale-105 transition-transform" 
                                      referrerPolicy="no-referrer" 
                                      onClick={() => setFullscreenPhoto(photo)}
                                    />
                                    <button
                                      onClick={() => handleRemovePhotoFromViewItem(idx)}
                                      className="absolute top-1 right-1 bg-white/90 text-rose-600 rounded-full w-6 h-6 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity drop-shadow-md hover:bg-rose-50"
                                      title="Remove Photo"
                                    >
                                      <X size={14} />
                                    </button>
                                  </div>
                                ))}
                              </div>
                            ) : (
                              <div className="text-sm text-slate-500 italic bg-slate-50 p-4 rounded-xl border border-slate-100 text-center">
                                No photos available for this item.
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {fullscreenPhoto && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setFullscreenPhoto(null)}
              className="absolute inset-0 bg-black/90 backdrop-blur-sm cursor-pointer"
            />
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="relative z-[61] max-w-5xl max-h-[90vh]"
            >
              <button 
                onClick={() => setFullscreenPhoto(null)}
                className="absolute -top-12 right-0 md:-right-12 text-white/70 hover:text-white p-2 transition-colors cursor-pointer"
              >
                <X size={32} />
              </button>
              <img 
                src={fullscreenPhoto} 
                alt="Fullscreen Material"
                className="max-w-full max-h-[90vh] object-contain rounded-lg shadow-2xl"
                referrerPolicy="no-referrer"
              />
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

function BorrowingView({ 
  records, 
  isAdmin,
  isSuperAdmin,
  currentUserEmail,
  onDelete,
  onToggleDeactivate,
  onViewMessages,
  initialStatusFilter = '',
  clearInitialStatusFilter,
  initialSelectedRecordId,
  clearInitialSelectedRecordId,
  appUsers
}: { 
  records: BorrowRecord[], 
  isAdmin: boolean,
  isSuperAdmin?: boolean,
  currentUserEmail: string,
  onDelete: (id: string) => Promise<void>,
  onToggleDeactivate: (id: string, currentStatus: string) => Promise<void>,
  onViewMessages: () => void,
  initialStatusFilter?: string,
  clearInitialStatusFilter?: () => void,
  initialSelectedRecordId?: string,
  clearInitialSelectedRecordId?: () => void,
  appUsers?: any[]
}) {
  const [selectedRecord, setSelectedRecord] = useState<BorrowRecord | null>(null);
  const [isEditingBorrowRecord, setIsEditingBorrowRecord] = useState(false);
  const [borrowerFilter, setBorrowerFilter] = useState('');
  const [deptFilter, setDeptFilter] = useState('');
  const [searchInput, setSearchInput] = useState('');
  const [appliedSearch, setAppliedSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState(initialStatusFilter);
  const [isConfirmingPickup, setIsConfirmingPickup] = useState<string | null>(null);
  const [isProcessingReturn, setIsProcessingReturn] = useState(false);
  const [viewingImage, setViewingImage] = useState<string | null>(null);

  useEffect(() => {
    if (selectedRecord) {
      const updated = records.find(r => r.id === selectedRecord.id);
      if (updated && JSON.stringify(updated) !== JSON.stringify(selectedRecord)) {
        setSelectedRecord(updated);
      }
    }
  }, [records, selectedRecord]);

  useEffect(() => {
    if (initialStatusFilter) {
      setStatusFilter(initialStatusFilter);
      if (clearInitialStatusFilter) clearInitialStatusFilter();
    }
  }, [initialStatusFilter, clearInitialStatusFilter]);

  useEffect(() => {
    if (initialSelectedRecordId && records.length > 0) {
      const record = records.find(r => r.id === initialSelectedRecordId);
      if (record) {
        setSelectedRecord(record);
      }
      if (clearInitialSelectedRecordId) clearInitialSelectedRecordId();
    }
  }, [initialSelectedRecordId, clearInitialSelectedRecordId, records]);

  const [borrowTypeFilter, setBorrowTypeFilter] = useState('');
  const [borrowDateFrom, setBorrowDateFrom] = useState('');
  const [borrowDateTo, setBorrowDateTo] = useState('');
  const [returnDateFrom, setReturnDateFrom] = useState('');
  const [returnDateTo, setReturnDateTo] = useState('');
  
  const [messageRecord, setMessageRecord] = useState<BorrowRecord | null>(null);
  const [messageContent, setMessageContent] = useState('');
  const [messageDelivery, setMessageDelivery] = useState<'email' | 'whatsapp'>('email');
  
  const [extensionReason, setExtensionReason] = useState('');
  const [extensionDate, setExtensionDate] = useState('');
  const [returnFormPhotos, setReturnFormPhotos] = useState<string[]>([]);
  const [isExporting, setIsExporting] = useState(false);
  
  const [editingItemIndex, setEditingItemIndex] = useState<number | null>(null);
  const [editingMaterialId, setEditingMaterialId] = useState('');
  const [editingMaterialDescription, setEditingMaterialDescription] = useState('');

  const handleEditItem = (index: number, item: any) => {
    setEditingItemIndex(index);
    setEditingMaterialId(item.materialId || '');
    setEditingMaterialDescription(item.materialDescription || '');
  };

  const handleSaveItemEdit = async () => {
    if (editingItemIndex === null || !selectedRecord) return;
    
    const updatedItems = [...selectedRecord.items];
    const oldItem = updatedItems[editingItemIndex];
    
    updatedItems[editingItemIndex] = {
      ...oldItem,
      materialId: editingMaterialId,
      materialDescription: editingMaterialDescription
    };
    
    try {
      await updateDoc(doc(db, 'borrow_records', selectedRecord.id), {
        items: updatedItems
      });
      
      const logDetails = `Admin edited item ${editingItemIndex + 1} (${oldItem.materialId}) in request ${selectedRecord.id}. New ID: ${editingMaterialId}, New Desc: ${editingMaterialDescription}`;
      
      await addDoc(collection(db, 'activity_logs'), {
        action: 'edit_item',
        user: currentUserEmail,
        timestamp: new Date().toISOString(),
        details: logDetails
      });
      
      setEditingItemIndex(null);
    } catch (err: any) {
      console.error(err);
      alert("Failed to edit item: " + err.message);
    }
  };

  const handleExport = async (format: 'pdf' | 'jpg') => {
    if (!selectedRecord) return;
    
    // Let's use the outer motion div, which contains "record-details-capture" ID
    const el = document.getElementById('record-details-capture');
    if (!el) return;
    
    try {
      setIsExporting(true);
      
      const origMaxH = el.style.maxHeight;
      const origOverflow = el.style.overflow;
      const innerEl = el.querySelector('.overflow-y-auto') as HTMLElement;
      const origInnerMaxH = innerEl ? innerEl.style.maxHeight : '';
      const origInnerOverflow = innerEl ? innerEl.style.overflow : '';
      
      el.style.maxHeight = 'none';
      el.style.overflow = 'visible';
      if (innerEl) {
        innerEl.style.maxHeight = 'none';
        innerEl.style.overflow = 'visible';
      }
      
      await new Promise(r => setTimeout(r, 100));

      const imgs = Array.from(el.querySelectorAll('img'));
      const originalSrcs = imgs.map(img => img.src);

      const fetchImageAsBase64 = async (url: string) => {
        const strategies = [
          // 1. Direct fetch with cache buster (solves Canvas cache poisoning if bucket has CORS)
          url + (url.includes('?') ? '&' : '?') + '_cb=' + Date.now(),
          // 2. corsproxy.io
          `https://corsproxy.io/?${encodeURIComponent(url)}`,
          // 3. codetabs proxy
          `https://api.codetabs.com/v1/proxy?quest=${encodeURIComponent(url)}`
        ];

        for (const fetchUrl of strategies) {
          try {
            const abortCtrl = new AbortController();
            const timeoutId = setTimeout(() => abortCtrl.abort(), 6000);
            
            // Only use mode: 'cors' on the direct fetch, proxies usually handle it without special mode requirements, but we'll let it default to cors
            const response = await fetch(fetchUrl, { signal: abortCtrl.signal });
            clearTimeout(timeoutId);
            
            if (response.ok) {
              const blob = await response.blob();
              if (blob.size > 100) { // Valid image blob
                return await new Promise<string>((resolve) => {
                  const reader = new FileReader();
                  reader.onloadend = () => resolve(reader.result as string);
                  reader.readAsDataURL(blob);
                });
              }
            }
          } catch (e) {
            console.warn(`Fetch strategy failed for ${url}:`, e);
          }
        }
        
        console.warn('All fetch strategies failed. Using fallback transparent image.');
        // Return a 1x1 transparent png on failure, so it doesn't break export
        return 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=';
      };

      await Promise.all(imgs.map(async (img) => {
        if (img.src.includes('firebasestorage.googleapis.com')) {
          const base64 = await fetchImageAsBase64(img.src);
          img.src = base64;
          // give browser a tick to update image source
          await new Promise(r => setTimeout(r, 50));
        }
      }));

      const { toJpeg } = await import('html-to-image');
      
      const imgData = await toJpeg(el, {
        pixelRatio: 2,
        backgroundColor: '#ffffff',
        filter: (node) => {
          if (node.nodeType === 1) { // Node.ELEMENT_NODE
            return (node as Element).getAttribute?.('data-html2canvas-ignore') !== 'true';
          }
          return true;
        }
      });

      // Restore original image sources
      imgs.forEach((img, i) => {
        img.src = originalSrcs[i];
      });

      el.style.maxHeight = origMaxH;
      el.style.overflow = origOverflow;
      if (innerEl) {
        innerEl.style.maxHeight = origInnerMaxH;
        innerEl.style.overflow = origInnerOverflow;
      }
      
      if (format === 'jpg') {
        const link = document.createElement('a');
        link.download = `borrow_record_${selectedRecord.requestNumber || selectedRecord.id}.jpg`;
        link.href = imgData;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      } else {
        const { jsPDF } = await import('jspdf');
        
        // Ensure image is loaded to get dimensions
        const img = new Image();
        img.src = imgData;
        await new Promise((resolve) => {
          img.onload = resolve;
        });
        
        const pdf = new jsPDF({
          orientation: img.width > img.height ? 'l' : 'p',
          unit: 'px',
          format: [img.width, img.height]
        });
        
        pdf.addImage(imgData, 'JPEG', 0, 0, img.width, img.height);
        pdf.save(`borrow_record_${selectedRecord.requestNumber || selectedRecord.id}.pdf`);
      }

      alert('ບັນທຶກສຳເລັດ! ຟາຍຖືກເກັບໄວ້ໃນໂຟນເດີ Downloads ຂອງທ່ານ\n(Saved to Downloads folder successfully)');
    } catch (err: any) {
      console.error(err);
      alert(`ຂໍອະໄພ, ບໍ່ສາມາດສ້າງຟາຍໄດ້ (Failed to generate export file): ${err.message || 'Unknown error'}`);
    } finally {
      setIsExporting(false);
    }
  };

  const handleRequestExtension = async (e: React.FormEvent, recordId: string) => {
    e.preventDefault();
    if (!extensionDate || !extensionReason) return;
    try {
      await updateDoc(doc(db, 'borrow_records', recordId), {
        extensionRequest: extensionReason,
        extensionDate: extensionDate,
        extensionStatus: 'pending'
      });
      
      try {
        await addDoc(collection(db, 'notifications'), {
          userId: 'admin',
          title: 'Extension Request',
          message: `${selectedRecord?.borrowerEmail} requested an extension until ${extensionDate}.`,
          read: false,
          createdAt: serverTimestamp(),
          type: 'info',
          linkToRecordId: recordId
        });
      } catch (err) {
        console.warn('Could not send notification (rules might be outdated):', err);
      }
      
      setExtensionReason('');
      setExtensionDate('');
      setSelectedRecord(prev => prev ? { ...prev, extensionRequest: extensionReason, extensionDate, extensionStatus: 'pending' } : null);
      alert('ສົ່ງຄຳຂໍຂະຫຍາຍເວລາສຳເລັດແລ້ວ (Extension request submitted successfully)');
    } catch (error: any) {
      console.error("Failed to request extension", error);
      alert(`Failed to request extension: ${error.message}`);
    }
  };

  const handleProcessExtension = async (recordId: string, status: 'approved' | 'rejected') => {
    try {
      const updates: any = {
        extensionStatus: status
      };
      
      if (status === 'approved' && selectedRecord?.extensionDate) {
         updates.plannedReturnDate = selectedRecord.extensionDate;
      }
      
      await updateDoc(doc(db, 'borrow_records', recordId), updates);
      
      try {
        await addDoc(collection(db, 'notifications'), {
          userId: selectedRecord?.borrowerEmail || '',
          title: `Extension ${status === 'approved' ? 'Approved' : 'Rejected'}`,
          message: `Your extension request has been ${status}.`,
          read: false,
          createdAt: serverTimestamp(),
          type: status === 'approved' ? 'info' : 'warning',
          linkToRecordId: recordId
        });
      } catch (err) {
        console.warn('Could not send notification (rules might be outdated):', err);
      }
      
      setSelectedRecord(prev => prev ? { 
        ...prev, 
        extensionStatus: status,
        plannedReturnDate: status === 'approved' && selectedRecord.extensionDate ? selectedRecord.extensionDate : prev.plannedReturnDate
      } : null);
      alert(`ອະນຸມັດ/ປະຕິເສດ ຄຳຂໍສຳເລັດແລ້ວ (Extension request ${status} successfully)`);
    } catch (error: any) {
      console.error("Failed to process extension", error);
      alert(`Failed to process extension: ${error.message}`);
    }
  };

  const filteredRecords = records.filter(record => {
    const matchBorrower = record.borrowerEmail.toLowerCase().includes(borrowerFilter.toLowerCase());
    const matchDept = record.borrowerDepartmentId.toLowerCase().includes(deptFilter.toLowerCase());
    const matchMaterial = record.items?.some(i => i.materialId.toLowerCase().includes(appliedSearch.toLowerCase()) || i.materialDescription.toLowerCase().includes(appliedSearch.toLowerCase())) ?? false;
    const matchStatus = statusFilter === '' 
      ? true 
      : statusFilter === 'wait_confirm_return'
        ? (record.borrowerReturnAcknowledge && record.status !== 'returned')
      : statusFilter === 'pending_approval'
        ? (record.status !== 'returned' && !record.takingConfirmation)
        : record.status === statusFilter;
    const matchBorrowType = borrowTypeFilter === '' || record.borrowType === borrowTypeFilter;
    
    let matchBorrowDate = true;
    if (borrowDateFrom) matchBorrowDate = matchBorrowDate && record.borrowDate >= borrowDateFrom;
    if (borrowDateTo) matchBorrowDate = matchBorrowDate && record.borrowDate <= borrowDateTo + 'T23:59:59';
    
    let matchReturnDate = true;
    if (returnDateFrom) matchReturnDate = matchReturnDate && record.plannedReturnDate >= returnDateFrom;
    if (returnDateTo) matchReturnDate = matchReturnDate && record.plannedReturnDate <= returnDateTo + 'T23:59:59';
    
    return (!borrowerFilter || matchBorrower) && 
           (!deptFilter || matchDept) && 
           (!appliedSearch || matchMaterial) &&
           matchStatus &&
           matchBorrowType &&
           matchBorrowDate &&
           matchReturnDate;
  }).sort((a, b) => {
    const timeA = (a as any).createdAt?.seconds || (a.borrowDate ? new Date(a.borrowDate).getTime() / 1000 : 0);
    const timeB = (b as any).createdAt?.seconds || (b.borrowDate ? new Date(b.borrowDate).getTime() / 1000 : 0);
    return timeB - timeA;
  });

  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;
  const totalPages = Math.ceil(filteredRecords.length / itemsPerPage);
  
  useEffect(() => {
    setCurrentPage(1);
  }, [borrowerFilter, deptFilter, appliedSearch, statusFilter, borrowTypeFilter, borrowDateFrom, borrowDateTo, returnDateFrom, returnDateTo]);

  const startIndex = (currentPage - 1) * itemsPerPage;
  const currentRecords = filteredRecords.slice(startIndex, startIndex + itemsPerPage);

  const openMessageDialog = (record: BorrowRecord) => {
    setMessageRecord(record);
    const itemsStr = record.items?.map(i => `- ${i.materialDescription} (x${i.borrowQty})`).join('\n') || '';
    const borrowDate = format(parseISO(record.borrowDate), 'MMM dd, yyyy HH:mm');
    const returnDate = format(parseISO(record.plannedReturnDate), 'MMM dd, yyyy HH:mm');
    
    const template = `ຂໍ້ມູນແຈ້ງເຕືອນ ເພື່ອການເກັບກຳກວດກາ ສົ່ງຄືນເຄື່ອງທີ່ຢືມ ຂອງທ່ານ ${formatUserName(record.borrowerEmail, appUsers)}\nລາຍການເຄື່ອງທີ່ຢືມ:\n${itemsStr}\nວັນທີຢືມ: ${borrowDate}\nຈຸດປະສົງການຢືມ: ${record.purpose}\nວັນທີສົ່ງຄືນ: ${returnDate}\n\nຖ້າທ່ານຕ້ອງການຂະຫຍາຍເວລາ ກະລຸນາເຂົ້າລະບົບ ເພື່ອຂໍຂະຫຍາຍເວລາ.`;
    setMessageContent(template);
  };

  const handleSendMessage = async () => {
    if (!messageRecord || !messageContent) return;
    
    try {
        await addDoc(collection(db, 'notifications'), {
           userId: messageRecord.borrowerEmail,
           title: 'ແຈ້ງເຕືອນການສົ່ງຄືນເຄື່ອງ / Return Reminder',
           message: messageContent,
           read: false,
           createdAt: serverTimestamp(),
           type: 'warning',
           linkToRecordId: messageRecord.id,
           deliveryMethod: messageDelivery
        });
        
        await updateDoc(doc(db, 'borrow_records', messageRecord.id), {
           remindingMessage: messageContent,
           reminderDate: new Date().toISOString(),
           reminderBy: 'Admin'
        });
        
        if (messageDelivery === 'whatsapp' && messageRecord.borrowerPhone) {
             let phoneStr = messageRecord.borrowerPhone.replace(/[^0-9+]/g, '');
             
             // Format Laos phone numbers correctly
             if (phoneStr.startsWith('020') || phoneStr.startsWith('030')) {
                 phoneStr = '856' + phoneStr.substring(1);
             } else if (phoneStr.length === 8) {
                 // Assume 8 digit numbers are mobile (20)
                 phoneStr = '85620' + phoneStr;
             } else if (phoneStr.length === 10 && (phoneStr.startsWith('20') || phoneStr.startsWith('30'))) {
                 phoneStr = '856' + phoneStr;
             }
             
             // Remove any remaining '+' for the wa.me link
             phoneStr = phoneStr.replace('+', '');
             
             const url = `https://wa.me/${phoneStr}?text=${encodeURIComponent(messageContent)}`;
             window.open(url, '_blank');
        } else if (messageDelivery === 'email') {
             const url = `mailto:${messageRecord.borrowerEmail}?subject=${encodeURIComponent("ແຈ້ງເຕືອນການສົ່ງຄືນເຄື່ອງ / Return Reminder")}&body=${encodeURIComponent(messageContent)}`;
             window.open(url, '_blank');
        }
        
        setMessageRecord(null);
    } catch (e) {
        console.error(e);
        alert('Failed to send message');
    }
  };

  const handleConfirmTaking = async (recordId: string) => {
    if (!isAdmin) {
      alert("Only warehouse admins can confirm pickup.");
      return;
    }
    setIsConfirmingPickup(recordId);
    try {
      await updateDoc(doc(db, 'borrow_records', recordId), {
        takingConfirmation: true,
        status: 'active'
      });
      alert("ການຢືນຢັນການຮັບເຄື່ອງສຳເລັດ! (Pickup confirmed successfully)");
    } catch (error: any) {
      console.error("Failed to confirm taking:", error);
      alert(`ເກີດຂໍ້ຜິດພາດ (Error): ${error.message}`);
    } finally {
      setIsConfirmingPickup(null);
    }
  };

  const handleProcessReturn = async (e: React.FormEvent<HTMLFormElement>, recordId: string) => {
    e.preventDefault();
    if (!isAdmin) {
      alert("Only warehouse admins can process returns.");
      return;
    }
    if (isProcessingReturn) return;
    setIsProcessingReturn(true);
    const formData = new FormData(e.currentTarget);
    const finalReturnDateStr = formData.get('borrowerReturnDate') as string || new Date().toISOString().split('T')[0];
    try {
      const timeoutPromise = <T,>(ms: number, message: string): Promise<T> => new Promise((_, reject) => setTimeout(() => reject(new Error(message)), ms));
      const uploadPhotos = async (photos: string[]) => {
        return await Promise.all(photos.map(async (p, i) => {
          if (p.startsWith('data:')) {
            const r = ref(storage, `borrow_records/${recordId}/return_${Date.now()}_${i}.jpg`);
            await uploadString(r, p, 'data_url');
            return await getDownloadURL(r);
          }
          return p;
        }));
      };
      
      const storagePhotos = await Promise.race([
        uploadPhotos(returnFormPhotos),
        timeoutPromise<string[]>(30000, "ການອັບໂຫຼດຮູບພາບໃຊ້ເວລາດົນເກີນໄປ. ກະລຸນາກວດສອບອິນເຕີເນັດຂອງທ່ານ (Image upload timed out. Please check your internet connection).")
      ]);

      await updateDoc(doc(db, 'borrow_records', recordId), {
        finalReturnDate: new Date(finalReturnDateStr).toISOString(),
        returnQty: Number(formData.get('returnQty')),
        condition: formData.get('condition') as string,
        returnRemarks: (formData.get('returnRemarks') as string) || '',
        returnPhotos: storagePhotos,
        borrowerReturnAcknowledge: true,
        whReturnAcknowledge: true,
        status: 'returned'
      });
      setSelectedRecord(null);
      setReturnFormPhotos([]);
    } catch (error) {
      console.error("Failed to process return:", error);
    } finally {
      setIsProcessingReturn(false);
    }
  };

  const handleBorrowerProcessReturn = async (e: React.FormEvent<HTMLFormElement>, recordId: string) => {
    e.preventDefault();
    if (isAdmin) return;
    if (isProcessingReturn) return;
    setIsProcessingReturn(true);
    
    const formData = new FormData(e.currentTarget);
    const expectedReturnDate = formData.get('borrowerReturnDate') as string;
    
    try {
      const timeoutPromise = <T,>(ms: number, message: string): Promise<T> => new Promise((_, reject) => setTimeout(() => reject(new Error(message)), ms));
      const uploadPhotos = async (photos: string[]) => {
        return await Promise.all(photos.map(async (p, i) => {
          if (p.startsWith('data:')) {
            const r = ref(storage, `borrow_records/${recordId}/borrower_return_${Date.now()}_${i}.jpg`);
            await uploadString(r, p, 'data_url');
            return await getDownloadURL(r);
          }
          return p;
        }));
      };
      
      const storagePhotos = await Promise.race([
        uploadPhotos(returnFormPhotos),
        timeoutPromise<string[]>(30000, "ການອັບໂຫຼດຮູບພາບໃຊ້ເວລາດົນເກີນໄປ. ກະລຸນາກວດສອບອິນເຕີເນັດຂອງທ່ານ (Image upload timed out).")
      ]);

      await updateDoc(doc(db, 'borrow_records', recordId), {
        borrowerReturnAcknowledge: true,
        borrowerReturnDate: expectedReturnDate,
        returnQty: Number(formData.get('returnQty')),
        condition: formData.get('condition') as string,
        returnRemarks: (formData.get('returnRemarks') as string) || '',
        returnPhotos: storagePhotos,
      });

      try {
        await addDoc(collection(db, 'notifications'), {
          userId: 'admin',
          title: 'Return Request (ແຈ້ງສົ່ງເຄື່ອງຄືນ)',
          message: `${selectedRecord?.borrowerEmail} ໄດ້ແຈ້ງສົ່ງເຄື່ອງຄືນ ໃນວັນທີ ${expectedReturnDate}. ກະລຸນາກວດສອບ ແລະ ຢືນຢັນຂັ້ນຕອນສຸດທ້າຍ.`,
          read: false,
          createdAt: serverTimestamp(),
          type: 'info',
          linkToRecordId: recordId
        });
      } catch (err) {
        console.warn('Could not send notification (rules outdated):', err);
      }

      alert("ໄດ້ແຈ້ງສົ່ງເຄື່ອງຄືນສຳເລັດ ພະນັກງານສາງຈະກວດສອບ ແລະ ປິດລາຍການ.");
      setSelectedRecord(null);
      setReturnFormPhotos([]);
    } catch (error) {
      console.error("Failed to process return request:", error);
    } finally {
      setIsProcessingReturn(false);
    }
  };

  return (
    <div className="space-y-4">
      {/* Global Search */}
      <div className="flex flex-col sm:flex-row gap-2 mb-4 bg-white p-3 rounded-xl border border-slate-200 shadow-sm">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
          <input 
            type="text" 
            placeholder="ຄົ້ນຫາລາຍການເຄື່ອງ / Search items (Material ID / Description)..." 
            className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 focus:bg-white focus:border-indigo-300 focus:ring-2 focus:ring-indigo-100 rounded-lg transition-all outline-none text-sm"
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && setAppliedSearch(searchInput.trim())}
          />
        </div>
        <button 
          onClick={() => setAppliedSearch(searchInput.trim())}
          className="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-2 rounded-lg font-semibold text-sm transition-colors flex items-center justify-center gap-2 w-full sm:w-auto shrink-0"
        >
          <Search size={16} /> ຄົ້ນຫາ (Search)
        </button>
      </div>

      {/* Filters */}
      <div className="flex flex-col gap-2 bg-white p-2 rounded-xl border border-slate-200 shadow-sm">
        <div className="flex flex-wrap items-center gap-2">
          <div className="relative flex-[1_1_150px] min-w-[150px]">
            <User className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={14} />
            <input 
              type="text" 
              placeholder="Borrower..." 
              className="w-full pl-8 pr-3 py-1.5 bg-slate-50 border border-transparent focus:bg-white focus:border-indigo-300 focus:ring-2 focus:ring-indigo-100 rounded-lg transition-all outline-none text-xs"
              value={borrowerFilter}
              onChange={(e) => setBorrowerFilter(e.target.value)}
            />
          </div>
          <div className="relative flex-[1_1_150px] min-w-[150px]">
            <Building2 className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={14} />
            <input 
              type="text" 
              placeholder="Department..." 
              className="w-full pl-8 pr-3 py-1.5 bg-slate-50 border border-transparent focus:bg-white focus:border-indigo-300 focus:ring-2 focus:ring-indigo-100 rounded-lg transition-all outline-none text-xs"
              value={deptFilter}
              onChange={(e) => setDeptFilter(e.target.value)}
            />
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <div className="relative flex-[1_1_150px] min-w-[150px]">
            <select 
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="w-full px-3 py-1.5 bg-slate-50 border border-transparent focus:bg-white focus:border-indigo-300 focus:ring-2 focus:ring-indigo-100 rounded-lg transition-all outline-none text-xs text-slate-700"
            >
              <option value="">All Statuses</option>
              <option value="pending_approval">Pending / ລາຍຢືມໃໝ່ ອະນຸມັດ</option>
              <option value="active">In Uses</option>
              <option value="wait_confirm_return">Confirm Return</option>
              <option value="overdue">Overdue</option>
              <option value="returned">Returned</option>
              <option value="deactivated">Deactivated</option>
            </select>
          </div>
          <div className="relative flex-[1_1_150px] min-w-[150px]">
            <select 
              value={borrowTypeFilter}
              onChange={(e) => setBorrowTypeFilter(e.target.value)}
              className="w-full px-3 py-1.5 bg-slate-50 border border-transparent focus:bg-white focus:border-indigo-300 focus:ring-2 focus:ring-indigo-100 rounded-lg transition-all outline-none text-xs text-slate-700"
            >
              <option value="">All Types (ປະເພດເຄື່ອງ)</option>
              <option value="new_inventory">New Inventory</option>
              <option value="deposited_tools">Deposited Tools</option>
              <option value="others">Others</option>
            </select>
          </div>
          <div className="flex-[1_1_150px] min-w-[300px] flex flex-col gap-1">
            <span className="text-[10px] font-bold text-slate-500 uppercase">Borrow Date</span>
            <div className="flex items-center gap-2">
              <input 
                type="date"
                title="Borrow Date From"
                value={borrowDateFrom}
                onChange={(e) => setBorrowDateFrom(e.target.value)}
                className="flex-1 px-3 py-1.5 bg-slate-50 border border-transparent focus:bg-white focus:border-indigo-300 focus:ring-2 focus:ring-indigo-100 rounded-lg transition-all outline-none text-xs"
              />
              <span className="text-xs text-slate-500">-</span>
              <input 
                type="date"
                title="Borrow Date To"
                value={borrowDateTo}
                onChange={(e) => setBorrowDateTo(e.target.value)}
                className="flex-1 px-3 py-1.5 bg-slate-50 border border-transparent focus:bg-white focus:border-indigo-300 focus:ring-2 focus:ring-indigo-100 rounded-lg transition-all outline-none text-xs"
              />
            </div>
          </div>
          <div className="flex-[1_1_150px] min-w-[300px] flex flex-col gap-1">
            <span className="text-[10px] font-bold text-slate-500 uppercase">Return Date</span>
            <div className="flex items-center gap-2">
              <input 
                type="date"
                title="Return Date From"
                value={returnDateFrom}
                onChange={(e) => setReturnDateFrom(e.target.value)}
                className="flex-1 px-3 py-1.5 bg-slate-50 border border-transparent focus:bg-white focus:border-indigo-300 focus:ring-2 focus:ring-indigo-100 rounded-lg transition-all outline-none text-xs"
              />
              <span className="text-xs text-slate-500">-</span>
              <input 
                type="date"
                title="Return Date To"
                value={returnDateTo}
                onChange={(e) => setReturnDateTo(e.target.value)}
                className="flex-1 px-3 py-1.5 bg-slate-50 border border-transparent focus:bg-white focus:border-indigo-300 focus:ring-2 focus:ring-indigo-100 rounded-lg transition-all outline-none text-xs"
              />
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse min-w-[900px]">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-xs text-slate-500 uppercase tracking-wider">
                <th className="p-4 font-bold border-r border-slate-100 min-w-[150px]">ຊື່ຜູ້ ຢືມ (Borrower)</th>
                <th className="p-4 font-bold border-r border-slate-100 min-w-[200px]">ເຄື່ອງທີ່ຢືມ (Items)</th>
                <th className="p-4 font-bold border-r border-slate-100">ລະຫັດເຄື່ອງ (Material ID)</th>
                <th className="p-4 font-bold border-r border-slate-100 min-w-[140px]">ວັນທີ ເວລາ (Date)</th>
                <th className="p-4 font-bold border-r border-slate-100">ສະຖານະ (Status)</th>
                <th className="p-4 font-bold min-w-[160px]">ເບິ່ງລາຍລະອຽດ (Actions)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-sm">
              {currentRecords.map((record) => {
                    const isPastDue = record.status === 'active' && record.plannedReturnDate && new Date() > new Date(record.plannedReturnDate);
                    return (
                <tr key={record.id} className="hover:bg-slate-50 transition-colors group">
                  <td className="p-4 align-top border-r border-slate-100">
                    <div className="font-bold text-slate-900">{formatUserName(record.borrowerEmail, appUsers)}</div>
                    <div className="text-xs text-slate-500 mt-1">{record.borrowerDepartmentId}</div>
                  </td>
                  <td className="p-4 align-top border-r border-slate-100">
                    <div className="flex items-start gap-3">
                      <div 
                        className={cn("w-10 h-10 rounded-lg bg-slate-100 flex items-center justify-center border border-slate-200 shrink-0 overflow-hidden", record.items?.[0]?.materialPhotos?.[0] ? "cursor-pointer" : "")}
                        onClick={(e) => {
                          e.stopPropagation();
                          if (record.items?.[0]?.materialPhotos?.[0]) {
                            setViewingImage(record.items[0].materialPhotos[0]);
                          }
                        }}
                      >
                        {record.items?.[0]?.materialPhotos?.[0] ? (
                           <img src={record.items[0].materialPhotos[0]} alt="Material" className="w-full h-full object-cover hover:scale-110 transition-transform" referrerPolicy="no-referrer" />
                        ) : (
                          <Package size={16} className="text-slate-400" />
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="font-bold text-slate-900 line-clamp-2" title={record.items?.map(i => i.materialDescription).join(', ')}>
                          {record.items?.map(i => i.materialDescription).join(', ') || 'Unknown Items'}
                        </div>
                        <div className="text-xs text-slate-500 mt-1">
                          Qty: {(record.items?.reduce((acc, i) => acc + i.borrowQty, 0) || 0).toLocaleString()} • {record.purpose}
                        </div>
                      </div>
                    </div>
                  </td>
                  <td className="p-4 align-top border-r border-slate-100">
                    <div className="flex flex-col gap-1">
                      {record.items?.map((item, idx) => (
                        <span key={idx} className="font-mono text-[10px] sm:text-xs font-bold text-slate-600 px-2 py-1 bg-slate-100 rounded-md whitespace-nowrap block w-fit truncate max-w-[150px]" title={item.materialId}>
                          {item.materialId}
                        </span>
                      ))}
                    </div>
                  </td>
                  <td className="p-4 align-top border-r border-slate-100">
                    <div className="font-medium text-slate-800 whitespace-nowrap">
                      {format(parseISO(record.borrowDate), 'MMM dd, yyyy')}
                    </div>
                    <div className="text-xs text-slate-500">
                      {format(parseISO(record.borrowDate), 'HH:mm')}
                    </div>
                    {record.plannedReturnDate && (
                      <div className="mt-2 pt-2 border-t border-slate-100">
                        <span className="text-[10px] uppercase text-slate-400 font-bold block">ສົ່ງຄືນ (Return):</span>
                        <span className={cn("text-xs font-bold whitespace-nowrap", record.status === 'overdue' || isPastDue ? "text-red-600" : "text-slate-600")}>
                          {format(parseISO(record.plannedReturnDate), 'MMM dd, yyyy HH:mm')}
                        </span>
                      </div>
                    )}
                  </td>
                  <td className="p-4 align-top border-r border-slate-100">
                    <div className="flex flex-col gap-1.5 items-start">
                      <span className={cn(
                        "text-xs px-2.5 py-1 rounded-full font-bold uppercase w-fit inline-flex items-center gap-1.5",
                        record.status === 'deactivated' ? "bg-amber-100 text-amber-700" :
                        (record.borrowerReturnAcknowledge && record.status !== 'returned') ? "bg-orange-100 text-blue-900" :
                        record.status === 'overdue' || isPastDue ? "bg-red-100 text-red-700" : 
                        record.status === 'active' ? "bg-indigo-100 text-indigo-700" : "bg-emerald-100 text-emerald-700"
                      )}>
                        {record.status === 'returned' && <CheckCircle2 size={12} />}
                        {record.status !== 'returned' && !record.borrowerReturnAcknowledge && <Clock size={12} />}
                        {(record.borrowerReturnAcknowledge && record.status !== 'returned') && <AlertTriangle size={12} />}
                        {(record.borrowerReturnAcknowledge && record.status !== 'returned') ? 'Confirm Return' : record.status === 'active' ? 'In Uses' : record.status.charAt(0).toUpperCase() + record.status.slice(1)}
                      </span>
                      {record.status === 'overdue' && (
                        <div className="text-[10px] text-red-500 font-bold">Overdue {record.overdueDays}d</div>
                      )}
                      {(record.status === 'active' || isPastDue) && record.plannedReturnDate && (
                        <div className={cn("text-[10px] font-bold", isPastDue ? "text-red-500" : "text-indigo-500")}>
                          {isPastDue ? "Overdue" : `In ${Math.max(0, differenceInDays(parseISO(record.plannedReturnDate), new Date()))}d`}
                        </div>
                      )}
                      {record.remindingMessage && (
                        <span className="text-[10px] text-emerald-600 font-semibold flex items-center gap-1 px-2 py-1 bg-emerald-50 rounded-full w-fit">
                          <Send size={10} /> Sent
                        </span>
                      )}
                    </div>
                  </td>
                  <td className="p-4 align-top">
                    <div className="flex flex-wrap items-center gap-2">
                      <button 
                        onClick={() => {
                          setSelectedRecord(record);
                          setReturnFormPhotos(record.returnPhotos || []);
                        }}
                        className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-bold transition-colors whitespace-nowrap"
                      >
                        View Details
                      </button>
                      {isAdmin && record.status !== 'returned' && (
                        <button 
                          onClick={() => openMessageDialog(record)}
                          className="p-2 bg-amber-100 hover:bg-amber-200 text-amber-700 rounded-lg transition-colors"
                          title="Send Reminder"
                        >
                          <Send size={14} />
                        </button>
                      )}
                      {isAdmin && record.status !== 'returned' && !record.takingConfirmation && (
                        <button 
                          onClick={() => handleConfirmTaking(record.id)}
                          disabled={isConfirmingPickup === record.id}
                          className="p-2 border border-slate-200 bg-white hover:bg-indigo-50 hover:border-indigo-200 text-indigo-600 rounded-lg transition-colors shadow-sm disabled:opacity-50"
                          title="Confirm Pickup"
                        >
                          {isConfirmingPickup === record.id ? (
                            <span className="w-3.5 h-3.5 border-2 border-indigo-300 border-t-indigo-600 rounded-full animate-spin block"></span>
                          ) : (
                            <CheckCircle2 size={14} />
                          )}
                        </button>
                      )}
                      {isAdmin && !record.takingConfirmation && (
                        <>
                          <button 
                            onClick={() => onToggleDeactivate(record.id, record.status)}
                            className={cn(
                              "p-2 rounded-lg transition-colors",
                              record.status === 'deactivated' ? "text-amber-500 hover:bg-amber-50" : "text-slate-500 hover:bg-slate-100"
                            )}
                            title={record.status === 'deactivated' ? "Activate Record" : "Deactivate Record"}
                          >
                            <PowerOff size={14} />
                          </button>
                          <button 
                            onClick={() => onDelete(record.id)}
                            className="p-2 text-rose-500 hover:bg-rose-50 rounded-lg transition-colors"
                            title="Delete Record"
                          >
                            <Trash2 size={14} />
                          </button>
                        </>
                      )}
                    </div>
                  </td>
                </tr>
              );
            })}
            </tbody>
          </table>
        </div>
      </div>
      
      {totalPages > 1 && (
        <div className="flex items-center justify-between bg-white p-4 rounded-2xl border border-slate-200 shadow-sm">
          <button 
            onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
            disabled={currentPage === 1}
            className="px-4 py-2 border border-slate-200 rounded-xl text-sm font-bold text-slate-600 hover:bg-slate-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            Previous
          </button>
          <span className="text-sm text-slate-500 font-medium">Page {currentPage} of {totalPages}</span>
          <button 
            onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
            disabled={currentPage === totalPages}
            className="px-4 py-2 border border-slate-200 rounded-xl text-sm font-bold text-slate-600 hover:bg-slate-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            Next
          </button>
        </div>
      )}

      {/* Details Modal */}
      <AnimatePresence>
        {selectedRecord && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => { if (!isProcessingReturn) setSelectedRecord(null); }}
              className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              id="record-details-capture"
              className="bg-white w-full max-w-4xl max-h-[90vh] rounded-3xl shadow-2xl overflow-hidden flex flex-col relative z-10"
            >
              <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-white shrink-0 z-10">
                <h2 className="text-xl font-bold">
                  Borrowing Record Details
                  <span className="ml-2 text-indigo-600">[{selectedRecord.requestNumber || (selectedRecord.id ? selectedRecord.id.slice(0,8).toUpperCase() : '')}]</span>
                </h2>
                <button 
                  onClick={() => { if (!isProcessingReturn) setSelectedRecord(null); }}
                  disabled={isProcessingReturn}
                  className="p-2 hover:bg-slate-100 rounded-full transition-colors disabled:opacity-50"
                >
                  <X size={20} />
                </button>
              </div>
              
              <div className="flex-1 overflow-y-auto p-4 sm:p-8 custom-scrollbar relative">
                <div className="max-w-4xl mx-auto space-y-8">
                  {/* Print Document Layout */}
                  <div className="bg-white px-3 py-6 sm:py-8 sm:px-10 text-slate-900 border border-slate-200 shadow-sm rounded-xl print:shadow-none print:border-none print:p-0" style={{ borderCollapse: 'collapse' }}>
                    <div className="text-center bg-slate-200 border border-slate-800 p-2 mb-4 font-bold sm:text-lg text-base uppercase tracking-wider leading-tight">
                      ບັນທຶກລາຍລະອຽດ ການຢືມເຄື່ອງ<br className="sm:hidden" /><span className="sm:hidden"> </span>(Borrowing Record Details)
                    </div>

                    {/* Info Section 1: Basic Info */}
                    <table className="w-full border-collapse mb-5 text-xs sm:text-sm [&_th]:border [&_th]:border-slate-800 [&_th]:p-1.5 [&_td]:border [&_td]:border-slate-800 [&_td]:p-1.5 [&_td]:px-2.5">
                      <tbody>
                        <tr>
                          <td className="font-bold bg-slate-50 w-[25%] sm:w-[20%]">ໃບຢືມເລກທີ / REQ No.</td>
                          <td className="w-[25%] sm:w-[30%] text-indigo-700 font-bold">{selectedRecord.requestNumber || (selectedRecord.id ? selectedRecord.id.slice(0,8).toUpperCase() : '')}</td>
                          <td className="font-bold bg-slate-50 w-[25%] sm:w-[20%]">ປະເພດຢືມ / Borrow Type</td>
                          <td className="w-[25%] sm:w-[30%]">
                            {selectedRecord.borrowType === 'new_inventory' ? 'ຢືມເຄື່ອງໃໝ່ (New Inventory)' : selectedRecord.borrowType === 'deposited_tools' ? 'ຢືມເຄື່ອງຝາກ (Deposited Tools)' : `ອື່ນໆ: ${selectedRecord.borrowTypeOthersDetail || ''}`}
                          </td>
                        </tr>
                        <tr>
                          <td className="font-bold bg-slate-50">ຜູ້ຢືມ / Borrower Name</td>
                          <td>{formatUserName(selectedRecord.borrowerEmail, appUsers)}</td>
                          <td className="font-bold bg-slate-50">ເບີໂທ / Phone</td>
                          <td>{selectedRecord.borrowerPhone}</td>
                        </tr>
                        <tr>
                          <td className="font-bold bg-slate-50">ໜ່ວຍງານ / Unit</td>
                          <td>{selectedRecord.borrowerUnitId}</td>
                          <td className="font-bold bg-slate-50">ພະແນກ / Department</td>
                          <td>{selectedRecord.borrowerDepartmentId}</td>
                        </tr>
                        <tr>
                          <td className="font-bold bg-slate-50">ຢືມວັນທີ / Borrow Date</td>
                          <td>{selectedRecord.borrowDate ? format(parseISO(selectedRecord.borrowDate), 'dd/MM/yyyy HH:mm') : ''}</td>
                          <td className="font-bold bg-slate-50">ຈຸດປະສົງ / Purpose</td>
                          <td>{selectedRecord.purpose}</td>
                        </tr>
                        <tr>
                          <td className="font-bold bg-slate-50">ກຳນົດວັນທີສົ່ງ / Due Date</td>
                          <td>{selectedRecord.plannedReturnDate ? format(parseISO(selectedRecord.plannedReturnDate), 'dd/MM/yyyy HH:mm') : ''} ({selectedRecord.periodDays} ມື້)</td>
                          <td className="font-bold bg-slate-50">ສະຖານະ / Status</td>
                          <td className={cn("font-bold", selectedRecord.status === 'returned' ? "text-slate-600" : selectedRecord.status === 'overdue' ? "text-red-600" : "text-emerald-600")}>
                            {selectedRecord.status === 'returned' ? 'Returned (ສົ່ງຄືນແລ້ວ)' : 
                             selectedRecord.status === 'overdue' ? 'Overdue (ກາຍກຳນົດ)' : 
                             'Active (ກຳລັງນຳໃຊ້)'}
                          </td>
                        </tr>
                      </tbody>
                    </table>

                    {/* Info Section 2: Items List */}
                    <div className="font-bold mb-1.5 text-sm text-slate-800">ລາຍການເຄື່ອງທີ່ຢືມ (Borrowed Items)</div>
                    <table className="w-full border-collapse mb-5 text-xs sm:text-sm text-center [&_th]:border [&_th]:border-slate-800 [&_th]:p-1.5 [&_td]:border [&_td]:border-slate-800 [&_td]:p-1.5 [&_td]:px-2.5">
                      <thead className="bg-slate-100 font-bold">
                        <tr>
                          <th className="w-8 sm:w-12">#</th>
                          <th className="w-20 sm:w-28">ລະຫັດເຄື່ອງ<br/><span className="text-[10px] sm:text-xs font-normal">Item ID</span></th>
                          <th className="text-left px-3">ລາຍລະອຽດອຸປະກອນ<br/><span className="text-[10px] sm:text-xs font-normal">Description</span></th>
                          <th className="w-20 sm:w-28">ຮູບພາບ<br/><span className="text-[10px] sm:text-xs font-normal">Photo</span></th>
                          <th className="w-12 sm:w-16">ຈຳນວນ<br/><span className="text-[10px] sm:text-xs font-normal">Qty</span></th>
                        </tr>
                      </thead>
                      <tbody>
                        {selectedRecord.items?.map((item, index) => {
                          const itemPhotos = item.materialPhotos?.length > 0 ? item.materialPhotos : (item.stockPhotos || []);
                          return (
                            <tr key={index}>
                              <td>{index + 1}</td>
                              <td className="break-all relative group px-2 font-mono">
                                {item.materialId}
                                {isAdmin && selectedRecord.borrowType !== 'new_inventory' && (
                                  <button 
                                    onClick={() => handleEditItem(index, item)} 
                                    className="absolute top-1 right-1 text-indigo-500 hover:text-indigo-700 bg-white/90 shadow rounded opacity-0 group-hover:opacity-100 transition-opacity p-1" data-html2canvas-ignore="true" title="Edit Item Details"
                                  ><Edit2 size={12} /></button>
                                )}
                              </td>
                              <td className="text-left px-3">
                                {editingItemIndex === index ? (
                                  <div className="space-y-2 py-1" data-html2canvas-ignore="true">
                                    <input className="w-full text-xs p-1.5 border border-slate-300 rounded outline-none focus:border-indigo-500" value={editingMaterialId} onChange={e => setEditingMaterialId(e.target.value)} placeholder="Material ID" />
                                    <textarea className="w-full text-xs p-1.5 border border-slate-300 rounded outline-none focus:border-indigo-500" value={editingMaterialDescription} onChange={e => setEditingMaterialDescription(e.target.value)} placeholder="Description" rows={2}/>
                                    <div className="flex gap-1.5 justify-end mt-2">
                                      <button onClick={() => setEditingItemIndex(null)} className="px-2 py-1 bg-slate-200 text-xs rounded font-medium hover:bg-slate-300">Cancel</button>
                                      <button onClick={handleSaveItemEdit} className="px-3 py-1 bg-indigo-600 text-white font-medium text-xs rounded hover:bg-indigo-700">Save</button>
                                    </div>
                                  </div>
                                ) : item.materialDescription}
                              </td>
                              <td>
                                <div className="flex flex-wrap items-center justify-center gap-1.5 py-1">
                                  {itemPhotos.length > 0 ? itemPhotos.slice(0, 1).map((photo, pIdx) => (
                                    <div key={pIdx} onClick={() => setViewingImage(photo)} className="w-10 h-10 sm:w-16 sm:h-16 bg-slate-200 border border-slate-300 flex items-center justify-center text-[10px] text-slate-500 rounded overflow-hidden cursor-pointer hover:ring-2 hover:ring-indigo-400 transition-all">
                                      <img src={photo} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                                    </div>
                                  )) : <div className="w-10 h-10 sm:w-16 sm:h-16 bg-slate-100 border border-slate-300 flex items-center justify-center text-[10px] text-slate-400 rounded">NO IMG</div>}
                                </div>
                              </td>
                              <td className="font-bold text-base">{item.borrowQty}</td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>

                    {/* Info Section 3: Approvals */}
                    <div className="font-bold mb-1.5 text-sm">ການຢັ້ງຢືນການອະນຸມັດ ແລະ ຮັບເຄື່ອງ (Approvals & Pickup)</div>
                    <table className="w-full border-collapse mb-5 text-xs sm:text-sm [&_th]:border [&_th]:border-slate-800 [&_th]:p-1.5 [&_td]:border [&_td]:border-slate-800 [&_td]:p-1.5 [&_td]:px-2.5">
                      <tbody>
                        <tr>
                          <td className="font-bold bg-slate-50 w-[20%]">ຜູ້ອະນຸມັດ (Manager)</td>
                          <td className="w-[30%] text-slate-700">{selectedRecord.managerAcknowledge || '-'}</td>
                          <td className="font-bold bg-slate-50 w-[20%]">ສາງອະນຸມັດ (WH Admin)</td>
                          <td className="w-[30%] text-slate-700">{selectedRecord.whApprover || '-'}</td>
                        </tr>
                        <tr>
                          <td className="font-bold bg-slate-50">ຜູ້ຢືມຮັບເຄື່ອງແລ້ວ<br/><span className="text-[10px] font-normal">User Took Items</span></td>
                          <td colSpan={3} className={cn("font-bold text-base", selectedRecord.takingConfirmation ? "text-emerald-600" : "text-amber-600")}>
                            {selectedRecord.takingConfirmation ? '✓ ຮັບເຄື່ອງແລ້ວ (Confirmed)' : 'ລໍຖ້າຮັບເຄື່ອງ (Pending)'}
                          </td>
                        </tr>
                      </tbody>
                    </table>

                    {/* Info Section 4: Extension Details */}
                    {selectedRecord.extensionStatus && (
                      <>
                        <div className="font-bold mb-1.5 text-sm">ການຕໍ່ເວລາ (Time Extension)</div>
                        <table className="w-full border-collapse mb-5 text-xs sm:text-sm [&_th]:border [&_th]:border-slate-800 [&_th]:p-1.5 [&_td]:border [&_td]:border-slate-800 [&_td]:p-1.5 [&_td]:px-2.5">
                          <tbody>
                            <tr>
                              <td className="font-bold bg-slate-50 w-[20%]">ສະຖານະຂໍຕໍ່ເວລາ</td>
                              <td className={cn("w-[30%] font-bold uppercase", selectedRecord.extensionStatus === 'approved' ? 'text-emerald-600' : selectedRecord.extensionStatus === 'rejected' ? 'text-red-600' : 'text-amber-600')}>{selectedRecord.extensionStatus}</td>
                              <td className="font-bold bg-slate-50 w-[20%]">ວັນທີຂໍຕໍ່ເວລາໄປຫາ</td>
                              <td className="w-[30%] font-medium">{selectedRecord.extensionDate ? format(parseISO(selectedRecord.extensionDate), 'dd/MM/yyyy HH:mm') : '-'}</td>
                            </tr>
                            <tr>
                              <td className="font-bold bg-slate-50">ເຫດຜົນຂໍຕໍ່ເວລາ</td>
                              <td colSpan={3} className="text-slate-700 font-medium whitespace-pre-wrap">"{selectedRecord.extensionRequest}"</td>
                            </tr>
                          </tbody>
                        </table>
                      </>
                    )}

                    {/* Info Section 5: Return Details */}
                    <div className="text-center bg-slate-200 border border-slate-800 p-2 mt-6 mb-4 font-bold text-base sm:text-lg">
                      ລາຍລະອຽດການສົ່ງຄືນ (Return Details)
                    </div>
                    
                    <table className="w-full border-collapse mb-8 text-xs sm:text-sm [&_th]:border [&_th]:border-slate-800 [&_th]:p-1.5 [&_td]:border [&_td]:border-slate-800 [&_td]:p-1.5 [&_td]:px-2.5">
                      <tbody>
                        <tr>
                          <td className="font-bold bg-slate-50 w-[25%]">ຜູ້ຢືມແຈ້ງສົ່ງວັນທີ<br/><span className="text-[10px] font-normal text-slate-500">Borrower Return Date</span></td>
                          <td className="w-[25%] font-medium text-slate-700">{selectedRecord.borrowerReturnDate ? format(parseISO(selectedRecord.borrowerReturnDate), 'dd/MM/yyyy HH:mm') : '-'}</td>
                          <td className="font-bold bg-slate-50 w-[25%]">ສະຖານະສາງຮັບຄືນ<br/><span className="text-[10px] font-normal text-slate-500">WH Return Status</span></td>
                          <td className={cn("w-[25%] font-bold text-base", selectedRecord.whReturnAcknowledge ? "text-emerald-600" : selectedRecord.borrowerReturnAcknowledge ? "text-amber-600" : "text-slate-400")}>
                            {selectedRecord.whReturnAcknowledge ? '✓ ຮັບຄືນແລ້ວ (Confirmed)' : selectedRecord.borrowerReturnAcknowledge ? 'ລໍຖ້າຮັບເຄື່ອງ (Pending)' : '-'}
                          </td>
                        </tr>
                        <tr>
                          <td className="font-bold bg-slate-50">ຈຳນວນທີ່ສົ່ງຄືນ<br/><span className="text-[10px] font-normal text-slate-500">Return Qty</span></td>
                          <td className="font-bold text-lg">{selectedRecord.returnQty ?? '-'}</td>
                          <td className="font-bold bg-slate-50">ສະພາບເຄື່ອງ<br/><span className="text-[10px] font-normal text-slate-500">Condition</span></td>
                          <td className="font-medium text-slate-700">{selectedRecord.condition || '-'}</td>
                        </tr>
                        <tr>
                          <td className="font-bold bg-slate-50">ໝາຍເຫດສົ່ງຄືນ<br/><span className="text-[10px] font-normal text-slate-500">Return Remarks</span></td>
                          <td colSpan={3} className="text-slate-700 font-medium whitespace-pre-wrap">{selectedRecord.returnRemarks || '-'}</td>
                        </tr>
                        <tr>
                          <td className="font-bold bg-slate-50">ໝາຍເຫດຈາກສາງ<br/><span className="text-[10px] font-normal text-slate-500">Admin Notes</span></td>
                          <td colSpan={3} className="text-slate-700 font-medium whitespace-pre-wrap">{selectedRecord.additionalInfo || '-'}</td>
                        </tr>
                        <tr>
                          <td className="font-bold bg-slate-50">ຮູບພາບຕອນສົ່ງຄືນ<br/><span className="text-[10px] font-normal text-slate-500">Return Photos</span></td>
                          <td colSpan={3}>
                            <div className="flex flex-wrap gap-2 py-2">
                              {(selectedRecord.returnPhotos || []).map((photo, i) => (
                                <div key={i} onClick={() => setViewingImage(photo)} className="w-14 h-14 sm:w-16 sm:h-16 border border-slate-300 flex items-center justify-center bg-slate-100 rounded-lg overflow-hidden cursor-pointer hover:ring-2 hover:ring-indigo-400 transition-all">
                                   <img src={photo} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                                </div>
                              ))}
                              {(!selectedRecord.returnPhotos || selectedRecord.returnPhotos.length === 0) && (
                                <div className="text-slate-400 text-xs italic py-2">No return photos provided.</div>
                              )}
                            </div>
                          </td>
                        </tr>
                      </tbody>
                    </table>

                    {/* Signatures */}
                    <div className="flex flex-col sm:flex-row justify-between pt-6 mb-6 pb-6 text-sm text-center px-4 sm:px-12">
                      <div className="w-full sm:w-64 mb-14 sm:mb-0">
                        <p className="font-bold mb-16 text-slate-700">ລາຍເຊັນ ຜູ້ຢືມ (Borrower)</p>
                        <div className="border-b border-black w-48 mx-auto mb-2 opacity-50"></div>
                        <p className="font-bold text-slate-700">{formatUserName(selectedRecord.borrowerEmail, appUsers) || '...........................'}</p>
                        <p className="text-[10px] font-medium text-slate-500 mt-1">ວັນທີ: {selectedRecord.borrowDate ? format(parseISO(selectedRecord.borrowDate), 'dd/MM/yyyy HH:mm') : '.........................'}</p>
                      </div>
                      <div className="w-full sm:w-64">
                        <p className="font-bold mb-16 text-slate-700">ລາຍເຊັນ ທີມສາງ (Admin)</p>
                        <div className="border-b border-black w-48 mx-auto mb-2 opacity-50"></div>
                        <p className="font-bold text-slate-700">{formatUserName(selectedRecord.approverEmail || currentUserEmail || '', appUsers) || selectedRecord.whApprover || 'Warehouse Team'}</p>
                        <p className="text-[10px] font-medium text-slate-500 mt-1">ວັນທີ: {format(new Date(), 'dd/MM/yyyy HH:mm')}</p>
                      </div>
                    </div>
                  </div>

                  {/* INTERACTIVE SECTIONS (Not Printed) */}
                  <div className="space-y-6 pb-20" data-html2canvas-ignore="true">
                    
                    {/* Interactive taking confirmation */}
                    {isAdmin && selectedRecord.status !== 'returned' && !selectedRecord.takingConfirmation && (
                        <div className="p-5 bg-indigo-50 border border-indigo-100 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-5 shadow-sm">
                          <div>
                             <p className="text-sm font-bold text-indigo-900 mb-1 flex items-center gap-2"><CheckCircle2 size={18}/> Confirm Pickup</p>
                             <p className="text-xs text-indigo-700">Acknowledge that the borrower has taken the items from the warehouse.</p>
                          </div>
                          <button 
                            onClick={() => handleConfirmTaking(selectedRecord.id)}
                            disabled={isConfirmingPickup === selectedRecord.id}
                            className="px-6 py-2.5 text-white text-sm font-bold rounded-xl transition-all flex items-center justify-center min-w-[160px] bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 shadow-md text-center"
                          >
                            {isConfirmingPickup === selectedRecord.id ? (
                              <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin block"></span>
                            ) : "Confirm Pickup"}
                          </button>
                        </div>
                    )}

                    {/* Interactive Request Extension */}
                    {!selectedRecord.extensionStatus && selectedRecord.borrowerEmail?.toLowerCase() === currentUserEmail?.toLowerCase() && selectedRecord.status !== 'returned' && (
                        <div className="p-6 bg-slate-50 border border-slate-200 rounded-2xl shadow-sm">
                           <h3 className="text-sm font-bold text-slate-800 mb-4 flex items-center gap-2"><CalendarClock size={18} className="text-indigo-600"/> Request Time Extension</h3>
                           <form onSubmit={(e) => handleRequestExtension(e, selectedRecord.id)} className="grid grid-cols-1 sm:grid-cols-4 gap-4 border-t border-slate-100 pt-4">
                              <div className="space-y-1 sm:col-span-1">
                                <label className="text-[10px] font-bold text-slate-500 uppercase">New Extension Date</label>
                                <input 
                                  type="date" 
                                  value={extensionDate}
                                  onChange={e => setExtensionDate(e.target.value)}
                                  min={selectedRecord.plannedReturnDate?.split('T')[0]}
                                  className="w-full p-2.5 bg-white border border-slate-200 rounded-xl text-sm outline-none focus:border-indigo-500 shadow-sm" 
                                  required 
                                />
                              </div>
                              <div className="space-y-1 sm:col-span-3">
                                <label className="text-[10px] font-bold text-slate-500 uppercase">Reason for Extension</label>
                                <div className="flex flex-col sm:flex-row gap-3">
                                  <input 
                                    value={extensionReason}
                                    onChange={e => setExtensionReason(e.target.value)}
                                    className="w-full p-2.5 bg-white border border-slate-200 rounded-xl text-sm outline-none focus:border-indigo-500 shadow-sm" 
                                    placeholder="Why do you need more time?"
                                    required 
                                  />
                                  <button type="submit" className="px-6 py-2.5 bg-slate-800 text-white text-sm font-bold rounded-xl hover:bg-slate-900 whitespace-nowrap shadow transition-colors">
                                    Request Extension
                                  </button>
                                </div>
                              </div>
                           </form>
                        </div>
                    )}

                    {/* Admin Process Extension */}
                    {isAdmin && selectedRecord.extensionStatus === 'pending' && selectedRecord.status !== 'returned' && (
                       <div className="p-6 bg-amber-50 border border-amber-200 rounded-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-5 shadow-sm">
                          <div>
                             <p className="text-sm font-bold text-amber-900 flex items-center gap-2"><Clock size={18}/> Review Extension Request</p>
                             <div className="mt-2 text-sm bg-white/60 p-3 rounded-lg border border-amber-100/50">
                               <p className="text-amber-800 font-bold mb-1">Requested to: {format(parseISO(selectedRecord.extensionDate || new Date().toISOString()), 'dd/MM/yyyy')}</p>
                               <p className="text-amber-700 italic">"{selectedRecord.extensionRequest}"</p>
                             </div>
                          </div>
                          <div className="flex gap-3 w-full sm:w-auto">
                            <button
                              type="button" 
                              onClick={() => handleProcessExtension(selectedRecord.id, 'approved')}
                              className="flex-1 sm:flex-none px-6 py-2.5 bg-emerald-600 text-white rounded-xl text-sm font-bold hover:bg-emerald-700 shadow transition-colors"
                            >
                              Approve
                            </button>
                            <button
                              type="button"
                              onClick={() => handleProcessExtension(selectedRecord.id, 'rejected')}
                              className="flex-1 sm:flex-none px-6 py-2.5 bg-red-600 text-white rounded-xl text-sm font-bold hover:bg-red-700 shadow transition-colors"
                            >
                              Reject
                            </button>
                          </div>
                       </div>
                    )}

                    {/* Return Process Forms */}
                    {selectedRecord.status !== 'returned' && (isAdmin || (selectedRecord.borrowerEmail?.toLowerCase() === currentUserEmail?.toLowerCase() && !selectedRecord.borrowerReturnAcknowledge)) && (
                        <div className="p-6 bg-slate-100 border border-slate-200 rounded-2xl shadow-inner">
                           <h3 className="text-base font-bold text-slate-800 mb-6 flex items-center gap-2">
                             <PackageCheck className={isAdmin ? "text-indigo-600" : "text-emerald-600"} size={20}/> 
                             {isAdmin ? 'Process Return (ສຳລັບສາງຮັບເຄື່ອງ)' : 'ແຈ້ງສົ່ງເຄື່ອງຄືນ (Submit Return Details)'}
                           </h3>
                           <form onSubmit={(e) => isAdmin ? handleProcessReturn(e, selectedRecord.id) : handleBorrowerProcessReturn(e, selectedRecord.id)} className="space-y-6">
                              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                                <div className="space-y-1 col-span-2 lg:col-span-1">
                                  <label className="text-[10px] font-bold text-slate-500 uppercase">{isAdmin ? "ວັນທີຮັບຄືນ" : "ວັນທີແຈ້ງສົ່ງຄືນ"}</label>
                                  <input name="borrowerReturnDate" type="date" defaultValue={selectedRecord.borrowerReturnDate || selectedRecord.finalReturnDate?.split('T')[0] || new Date().toISOString().split('T')[0]} className="w-full p-2.5 bg-white border border-slate-200 rounded-xl text-sm outline-none focus:border-indigo-500 shadow-sm" required />
                                </div>
                                <div className="space-y-1">
                                  <label className="text-[10px] font-bold text-slate-500 uppercase">Return Qty</label>
                                  <input name="returnQty" type="number" defaultValue={selectedRecord.returnQty ?? (selectedRecord.items?.reduce((sum, item) => sum + item.borrowQty, 0) || 1)} className="w-full p-2.5 bg-white border border-slate-200 rounded-xl text-sm outline-none focus:border-indigo-500 shadow-sm" required />
                                </div>
                                <div className="space-y-1">
                                  <label className="text-[10px] font-bold text-slate-500 uppercase">Condition</label>
                                  <select name="condition" defaultValue={selectedRecord.condition || 'Good'} className="w-full p-2.5 bg-white border border-slate-200 rounded-xl text-sm outline-none focus:border-indigo-500 shadow-sm" required>
                                    <option value="Good">Good</option>
                                    <option value="Damaged">Damaged</option>
                                    <option value="Lost">Lost</option>
                                  </select>
                                </div>
                                <div className="space-y-1 col-span-2 lg:col-span-1">
                                  <label className="text-[10px] font-bold text-slate-500 uppercase">Remarks / Notes</label>
                                  <textarea name="returnRemarks" defaultValue={selectedRecord.returnRemarks || ''} placeholder="Ex: Returned all, in good condition..." className="w-full p-2.5 bg-white border border-slate-200 rounded-xl text-sm outline-none focus:border-indigo-500 shadow-sm min-h-[44px]" rows={1}></textarea>
                                </div>
                              </div>
                              
                              <div className="space-y-2 mt-4 pt-6 border-t border-slate-200">
                                <label className="text-xs font-bold text-slate-600 uppercase">Upload Condition Photos (Optional, Max 3)</label>
                                <div className="flex flex-wrap gap-3">
                                  {returnFormPhotos.map((photo, pIdx) => (
                                    <div key={pIdx} className="relative w-20 h-20 rounded-xl overflow-hidden border border-slate-200 shadow-sm">
                                      <img src={photo} alt="Condition" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                                      <button 
                                        type="button" 
                                        onClick={() => {
                                          const newPhotos = [...returnFormPhotos];
                                          newPhotos.splice(pIdx, 1);
                                          setReturnFormPhotos(newPhotos);
                                        }}
                                        className="absolute top-1 right-1 bg-white/90 hover:bg-red-50 text-red-600 p-1.5 rounded-lg transition-colors shadow"
                                      >
                                        <X size={12} />
                                      </button>
                                    </div>
                                  ))}
                                  {returnFormPhotos.length < 3 && (
                                    <div className="flex gap-3">
                                      <label className="w-20 h-20 bg-white border-2 border-dashed border-slate-300 rounded-xl flex flex-col items-center justify-center text-slate-400 hover:text-indigo-600 hover:border-indigo-400 hover:bg-indigo-50 cursor-pointer transition-all">
                                        <Camera size={20} />
                                        <span className="text-[10px] font-bold mt-1">Camera</span>
                                        <input 
                                          type="file" 
                                          accept="image/*" 
                                          capture="environment"
                                          className="hidden" 
                                          onChange={async (e) => {
                                            if (!e.target.files) return;
                                            const newPhotos = await processImageFiles(e.target.files, 3 - returnFormPhotos.length);
                                            setReturnFormPhotos([...returnFormPhotos, ...newPhotos]);
                                            e.target.value = '';
                                          }}
                                        />
                                      </label>
                                      <label className="w-20 h-20 bg-white border-2 border-dashed border-slate-300 rounded-xl flex flex-col items-center justify-center text-slate-400 hover:text-indigo-600 hover:border-indigo-400 hover:bg-indigo-50 cursor-pointer transition-all">
                                        <ImageIcon size={20} />
                                        <span className="text-[10px] font-bold mt-1">Gallery</span>
                                        <input 
                                          type="file" 
                                          accept="image/*" 
                                          multiple 
                                          className="hidden" 
                                          onChange={async (e) => {
                                            if (!e.target.files) return;
                                            const newPhotos = await processImageFiles(e.target.files, 3 - returnFormPhotos.length);
                                            setReturnFormPhotos([...returnFormPhotos, ...newPhotos]);
                                            e.target.value = '';
                                          }}
                                        />
                                      </label>
                                    </div>
                                  )}
                                </div>
                              </div>

                              <button type="submit" disabled={isProcessingReturn} className="w-full py-4 mt-6 bg-emerald-600 text-white text-sm font-bold rounded-xl hover:bg-emerald-700 transition-all shadow-lg disabled:opacity-50 flex items-center justify-center gap-2">
                                {isProcessingReturn ? (
                                   <>
                                     <span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></span>
                                     ກຳລັງດຳເນີນການ...
                                   </>
                                ) : (
                                   isAdmin ? 'Process Return & Close (ສາງຮັບເຄື່ອງສຳເລັດ)' : 'ແຈ້ງສົ່ງເຄື່ອງຄືນ (Submit Return Request)'
                                )}
                              </button>
                           </form>
                        </div>
                    )}
                  </div>
                </div>
              </div>
              
              <div className="p-4 sm:p-6 border-t border-slate-100 bg-slate-50 flex flex-col-reverse sm:flex-row items-center justify-between gap-3 sticky bottom-0 z-10" data-html2canvas-ignore="true">
                <div className="flex w-full sm:w-auto items-center justify-center bg-white border border-slate-200 p-1 rounded-xl shadow-sm">
                  <span className="pl-3 pr-2 flex items-center gap-1.5 text-slate-600 font-bold text-sm whitespace-nowrap">
                    {isExporting ? <span className="w-4 h-4 rounded-full border-2 border-slate-400 border-t-transparent animate-spin"></span> : <Download size={16} />}
                    Export
                  </span>
                  <div className="h-5 w-px bg-slate-200 mx-1"></div>
                  <button 
                    onClick={() => handleExport('jpg')}
                    disabled={isExporting}
                    className="px-3 py-1.5 hover:bg-slate-50 text-slate-700 text-sm font-bold rounded-lg transition-colors flex-1 text-center"
                  >
                    JPG
                  </button>
                  <button 
                    onClick={() => handleExport('pdf')}
                    disabled={isExporting}
                    className="px-3 py-1.5 hover:bg-slate-50 text-slate-700 text-sm font-bold rounded-lg transition-colors flex-1 text-center"
                  >
                    PDF
                  </button>
                </div>
                <div className="flex w-full sm:w-auto flex-row gap-3">
                  {(isAdmin || isSuperAdmin) && (
                    <button 
                      onClick={() => setIsEditingBorrowRecord(true)}
                      disabled={isProcessingReturn}
                      className="px-6 py-2.5 bg-amber-100/50 hover:bg-amber-100 text-amber-700 font-bold rounded-xl transition-all shadow-sm flex items-center flex-1 sm:flex-none justify-center disabled:opacity-50"
                    >
                      <Edit3 size={16} className="mr-2" />
                      Edit
                    </button>
                  )}
                  <button onClick={() => { if (!isProcessingReturn) setSelectedRecord(null); }} disabled={isProcessingReturn} className="px-8 py-2.5 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-200 flex-1 sm:flex-none justify-center disabled:opacity-50">Close</button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {isEditingBorrowRecord && selectedRecord && (
           <EditBorrowRecordModal
             record={selectedRecord}
             onClose={() => setIsEditingBorrowRecord(false)}
             onUpdate={() => {
               // The parent component listens to Firestore so it auto updates,
               // But we can reset selectedRecord if needed, or close it.
               setIsEditingBorrowRecord(false);
               setSelectedRecord(null); // Or just leave it open to see changes. Let's close modal, but keep row active or reset it.
               // It's probably better to just close the edit modal but keep the record modal open.
             }}
             currentUserEmail={currentUserEmail}
           />
        )}
      </AnimatePresence>

      {/* Message Dialog */}
      <AnimatePresence>
        {messageRecord && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setMessageRecord(null)}
              className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="bg-white w-full max-w-lg rounded-3xl shadow-2xl overflow-hidden flex flex-col relative z-10"
            >
              <div className="p-5 border-b border-slate-100 flex items-center justify-between bg-white">
                <h2 className="text-lg font-bold text-slate-800">Send Reminder</h2>
                <button onClick={() => setMessageRecord(null)} className="p-2 hover:bg-slate-100 rounded-full transition-colors">
                  <X size={20} />
                </button>
              </div>
              
              <div className="p-6 space-y-4">
                <div className="space-y-4">
                   <div className="flex flex-col gap-1">
                      <label className="text-xs font-bold text-slate-500 uppercase">Delivery Method</label>
                      <select 
                        value={messageDelivery} 
                        onChange={(e) => setMessageDelivery(e.target.value as any)}
                        className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-indigo-500 text-sm font-medium"
                      >
                        <option value="email">Email / Microsoft Teams</option>
                        <option value="whatsapp">WhatsApp Messenger</option>
                      </select>
                   </div>
                   
                   <div className="flex flex-col gap-1">
                      <label className="text-xs font-bold text-slate-500 uppercase">Message Body</label>
                      <textarea 
                        value={messageContent}
                        onChange={(e) => setMessageContent(e.target.value)}
                        rows={8}
                        className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-indigo-500 text-sm"
                      />
                      <p className="text-[10px] text-slate-400">You can edit the auto-generated text before sending. A record of this message will be kept in the system Notifications.</p>
                   </div>
                </div>
              </div>
              
              <div className="p-5 border-t border-slate-100 bg-slate-50 flex items-center justify-end gap-3">
                <button onClick={() => setMessageRecord(null)} className="px-5 py-2 text-slate-600 font-bold hover:bg-slate-200 rounded-xl transition-all text-sm">Cancel</button>
                <button onClick={handleSendMessage} className="px-5 py-2 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 transition-all shadow-md shadow-indigo-200 text-sm flex items-center gap-2">
                  <Send size={16} /> Send {messageDelivery === 'whatsapp' ? 'via WhatsApp' : 'Notification'}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {viewingImage && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 p-4" onClick={() => setViewingImage(null)}>
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              transition={{ type: 'spring', damping: 25, stiffness: 300 }}
              className="relative max-w-5xl max-h-screen w-full h-full flex items-center justify-center p-4"
              onClick={(e) => e.stopPropagation()}
            >
              <button 
                onClick={() => setViewingImage(null)}
                className="absolute top-4 right-4 sm:top-8 sm:right-8 w-12 h-12 bg-white/10 hover:bg-white/20 text-white rounded-full flex items-center justify-center transition-colors backdrop-blur-sm shadow-xl z-[101]"
              >
                <X size={24} />
              </button>
              <img 
                src={viewingImage} 
                alt="Fullscreen" 
                className="max-w-full max-h-[85vh] object-contain rounded-xl shadow-2xl ring-1 ring-white/10" 
                referrerPolicy="no-referrer"
              />
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

function HistoryView({ logs }: { logs: ActivityLog[] }) {
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;
  
  const totalPages = Math.ceil(logs.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const currentLogs = logs.slice(startIndex, startIndex + itemsPerPage);

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-4 border-b border-slate-100 bg-slate-50/50 flex items-center justify-between">
          <span className="text-sm font-semibold text-slate-600">Recent Logs ({logs.length})</span>
          <button className="text-xs font-bold text-indigo-600 hover:underline">Download CSV</button>
        </div>
        <div className="divide-y divide-slate-100">
          {currentLogs.map((log) => (
            <div key={log.id} className="p-4 md:p-6 flex flex-col md:flex-row md:items-start justify-between gap-4 hover:bg-slate-50 transition-colors">
              <div className="flex gap-3 md:gap-4">
                <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center shrink-0">
                  <History size={18} className="text-slate-500" />
                </div>
                <div>
                  <p className="text-slate-900 font-medium text-sm md:text-base">{log.details}</p>
                  <p className="text-xs md:text-sm text-slate-500">Performed by <span className="text-slate-700 font-semibold">{log.user}</span></p>
                </div>
              </div>
              <div className="text-left md:text-right pl-13 md:pl-0">
                <p className="text-sm font-medium text-slate-900">{format(parseISO(log.timestamp), 'HH:mm')}</p>
                <p className="text-xs text-slate-400">{format(parseISO(log.timestamp), 'MMM dd, yyyy')}</p>
              </div>
            </div>
          ))}
        </div>
        
        {totalPages > 1 && (
          <div className="p-4 border-t border-slate-100 flex items-center justify-between">
            <button 
              onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
              disabled={currentPage === 1}
              className="px-4 py-2 border border-slate-200 rounded-xl text-sm font-bold text-slate-600 hover:bg-slate-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              Previous
            </button>
            <span className="text-sm text-slate-500 font-medium">Page {currentPage} of {totalPages}</span>
            <button 
              onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
              disabled={currentPage === totalPages}
              className="px-4 py-2 border border-slate-200 rounded-xl text-sm font-bold text-slate-600 hover:bg-slate-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              Next
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

function UsersView({
  users,
  units,
  departments,
  isSuperAdmin,
  onUpdateRole,
  onAddUser,
  onDeleteUser,
  onUpdateUser,
  onApproveUser
}: {
  users: any[],
  units: Unit[],
  departments: Department[],
  isSuperAdmin?: boolean,
  onUpdateRole: (id: string, role: 'super_admin' | 'admin' | 'user' | 'approver' | 'acknowledge') => void,
  onAddUser: (data: { email: string, role: string, firstName: string, lastName: string, unitId: string, departmentId: string, phone: string }) => Promise<void>,
  onDeleteUser?: (id: string) => Promise<void>,
  onUpdateUser?: (id: string, data: any, reason?: string) => Promise<void>,
  onApproveUser?: (id: string) => Promise<void>
}) {
  const [isSaving, setIsSaving] = useState(false);
  const [isAddingUser, setIsAddingUser] = useState(false);
  const [newEmail, setNewEmail] = useState('');
  const [newRole, setNewRole] = useState<'super_admin' | 'admin' | 'user' | 'approver' | 'acknowledge'>('user');
  const [newFirstName, setNewFirstName] = useState('');
  const [newLastName, setNewLastName] = useState('');
  const [newUnitId, setNewUnitId] = useState('');
  const [newDepartmentId, setNewDepartmentId] = useState('');
  const [newPhone, setNewPhone] = useState('');

  const [editingUser, setEditingUser] = useState<any>(null);
  const [editFirstName, setEditFirstName] = useState('');
  const [editLastName, setEditLastName] = useState('');
  const [editEmail, setEditEmail] = useState('');
  const [editPhone, setEditPhone] = useState('');
  const [editUnitId, setEditUnitId] = useState('');
  const [editDepartmentId, setEditDepartmentId] = useState('');
  const [editReason, setEditReason] = useState('');
  
  const [editRole, setEditRole] = useState<'super_admin' | 'admin' | 'user' | 'approver' | 'acknowledge'>('user');

  const [userToDelete, setUserToDelete] = useState<any>(null);
  const [userToResetPassword, setUserToResetPassword] = useState<any>(null);
  const [resetPasswordMessage, setResetPasswordMessage] = useState<{type: 'success' | 'error', text: string} | null>(null);
  const [resetPasswordMode, setResetPasswordMode] = useState<'email' | 'manual'>('email');
  const [manualPasswordInput, setManualPasswordInput] = useState('');

  const openEdit = (user: any) => {
    setEditingUser(user);
    setEditFirstName(user.firstName || '');
    setEditLastName(user.lastName || '');
    setEditEmail(user.email || '');
    setEditPhone(user.phone || '');
    setEditUnitId(user.unitId || '');
    setEditDepartmentId(user.departmentId || '');
    setEditRole(user.role || 'user');
    setEditReason('');
  };

  const handleSaveEdit = async () => {
    if (!editingUser || !onUpdateUser || isSaving) return;
    
    if (!editReason || editReason.trim() === '') {
      alert("ຕ້ອງປ້ອນເຫດຜົນເພື່ອບັນທຶກປະຫວັດ / Reason is required to keep track.");
      return;
    }

    setIsSaving(true);
    try {
      await onUpdateUser(editingUser.id, {
        firstName: editFirstName,
        lastName: editLastName,
        name: `${editFirstName} ${editLastName}`.trim(),
        displayName: `${editFirstName} ${editLastName}`.trim(),
        email: editEmail,
        phone: editPhone,
        unitId: editUnitId,
        departmentId: editDepartmentId,
        role: editRole
      }, editReason);
      setEditingUser(null);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="space-y-8 pb-20">
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-6 border-b border-slate-100 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h2 className="text-lg font-bold">User Access Management</h2>
            <p className="text-sm text-slate-500">Manage roles, approve pending sign-ups, and add new users.</p>
          </div>
          <div className="flex items-center gap-2">
            <button 
              onClick={() => setIsAddingUser(true)}
              className="px-4 py-2 bg-indigo-600 text-white rounded-lg text-sm font-bold hover:bg-indigo-700 transition-colors whitespace-nowrap flex items-center gap-1.5"
            >
              <Plus size={16} />
              Add User
            </button>
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-slate-50 text-slate-500 text-xs uppercase font-bold">
              <tr>
                <th className="px-6 py-4">User</th>
                <th className="px-6 py-4">Role & Status</th>
                <th className="px-6 py-4">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {users.length === 0 ? (
                <tr>
                  <td colSpan={3} className="px-6 py-8 text-center text-slate-400 italic">
                    No users found in database.
                  </td>
                </tr>
              ) : (
                users.map((u) => (
                  <tr key={u.id} className="hover:bg-slate-50/50 transition-colors">
                    <td className="px-6 py-4">
                      <div className="flex flex-col gap-0.5">
                        <span className="font-semibold text-slate-700">{(() => {
                          const fullName = u.name || u.displayName || (u.isPreCreated ? 'Pre-created User' : 'Unknown User');
                          if (fullName === 'Pre-created User' || fullName === 'Unknown User') return fullName;
                          const parts = fullName.trim().split(/\s+/);
                          if (parts.length > 1) {
                            return `${parts[0]} ${parts[parts.length - 1][0]}.`;
                          }
                          return fullName;
                        })()}</span>
                        <span className="text-xs text-slate-500">{u.email}</span>
                        {u.phone && (
                          <span className="text-[10px] bg-slate-100 text-slate-500 w-fit px-1.5 py-0.5 rounded font-mono mt-1">{u.phone}</span>
                        )}
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className={cn(
                          "text-[10px] px-2 py-1 rounded-full font-bold uppercase",
                          u.role === 'admin' ? "bg-indigo-100 text-indigo-700" : 
                          u.role === 'approver' ? "bg-purple-100 text-purple-700" :
                          u.role === 'acknowledge' ? "bg-sky-100 text-sky-700" :
                          "bg-slate-100 text-slate-600"
                        )}>
                          {u.role || 'user'}
                        </span>
                        {u.status === 'pending' && (
                          <span className="text-[10px] px-2 py-1 bg-amber-100 text-amber-700 rounded-full font-bold uppercase border border-amber-200">Pending Approval</span>
                        )}
                        {u.email === 'khamsone.peng@gmail.com' && (
                          <span className="text-[10px] px-1.5 py-0.5 bg-amber-100 text-amber-700 rounded font-black uppercase">Super</span>
                        )}
                        {u.isPreCreated && (
                          <span className="text-[10px] px-1.5 py-0.5 bg-blue-100 text-blue-700 rounded font-black uppercase">Pending Login</span>
                        )}
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        {u.status === 'pending' && onApproveUser && (
                           <button 
                             onClick={() => onApproveUser(u.id)}
                             className="text-xs font-bold px-3 py-1 bg-emerald-100 text-emerald-700 hover:bg-emerald-200 rounded-lg transition-colors border border-emerald-200"
                           >
                             Approve
                           </button>
                        )}
                        {onUpdateUser && (
                          <button onClick={() => openEdit(u)} className="text-slate-400 hover:text-indigo-600 transition-colors" title="Edit">
                            <Edit3 size={16} />
                          </button>
                        )}
                        <button 
                          onClick={() => setUserToResetPassword(u)} 
                          className="text-slate-400 hover:text-indigo-600 transition-colors" 
                          title="Send Password Reset Email"
                        >
                          <KeyRound size={16} />
                        </button>
                        {isSuperAdmin && onDeleteUser && (
                           <button 
                             onClick={() => setUserToDelete(u)}
                             disabled={u.email === 'khamsone.peng@gmail.com'}
                             className="text-slate-400 hover:text-red-600 transition-colors disabled:opacity-30" title="Delete">
                             <Trash2 size={16} />
                           </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      <AnimatePresence>
        {isAddingUser && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              onClick={() => setIsAddingUser(false)}
              className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="bg-white w-full max-w-sm rounded-3xl shadow-2xl overflow-hidden flex flex-col relative z-10"
            >
              <div className="p-5 border-b border-slate-100 flex items-center justify-between">
                <h2 className="text-lg font-bold text-slate-800">Add New User</h2>
                <button onClick={() => setIsAddingUser(false)} className="p-2 hover:bg-slate-100 rounded-full text-slate-500">
                  <X size={20} />
                </button>
              </div>
              <div className="p-6 space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">First Name</label>
                    <input 
                      type="text" value={newFirstName} onChange={e => setNewFirstName(e.target.value)}
                      className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl outline-none text-sm focus:border-indigo-500"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Last Name</label>
                    <input 
                      type="text" value={newLastName} onChange={e => setNewLastName(e.target.value)}
                      className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl outline-none text-sm focus:border-indigo-500"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Email <span className="text-red-500">*</span></label>
                  <input 
                    type="email" value={newEmail} onChange={e => setNewEmail(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl outline-none text-sm focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Mobile Phone (WhatsApp)</label>
                  <input 
                    type="tel" value={newPhone} onChange={e => setNewPhone(e.target.value)} placeholder="Ex: 59682000 or 020..."
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl outline-none text-sm focus:border-indigo-500"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Unit</label>
                    <select
                      value={newUnitId} onChange={e => setNewUnitId(e.target.value)}
                      className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl outline-none text-sm focus:border-indigo-500"
                    >
                      <option value="">Select Unit</option>
                      {units.map((u) => (
                        <option key={u.id} value={u.id}>{u.name}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Department</label>
                    <select
                      value={newDepartmentId} onChange={e => setNewDepartmentId(e.target.value)}
                      className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl outline-none text-sm focus:border-indigo-500"
                    >
                      <option value="">Select Dept</option>
                      {departments.map((d) => (
                        <option key={d.id} value={d.id}>{d.name}</option>
                      ))}
                    </select>
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Role</label>
                  <select 
                    value={newRole} onChange={(e) => setNewRole(e.target.value as any)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl outline-none text-sm focus:border-indigo-500"
                  >
                    <option value="user">User</option>
                    <option value="acknowledge">Acknowledge</option>
                    <option value="approver">Approver</option>
                    <option value="admin">Admin</option>
                    {isSuperAdmin && <option value="super_admin">Super Admin</option>}
                  </select>
                </div>
              </div>
              <div className="p-5 border-t border-slate-100 bg-slate-50 flex justify-end gap-3">
                <button onClick={() => setIsAddingUser(false)} className="px-5 py-2 text-slate-600 font-bold hover:bg-slate-200 rounded-xl text-sm transition">Cancel</button>
                <button 
                  onClick={() => {
                    if (newEmail) {
                      onAddUser({ email: newEmail, role: newRole, firstName: newFirstName, lastName: newLastName, unitId: newUnitId, departmentId: newDepartmentId, phone: newPhone });
                      setNewEmail(''); setNewFirstName(''); setNewLastName(''); setNewUnitId(''); setNewDepartmentId(''); setNewPhone('');
                      setIsAddingUser(false);
                    }
                  }} 
                  disabled={!newEmail}
                  className="px-5 py-2 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 disabled:opacity-50 shadow-md shadow-indigo-200 text-sm transition"
                >
                  Add User
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {editingUser && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              onClick={() => setEditingUser(null)}
              className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="bg-white w-full max-w-sm rounded-3xl shadow-2xl overflow-hidden flex flex-col relative z-10"
            >
              <div className="p-5 border-b border-slate-100 flex items-center justify-between">
                <h2 className="text-lg font-bold text-slate-800">Edit User</h2>
                <button onClick={() => setEditingUser(null)} className="p-2 hover:bg-slate-100 rounded-full text-slate-500">
                  <X size={20} />
                </button>
              </div>
              <div className="p-6 space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">First Name</label>
                    <input 
                      type="text" value={editFirstName} onChange={e => setEditFirstName(e.target.value)}
                      className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl outline-none text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Last Name</label>
                    <input 
                      type="text" value={editLastName} onChange={e => setEditLastName(e.target.value)}
                      className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl outline-none text-sm"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Email Address</label>
                  <input 
                    type="email" value={editEmail} onChange={e => setEditEmail(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl outline-none text-sm"
                  />
                  <p className="text-[10px] text-amber-600 mt-1">* ໃຫ້ແອັດມິນແກ້ອີເມລໃນກໍລະນີພິມຜິດ. ສຳລັບການແກ້ໄຂອື່ນໆ ຕ້ອງປ້ອນເຫດຜົນ.</p>
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Mobile Phone (WhatsApp)</label>
                  <input 
                    type="tel" value={editPhone} onChange={e => setEditPhone(e.target.value)} placeholder="Ex: 59682000 or 020..."
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl outline-none text-sm"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Unit</label>
                    <select
                      value={editUnitId} onChange={e => setEditUnitId(e.target.value)}
                      className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl outline-none text-sm"
                    >
                      <option value="">Select Unit</option>
                      {units.map((u) => (
                        <option key={u.id} value={u.id}>{u.name}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Department</label>
                    <select
                      value={editDepartmentId} onChange={e => setEditDepartmentId(e.target.value)}
                      className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl outline-none text-sm"
                    >
                      <option value="">Select Department</option>
                      {departments.map((d) => (
                        <option key={d.id} value={d.id}>{d.name}</option>
                      ))}
                    </select>
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Role</label>
                  <select 
                    value={editRole} onChange={(e) => setEditRole(e.target.value as any)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl outline-none text-sm focus:border-indigo-500"
                  >
                    <option value="user">User</option>
                    <option value="acknowledge">Acknowledge</option>
                    <option value="approver">Approver</option>
                    <option value="admin">Admin</option>
                    {isSuperAdmin && <option value="super_admin">Super Admin</option>}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Reason for editing <span className="text-red-500">*</span></label>
                  <input 
                    type="text" 
                    value={editReason} onChange={(e) => setEditReason(e.target.value)} 
                    placeholder="Enter reason for updating user" 
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl outline-none text-sm focus:border-indigo-500"
                  />
                  <p className="text-xs text-red-500 mt-1">* Used for activity logs.</p>
                </div>
              </div>
              <div className="p-5 border-t border-slate-100 bg-slate-50 flex justify-end gap-3">
                <button onClick={() => setEditingUser(null)} className="px-5 py-2 text-slate-600 font-bold hover:bg-slate-200 rounded-xl text-sm transition">Cancel</button>
                <button 
                  onClick={handleSaveEdit} 
                  disabled={isSaving}
                  className={`px-5 py-2 font-bold rounded-xl shadow-md text-sm transition ${isSaving ? 'bg-slate-400 text-white cursor-not-allowed shadow-none' : 'bg-indigo-600 text-white hover:bg-indigo-700 shadow-indigo-200'}`}>
                  {isSaving ? 'Saving...' : 'Save Changes'}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {userToDelete && onDeleteUser && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              onClick={() => setUserToDelete(null)}
              className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="bg-white w-full max-w-sm rounded-3xl shadow-2xl overflow-hidden flex flex-col relative z-10"
            >
              <div className="p-5 border-b border-slate-100 flex items-center justify-between">
                <h2 className="text-lg font-bold text-red-600">Delete User</h2>
                <button onClick={() => setUserToDelete(null)} className="p-2 hover:bg-slate-100 rounded-full text-slate-500">
                  <X size={20} />
                </button>
              </div>
              <div className="p-6">
                <p className="text-sm text-slate-700 mb-4 whitespace-normal">
                  Are you sure you want to delete <strong className="text-slate-900">{userToDelete.name || userToDelete.displayName || userToDelete.email}</strong>? 
                  This action cannot be undone and will revoke their access.
                </p>
              </div>
              <div className="p-5 border-t border-slate-100 bg-slate-50 flex justify-end gap-3">
                <button onClick={() => setUserToDelete(null)} className="px-5 py-2 text-slate-600 font-bold hover:bg-slate-200 rounded-xl text-sm transition">Cancel</button>
                <button 
                  onClick={() => {
                    onDeleteUser(userToDelete.id);
                    setUserToDelete(null);
                  }} 
                  className="px-5 py-2 bg-red-600 text-white font-bold rounded-xl hover:bg-red-700 shadow-md shadow-red-200 text-sm transition"
                >
                  Confirm Delete
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {userToResetPassword && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              onClick={() => {
                setUserToResetPassword(null);
                setResetPasswordMessage(null);
                setResetPasswordMode('email');
                setManualPasswordInput('');
              }}
              className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="bg-white w-full max-w-md rounded-3xl shadow-2xl overflow-hidden flex flex-col relative z-10"
            >
              <div className="p-5 border-b border-slate-100 flex items-center justify-between">
                <h2 className="text-lg font-bold text-indigo-600">Reset Password</h2>
                <button 
                  onClick={() => {
                    setUserToResetPassword(null);
                    setResetPasswordMessage(null);
                    setResetPasswordMode('email');
                    setManualPasswordInput('');
                  }}
                  className="p-2 hover:bg-slate-100 rounded-full text-slate-500"
                >
                  <X size={20} />
                </button>
              </div>
              
              <div className="flex border-b border-slate-100">
                <button 
                  onClick={() => setResetPasswordMode('email')}
                  className={cn("flex-1 p-3 text-sm font-bold text-center border-b-2 transition-colors", resetPasswordMode === 'email' ? "border-indigo-600 text-indigo-600" : "border-transparent text-slate-500 hover:text-slate-700 hover:bg-slate-50")}
                >
                  Send Reset Email
                </button>
                <button 
                  onClick={() => setResetPasswordMode('manual')}
                  className={cn("flex-1 p-3 text-sm font-bold text-center border-b-2 transition-colors", resetPasswordMode === 'manual' ? "border-amber-500 text-amber-600" : "border-transparent text-slate-500 hover:text-slate-700 hover:bg-slate-50")}
                >
                  Manual Override
                </button>
              </div>

              <div className="p-6">
                {resetPasswordMessage ? (
                  <div className={`p-4 rounded-xl text-sm ${resetPasswordMessage.type === 'success' ? 'bg-emerald-50 text-emerald-700 border border-emerald-100' : 'bg-red-50 text-red-700 border border-red-100'}`}>
                    {resetPasswordMessage.text}
                  </div>
                ) : resetPasswordMode === 'email' ? (
                  <p className="text-sm text-slate-700 whitespace-normal">
                    Send a secure password reset email to <strong className="text-slate-900">{userToResetPassword.email}</strong>?
                  </p>
                ) : (
                  <div className="space-y-4">
                    <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-sm text-amber-800 flex items-start gap-2">
                      <AlertTriangle className="shrink-0 mt-0.5" size={16} />
                      <p>
                        This system is running as a client-side platform. Firebase restricts direct password modifications without the backend Admin SDK. By proceeding, we will save this temporary password to their record, but they must still reset it or the Admin SDK integration should be enabled.
                      </p>
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-500 uppercase mb-1">New Password (Temporary)</label>
                      <input 
                        type="text" 
                        value={manualPasswordInput}
                        onChange={e => setManualPasswordInput(e.target.value)}
                        placeholder="Enter temporary password..."
                        className="w-full p-2.5 bg-white border border-slate-200 rounded-xl text-sm outline-none focus:border-indigo-500"
                      />
                    </div>
                  </div>
                )}
              </div>
              <div className="p-5 border-t border-slate-100 bg-slate-50 flex justify-end gap-3">
                {resetPasswordMessage?.type === 'success' ? (
                  <button 
                    onClick={() => {
                      setUserToResetPassword(null);
                      setResetPasswordMessage(null);
                      setResetPasswordMode('email');
                      setManualPasswordInput('');
                    }}
                    className="px-5 py-2 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 text-sm transition"
                  >
                    Close
                  </button>
                ) : (
                  <>
                    <button 
                      onClick={() => {
                        setUserToResetPassword(null);
                        setResetPasswordMessage(null);
                        setResetPasswordMode('email');
                        setManualPasswordInput('');
                      }} 
                      className="px-5 py-2 text-slate-600 font-bold hover:bg-slate-200 rounded-xl text-sm transition"
                    >
                      Cancel
                    </button>
                    {resetPasswordMode === 'email' ? (
                      <button 
                        onClick={async () => {
                          if (!userToResetPassword?.email) {
                            setResetPasswordMessage({ type: 'error', text: "User does not have an email address."});
                            return;
                          }
                          try {
                            await sendPasswordResetEmail(auth, userToResetPassword.email);
                            setResetPasswordMessage({ type: 'success', text: `Password reset email sent to ${userToResetPassword.email}`});
                          } catch (err: any) {
                            setResetPasswordMessage({ type: 'error', text: err.message || "Failed to send reset email"});
                          }
                        }} 
                        className="px-5 py-2 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 shadow-md shadow-indigo-200 text-sm transition"
                      >
                        Send Email
                      </button>
                    ) : (
                      <button 
                        onClick={async () => {
                          if (!manualPasswordInput.trim()) {
                            setResetPasswordMessage({ type: 'error', text: "Please enter a valid password." });
                            return;
                          }
                          try {
                            await updateDoc(doc(db, 'users', userToResetPassword.id), {
                              adminAssignedPassword: manualPasswordInput,
                              forceManualReset: true
                            });
                            setResetPasswordMessage({ type: 'success', text: `Temporary password saved successfully (Mock action completed).`});
                          } catch (err: any) {
                            setResetPasswordMessage({ type: 'error', text: err.message || "Failed to save password overriding flag."});
                          }
                        }} 
                        className="px-5 py-2 bg-amber-600 text-white font-bold rounded-xl hover:bg-amber-700 shadow-md shadow-amber-200 text-sm transition"
                      >
                        Force Reset
                      </button>
                    )}
                  </>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

function MessagesView({ 
  notifications, 
  isAdmin, 
  isSuperAdmin,
  appUsers,
  onNavigateToRecord
}: { 
  notifications: AppNotification[], 
  isAdmin?: boolean, 
  isSuperAdmin?: boolean,
  appUsers?: any[],
  onNavigateToRecord?: (recordId: string) => void
}) {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editMessage, setEditMessage] = useState<AppNotification | null>(null);
  const [userId, setUserId] = useState('');
  const [title, setTitle] = useState('');
  const [message, setMessage] = useState('');
  const [type, setType] = useState<'info' | 'warning' | 'error'>('info');
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());

  const openNewMessage = () => {
    setEditMessage(null);
    setUserId(appUsers && appUsers.length > 0 ? (appUsers[0].email || 'admin') : 'admin');
    setTitle('');
    setMessage('');
    setType('info');
    setIsModalOpen(true);
  };

  const openEditMessage = (notif: AppNotification) => {
    setEditMessage(notif);
    setUserId(notif.userId);
    setTitle(notif.title);
    setMessage(notif.message);
    setType(notif.type || 'info');
    setIsModalOpen(true);
  };

  const handleDelete = async (id: string) => {
    if (!isAdmin) return;
    if (confirm("ແນ່ໃຈບໍ່ວ່າຕ້ອງການລຶບ? (Are you sure you want to delete?)")) {
      try {
        await deleteDoc(doc(db, 'notifications', id));
      } catch (error) {
        console.error("Error deleting message:", error);
      }
    }
  };

  const handleBulkDelete = async () => {
    if (!isAdmin || selectedIds.size === 0) return;
    if (confirm(`ຕ້ອງການລຶບ ${selectedIds.size} ລາຍການທີ່ເລືອກໄວ້ ຫຼື ບໍ່? (Delete ${selectedIds.size} selected items?)`)) {
      try {
        const promises = Array.from(selectedIds).map((id: string) => deleteDoc(doc(collection(db, 'notifications'), id)));
        await Promise.all(promises);
        setSelectedIds(new Set());
      } catch (error) {
        console.error("Error bulk deleting messages:", error);
      }
    }
  };

  const toggleSelect = (id: string) => {
    const newSelected = new Set(selectedIds);
    if (newSelected.has(id)) {
      newSelected.delete(id);
    } else {
      newSelected.add(id);
    }
    setSelectedIds(newSelected);
  };

  const toggleSelectAll = () => {
    if (selectedIds.size === notifications.length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(notifications.map(n => n.id)));
    }
  };

  const handleSave = async () => {
    if (!title || !message || !userId) return;
    try {
      if (editMessage) {
        await updateDoc(doc(db, 'notifications', editMessage.id), {
          title,
          message,
          userId,
          type
        });
      } else {
        await addDoc(collection(db, 'notifications'), {
          title,
          message,
          userId,
          type,
          read: false,
          createdAt: serverTimestamp()
        });
      }
      setIsModalOpen(false);
    } catch (error) {
      console.error("Error saving message:", error);
    }
  };

  return (
    <div className="space-y-4">
      {isAdmin && (
        <div className="flex justify-between items-center bg-white p-3 rounded-2xl border border-slate-200">
          <div className="flex items-center gap-3 ml-2">
            {isAdmin && notifications.length > 0 && (
              <>
                <input 
                  type="checkbox" 
                  checked={selectedIds.size > 0 && selectedIds.size === notifications.length}
                  ref={el => {
                    if (el) {
                      el.indeterminate = selectedIds.size > 0 && selectedIds.size < notifications.length;
                    }
                  }}
                  onChange={toggleSelectAll}
                  className="w-4 h-4 text-indigo-600 bg-slate-100 border-slate-300 rounded focus:ring-indigo-500 cursor-pointer"
                />
                <span className="text-sm text-slate-600 font-medium">Select All</span>
                
                {selectedIds.size > 0 && (
                  <button 
                    onClick={handleBulkDelete}
                    className="ml-2 px-3 py-1.5 bg-red-50 text-red-600 hover:bg-red-100 rounded-lg text-xs font-bold transition flex items-center gap-1"
                  >
                    <Trash2 size={14} /> Delete Selected ({selectedIds.size})
                  </button>
                )}
              </>
            )}
          </div>
          <button 
            onClick={openNewMessage}
            className="px-4 py-2 bg-indigo-600 text-white rounded-xl text-sm font-bold shadow-md shadow-indigo-200 hover:bg-indigo-700 transition flex items-center gap-2"
          >
            <Plus size={16} />
            New Message
          </button>
        </div>
      )}
      
      {notifications.length === 0 ? (
        <div className="text-center py-12 text-slate-500">
          No messages or notifications.
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-3">
          {notifications.map((notif) => (
            <div key={notif.id} className={cn(
              "p-4 rounded-2xl border flex items-start gap-4 transition-colors relative",
              notif.read ? "bg-white border-slate-200" : "bg-indigo-50 border-indigo-100",
              notif.linkToRecordId ? "cursor-pointer hover:border-indigo-300" : ""
            )}
            onClick={async (e) => {
              // Ignore click if clicking the checkbox
              if ((e.target as HTMLElement).tagName === 'INPUT') return;
              
              if (!notif.read) {
                try {
                  await updateDoc(doc(db, 'notifications', notif.id), { read: true });
                } catch (err) {}
              }
              if (notif.linkToRecordId && onNavigateToRecord) {
                onNavigateToRecord(notif.linkToRecordId);
              }
            }}>
              {isAdmin && (
                <div className="absolute top-4 right-4" onClick={(e) => e.stopPropagation()}>
                   <input 
                    type="checkbox" 
                    checked={selectedIds.has(notif.id)}
                    onChange={() => toggleSelect(notif.id)}
                    className="w-4 h-4 text-indigo-600 bg-slate-100 border-slate-300 rounded focus:ring-indigo-500 cursor-pointer"
                  />
                </div>
              )}
              <div className={cn(
                "w-10 h-10 rounded-xl flex items-center justify-center shrink-0",
                notif.type === 'warning' ? "bg-amber-100 text-amber-600" :
                notif.type === 'error' ? "bg-red-100 text-red-600" :
                "bg-indigo-100 text-indigo-600"
              )}>
                <Send size={20} />
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between gap-4 mb-1">
                  <h4 className="font-bold text-slate-900">{notif.title}</h4>
                  <span className="text-xs text-slate-500 whitespace-nowrap">
                    {notif.createdAt?.toDate ? format(notif.createdAt.toDate(), 'MMM dd, yyyy HH:mm') : 
                     notif.createdAt ? format(parseISO(notif.createdAt as string), 'MMM dd, yyyy HH:mm') : ''}
                  </span>
                </div>
                <p className="text-sm text-slate-600 mb-2">{notif.message}</p>
                {isAdmin && (
                  <div className="flex justify-end gap-2 mt-2">
                    <button 
                      onClick={(e) => { e.stopPropagation(); openEditMessage(notif); }}
                      className="px-3 py-1 bg-slate-100 hover:bg-slate-200 text-slate-600 font-medium rounded-lg text-xs transition border border-slate-200"
                    >
                      <Edit3 size={12} className="inline mr-1 -mt-0.5" /> Edit
                    </button>
                    {isAdmin && (
                      <button 
                        onClick={(e) => { e.stopPropagation(); handleDelete(notif.id); }}
                        className="px-3 py-1 bg-red-50 hover:bg-red-100 text-red-600 font-medium rounded-lg text-xs transition border border-red-100"
                      >
                        <Trash2 size={12} className="inline mr-1 -mt-0.5" /> Delete
                      </button>
                    )}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Edit/Create Modal */}
      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              onClick={() => setIsModalOpen(false)}
              className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="bg-white w-full max-w-lg rounded-3xl shadow-2xl overflow-hidden flex flex-col relative z-10"
            >
              <div className="p-5 border-b border-slate-100 flex items-center justify-between">
                <h2 className="text-lg font-bold text-slate-800">{editMessage ? "Edit Message" : "New Message"}</h2>
                <button onClick={() => setIsModalOpen(false)} className="p-2 hover:bg-slate-100 rounded-full">
                  <X size={20} />
                </button>
              </div>
              <div className="p-6 space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">To User / Target</label>
                  <select 
                    value={userId} onChange={(e) => setUserId(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl outline-none text-sm font-medium"
                  >
                    <option value="admin">All Admins (admin)</option>
                    {appUsers?.map(u => (
                      <option key={u.id} value={u.email}>{u.name || u.email} ({u.email})</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Type</label>
                  <select 
                    value={type} onChange={(e) => setType(e.target.value as any)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl outline-none text-sm font-medium"
                  >
                    <option value="info">Info</option>
                    <option value="warning">Warning</option>
                    <option value="error">Error</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Title</label>
                  <input 
                    type="text" value={title} onChange={e => setTitle(e.target.value)}
                    placeholder="Message Title"
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl outline-none text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Message</label>
                  <textarea 
                    value={message} onChange={e => setMessage(e.target.value)}
                    placeholder="Enter details..." rows={4}
                    className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl outline-none text-sm"
                  />
                </div>
              </div>
              <div className="p-5 border-t border-slate-100 bg-slate-50 flex justify-end gap-3">
                <button onClick={() => setIsModalOpen(false)} className="px-5 py-2 text-slate-600 font-bold hover:bg-slate-200 rounded-xl text-sm transition">Cancel</button>
                <button onClick={handleSave} className="px-5 py-2 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 shadow-md shadow-indigo-200 text-sm transition">
                  Save
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

function SettingsView({ 
  units,
  departments,
  isSuperAdmin,
  onAddUnit,
  onUpdateUnit,
  onDeleteUnit,
  onAddDept,
  onUpdateDept,
  onDeleteDept,
  itemsPerPage,
  onItemsPerPageChange,
  notificationSettings,
  onUpdateNotificationSettings,
  workflowSettings,
  onUpdateWorkflowSettings
}: { 
  units: Unit[],
  departments: Department[],
  isSuperAdmin?: boolean,
  onAddUnit: (id: string, name: string) => Promise<void>,
  onUpdateUnit: (id: string, name: string) => Promise<void>,
  onDeleteUnit: (id: string) => Promise<void>,
  onAddDept: (id: string, name: string) => Promise<void>,
  onUpdateDept: (id: string, name: string) => Promise<void>,
  onDeleteDept: (id: string) => Promise<void>,
  itemsPerPage: number,
  onItemsPerPageChange: (val: number) => void,
  notificationSettings?: NotificationSettings,
  onUpdateNotificationSettings?: (settings: NotificationSettings) => Promise<void>,
  workflowSettings?: WorkflowSettings,
  onUpdateWorkflowSettings?: (settings: WorkflowSettings) => Promise<void>
}) {
  const [newUnitId, setNewUnitId] = useState('');
  const [newUnitName, setNewUnitName] = useState('');
  const [newDeptId, setNewDeptId] = useState('');
  const [newDeptName, setNewDeptName] = useState('');

  const [editingUnitId, setEditingUnitId] = useState<string | null>(null);
  const [editUnitName, setEditUnitName] = useState('');

  const [editingDeptId, setEditingDeptId] = useState<string | null>(null);
  const [editDeptName, setEditDeptName] = useState('');

  const [localDaysBeforeReminder, setLocalDaysBeforeReminder] = useState(notificationSettings?.daysBeforeReminder ?? 1);
  const [localAdminWhatsApp, setLocalAdminWhatsApp] = useState(workflowSettings?.adminWhatsApp || '');

  useEffect(() => {
    setLocalDaysBeforeReminder(notificationSettings?.daysBeforeReminder ?? 1);
  }, [notificationSettings?.daysBeforeReminder]);

  useEffect(() => {
    setLocalAdminWhatsApp(workflowSettings?.adminWhatsApp || '');
  }, [workflowSettings?.adminWhatsApp]);

  return (
    <div className="space-y-8 pb-20">
      {/* Display Settings */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-6 border-b border-slate-100">
          <h2 className="text-lg font-bold">Display Settings</h2>
          <p className="text-sm text-slate-500">Customize how information is displayed.</p>
        </div>
        <div className="p-6">
          <div className="flex items-center justify-between max-w-md">
            <div>
              <label className="font-semibold text-slate-700 block">Items Per Page</label>
              <span className="text-xs text-slate-500">Number of items to show in the inventory table.</span>
            </div>
            <select 
              value={itemsPerPage}
              onChange={(e) => onItemsPerPageChange(Number(e.target.value))}
              className="p-2 bg-slate-50 border border-slate-200 rounded-lg text-sm outline-none focus:border-indigo-500 font-medium"
            >
              <option value={5}>5 Items</option>
              <option value={8}>8 Items</option>
              <option value={10}>10 Items</option>
              <option value={20}>20 Items</option>
              <option value={50}>50 Items</option>
            </select>
          </div>
        </div>
      </div>

      {/* Notification Settings */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden mb-6">
        <div className="p-6 border-b border-slate-100">
          <h2 className="text-lg font-bold flex items-center gap-2">
            <Bell size={20} className="text-indigo-600" />
            Automated Reminders Setup
          </h2>
          <p className="text-sm text-slate-500">Configure when the system automatically sends return reminder notifications.</p>
        </div>
        <div className="p-6">
          <div className="flex items-center justify-between max-w-md">
            <div>
              <label className="font-semibold text-slate-700 block">Days Before Due Date</label>
              <span className="text-xs text-slate-500 block max-w-[280px]">
                E.g. If borrowing for 5 days, sending notification 1 day before due means the reminder is sent on day 4.
              </span>
            </div>
            <div className="flex items-center gap-2">
              <input 
                type="number" 
                min={0}
                max={30}
                value={localDaysBeforeReminder}
                onChange={(e) => setLocalDaysBeforeReminder(Number(e.target.value) || 0)}
                className="p-2 w-20 text-center bg-slate-50 border border-slate-200 rounded-lg text-sm outline-none focus:border-indigo-500 font-medium"
              />
              <span className="text-sm text-slate-600 font-medium">Days</span>
              <button 
                onClick={() => {
                  if (onUpdateNotificationSettings) {
                    onUpdateNotificationSettings({ 
                      daysBeforeReminder: localDaysBeforeReminder 
                    });
                    alert('ບັນທຶກສຳເລັດ (Saved successfully)');
                  }
                }}
                className="ml-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-lg transition-colors"
              >
                ບັນທຶກ (Save)
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Workflow Configuration */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden mb-6">
        <div className="p-6 border-b border-slate-100">
          <h2 className="text-lg font-bold flex items-center gap-2">
            <ArrowLeftRight size={20} className="text-indigo-600" />
            Borrowing Approval Workflow
          </h2>
          <p className="text-sm text-slate-500">Enable or disable specific approval steps in the borrowing process.</p>
        </div>
        <div className="p-6 space-y-4">
          
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 bg-slate-50 border border-slate-100 rounded-xl">
            <div>
              <h4 className="font-bold text-slate-800 text-sm mb-1">Require Manager Acknowledge</h4>
              <span className="text-xs text-slate-500 max-w-sm block">
                If enabled, borrowers will be required to select a manager to acknowledge the request. If disabled, this step is skipped.
              </span>
            </div>
            <div className="flex items-center">
               <label className="relative inline-flex items-center cursor-pointer">
                  <input type="checkbox" className="sr-only peer" checked={workflowSettings?.requireManagerAcknowledge ?? true} onChange={(e) => {
                    if (onUpdateWorkflowSettings) {
                      onUpdateWorkflowSettings({ 
                        requireManagerAcknowledge: e.target.checked,
                        requireWhApprover: workflowSettings?.requireWhApprover ?? true
                      });
                    }
                  }} />
                  <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600"></div>
                </label>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 bg-slate-50 border border-slate-100 rounded-xl">
            <div>
              <h4 className="font-bold text-slate-800 text-sm mb-1">Require Department Head Approval</h4>
              <span className="text-xs text-slate-500 max-w-sm block">
                If enabled, borrowers will be required to select a department head or warehouse approver. If disabled, this step is skipped.
              </span>
            </div>
            <div className="flex items-center">
               <label className="relative inline-flex items-center cursor-pointer">
                  <input type="checkbox" className="sr-only peer" checked={workflowSettings?.requireWhApprover ?? true} onChange={(e) => {
                    if (onUpdateWorkflowSettings) {
                      onUpdateWorkflowSettings({ 
                        requireWhApprover: e.target.checked,
                        requireManagerAcknowledge: workflowSettings?.requireManagerAcknowledge ?? true
                      });
                    }
                  }} />
                  <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600"></div>
                </label>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 bg-slate-50 border border-slate-100 rounded-xl">
            <div>
              <p className="font-bold text-slate-800">Admin WhatsApp Number</p>
              <span className="text-sm text-slate-500 max-w-[400px] leading-relaxed block">
                Number used to notify administrators of new user registrations.
              </span>
            </div>
            <div className="flex items-center gap-2 w-full sm:w-auto">
                <input 
                  type="text" 
                  value={localAdminWhatsApp}
                  onChange={(e) => setLocalAdminWhatsApp(e.target.value)}
                  className="px-4 py-2 bg-white border border-slate-200 rounded-lg outline-none focus:border-indigo-500 w-full sm:w-[200px] text-sm"
                  placeholder="8562059682000"
                />
                <button 
                  onClick={() => {
                    if (onUpdateWorkflowSettings) {
                      onUpdateWorkflowSettings({ 
                        ...workflowSettings!,
                        adminWhatsApp: localAdminWhatsApp
                      });
                      alert('ບັນທຶກສຳເລັດ (Saved successfully)');
                    }
                  }}
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-lg transition-colors whitespace-nowrap"
                >
                  ບັນທຶກ (Save)
                </button>
            </div>
          </div>

        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Units Management */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="p-6 border-b border-slate-100 flex items-center justify-between">
            <div>
              <h2 className="text-lg font-bold">Units Management</h2>
              <p className="text-sm text-slate-500">Manage organizational units.</p>
            </div>
            <button 
              onClick={async () => {
                const list = ['FAU', 'OMU', 'SGU', 'HAU', 'ISU', 'CIU', 'COU', 'SCU'];
                for (const unit of list) {
                  await onAddUnit(unit, unit);
                }
              }}
              className="px-3 py-1.5 bg-indigo-50 text-indigo-600 rounded-lg text-sm font-bold hover:bg-indigo-100 transition-colors"
            >
              Import List
            </button>
          </div>
          <div className="p-6 space-y-4">
            <div className="flex gap-2">
              <input 
                type="text" 
                placeholder="ID" 
                className="w-20 p-2 bg-slate-50 border border-slate-200 rounded-lg text-sm outline-none focus:border-indigo-500"
                value={newUnitId}
                onChange={(e) => setNewUnitId(e.target.value)}
              />
              <input 
                type="text" 
                placeholder="Unit Name" 
                className="flex-1 p-2 bg-slate-50 border border-slate-200 rounded-lg text-sm outline-none focus:border-indigo-500"
                value={newUnitName}
                onChange={(e) => setNewUnitName(e.target.value)}
              />
              <button 
                onClick={() => {
                  const id = newUnitId.trim() || newUnitName.trim().toUpperCase().replace(/\s+/g, '-');
                  const name = newUnitName.trim();
                  if (id && name) {
                    onAddUnit(id, name);
                    setNewUnitId('');
                    setNewUnitName('');
                  } else {
                    alert('Please enter a Unit Name');
                  }
                }}
                className="p-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
              >
                <Plus size={20} />
              </button>
            </div>
            <div className="divide-y divide-slate-100 max-h-[300px] overflow-y-auto custom-scrollbar">
              {units.map(unit => (
                <div key={unit.id} className="py-3 flex items-center justify-between group">
                  {editingUnitId === unit.id ? (
                    <div className="flex items-center gap-2 flex-1 mr-4">
                      <input 
                        type="text" 
                        value={editUnitName}
                        onChange={(e) => setEditUnitName(e.target.value)}
                        className="flex-1 p-2 bg-slate-50 border border-slate-200 rounded-lg text-sm outline-none focus:border-indigo-500"
                        autoFocus
                      />
                      <button 
                        onClick={() => {
                          if (editUnitName.trim()) {
                            onUpdateUnit(unit.id, editUnitName.trim());
                          }
                          setEditingUnitId(null);
                        }}
                        className="p-1.5 text-indigo-600 hover:bg-indigo-50 rounded-lg transition-all"
                      >
                        <Check size={16} />
                      </button>
                      <button 
                        onClick={() => setEditingUnitId(null)}
                        className="p-1.5 text-slate-400 hover:bg-slate-50 rounded-lg transition-all"
                      >
                        <X size={16} />
                      </button>
                    </div>
                  ) : (
                    <>
                      <div className="flex flex-col">
                        <span className="text-sm font-bold text-slate-900">{unit.name}</span>
                        <span className="text-xs text-slate-400">{unit.id}</span>
                      </div>
                      <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-all">
                        <button 
                          onClick={() => {
                            setEditingUnitId(unit.id);
                            setEditUnitName(unit.name);
                          }}
                          className="p-1.5 text-slate-300 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-all"
                        >
                          <Edit2 size={16} />
                        </button>
                        {isSuperAdmin && (
                          <button 
                            onClick={() => onDeleteUnit(unit.id)}
                            className="p-1.5 text-slate-300 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-all"
                          >
                            <Trash2 size={16} />
                          </button>
                        )}
                      </div>
                    </>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Departments Management */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="p-6 border-b border-slate-100 flex items-center justify-between">
            <div>
              <h2 className="text-lg font-bold">Departments Management</h2>
              <p className="text-sm text-slate-500">Manage organizational departments.</p>
            </div>
            <button 
              onClick={async () => {
                const list = ['FMU', 'MTN-PL', 'MTN-CV', 'MTN-EL', 'MTN-EM', 'MTN-SC', 'MTN-ME', 'MTN-TL', 'OP-HM', 'OP-SCO', 'OP-DW'];
                for (const dept of list) {
                  await onAddDept(dept, dept);
                }
              }}
              className="px-3 py-1.5 bg-indigo-50 text-indigo-600 rounded-lg text-sm font-bold hover:bg-indigo-100 transition-colors"
            >
              Import List
            </button>
          </div>
          <div className="p-6 space-y-4">
            <div className="flex gap-2">
              <input 
                type="text" 
                placeholder="ID" 
                className="w-20 p-2 bg-slate-50 border border-slate-200 rounded-lg text-sm outline-none focus:border-indigo-500"
                value={newDeptId}
                onChange={(e) => setNewDeptId(e.target.value)}
              />
              <input 
                type="text" 
                placeholder="Dept Name" 
                className="flex-1 p-2 bg-slate-50 border border-slate-200 rounded-lg text-sm outline-none focus:border-indigo-500"
                value={newDeptName}
                onChange={(e) => setNewDeptName(e.target.value)}
              />
              <button 
                onClick={() => {
                  const id = newDeptId.trim() || newDeptName.trim().toUpperCase().replace(/\s+/g, '-');
                  const name = newDeptName.trim();
                  if (id && name) {
                    onAddDept(id, name);
                    setNewDeptId('');
                    setNewDeptName('');
                  } else {
                    alert('Please enter a Department Name');
                  }
                }}
                className="p-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
              >
                <Plus size={20} />
              </button>
            </div>
            <div className="divide-y divide-slate-100 max-h-[300px] overflow-y-auto custom-scrollbar">
              {departments.map(dept => (
                <div key={dept.id} className="py-3 flex items-center justify-between group">
                  {editingDeptId === dept.id ? (
                    <div className="flex items-center gap-2 flex-1 mr-4">
                      <input 
                        type="text" 
                        value={editDeptName}
                        onChange={(e) => setEditDeptName(e.target.value)}
                        className="flex-1 p-2 bg-slate-50 border border-slate-200 rounded-lg text-sm outline-none focus:border-indigo-500"
                        autoFocus
                      />
                      <button 
                        onClick={() => {
                          if (editDeptName.trim()) {
                            onUpdateDept(dept.id, editDeptName.trim());
                          }
                          setEditingDeptId(null);
                        }}
                        className="p-1.5 text-indigo-600 hover:bg-indigo-50 rounded-lg transition-all"
                      >
                        <Check size={16} />
                      </button>
                      <button 
                        onClick={() => setEditingDeptId(null)}
                        className="p-1.5 text-slate-400 hover:bg-slate-50 rounded-lg transition-all"
                      >
                        <X size={16} />
                      </button>
                    </div>
                  ) : (
                    <>
                      <div className="flex flex-col">
                        <span className="text-sm font-bold text-slate-900">{dept.name}</span>
                        <span className="text-xs text-slate-400">{dept.id}</span>
                      </div>
                      <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-all">
                        <button 
                          onClick={() => {
                            setEditingDeptId(dept.id);
                            setEditDeptName(dept.name);
                          }}
                          className="p-1.5 text-slate-300 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-all"
                        >
                          <Edit2 size={16} />
                        </button>
                        {isSuperAdmin && (
                          <button 
                            onClick={() => onDeleteDept(dept.id)}
                            className="p-1.5 text-slate-300 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-all"
                          >
                            <Trash2 size={16} />
                          </button>
                        )}
                      </div>
                    </>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// --- Helper Components ---

function StatCard({ title, value, icon: Icon, trend, color, isAlert, onClick }: any) {
  const colors: any = {
    indigo: "bg-indigo-50 text-indigo-600",
    amber: "bg-amber-50 text-amber-600",
    red: "bg-red-50 text-red-600",
    rose: "bg-rose-50 text-rose-600",
    emerald: "bg-emerald-50 text-emerald-600",
    blue: "bg-blue-50 text-blue-600",
    yellow: "bg-yellow-50 text-yellow-600",
  };

  return (
    <div 
      onClick={onClick}
      className={cn(
        "bg-white p-3 sm:p-4 rounded-2xl border border-slate-200 shadow-sm relative overflow-hidden group hover:shadow-md transition-all",
        isAlert && "border-red-100",
        onClick && "cursor-pointer hover:border-slate-300"
      )}
    >
      <div className="flex flex-col sm:flex-row items-center sm:items-start gap-2 sm:gap-4 text-center sm:text-left">
        <div className={cn("w-10 h-10 sm:w-12 sm:h-12 rounded-lg sm:rounded-xl flex items-center justify-center shrink-0", colors[color])}>
          <Icon className="w-5 h-5 sm:w-6 sm:h-6" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center sm:items-start justify-center sm:justify-start gap-2">
            <p className="text-[10px] sm:text-xs font-medium text-slate-500 truncate">{title}</p>
            {isAlert && <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse shrink-0"></div>}
          </div>
          <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-slate-900 truncate">{value}</h2>
          <div className="text-[10px] font-semibold text-slate-400 truncate mt-0.5">
            {trend}
          </div>
        </div>
      </div>
    </div>
  );
}

function StatusBadge({ status }: { status: ItemStatus }) {
  const styles: any = {
    'available': "bg-emerald-100 text-emerald-700",
    'borrowed': "bg-amber-100 text-amber-700",
    'maintenance': "bg-red-100 text-red-700",
    'low-stock': "bg-rose-100 text-rose-700",
  };

  return (
    <span className={cn("text-xs px-2.5 py-1 rounded-full font-bold uppercase tracking-wider", styles[status])}>
      {status.replace('-', ' ')}
    </span>
  );
}
