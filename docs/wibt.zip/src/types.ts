export type ItemStatus = 'available' | 'borrowed' | 'maintenance' | 'low-stock';

export interface Unit {
  id: string; // Unit ID
  name: string; // Unit Name
}

export interface Department {
  id: string; // Department ID
  name: string; // Department Name
  unitId: string; // Link to Unit
}

export interface InventoryItem {
  id: string; // Material ID
  name: string; // Description
  uom: string; // Unit of Measure
  sloc: string; // Storage Location
  bin: string; // Bin
  functionalSystem: string; // Functional system
  mfrPartNumber: string; // Mfr. Part Number
  brand: string; // Brand
  category: string;
  quantity: number;
  minQuantity: number;
  status: ItemStatus;
  lastUpdated: string;
  description?: string;
  photos?: string[]; // Up to 3 photos
}

export interface BorrowedItem {
  materialId: string;
  materialDescription: string;
  borrowQty: number;
  materialPhotos: string[];
  stockPhotos?: string[];
}

export interface BorrowRecord {
  id: string;
  requestNumber?: string;
  // User Info
  borrowerEmail: string;
  borrowerPhone: string;
  borrowerUnitId: string;
  borrowerDepartmentId: string;
  
  // Borrowing Type
  borrowType: 'new_inventory' | 'deposited_tools' | 'others';
  borrowTypeOthersDetail?: string;
  
  // Material Info
  items: BorrowedItem[];
  
  // Purposes & Approval
  borrowDate: string;
  purpose: string;
  periodDays: number;
  plannedReturnDate: string;
  managerAcknowledge: string; // Role: Acknowledge
  managerEmail?: string;
  managerPhone?: string;
  whApprover: string; // Role: Approver
  approverEmail?: string;
  approverPhone?: string;
  takingConfirmation: boolean;
  
  // Follow up / Tracking
  overdueDays: number;
  remindingMessage?: string;
  reminderBy?: string;
  reminderDate?: string;
  extensionRequest?: string; // Reason
  extensionDate?: string; // Requested Date
  extensionStatus?: 'pending' | 'approved' | 'rejected';
  
  // Returning and Closure
  finalReturnDate?: string;
  returnQty?: number;
  condition?: string;
  returnRemarks?: string;
  additionalInfo?: string;
  returnPhotos?: string[];
  borrowerReturnAcknowledge: boolean;
  borrowerReturnDate?: string;
  whReturnAcknowledge: boolean;
  
  status: 'active' | 'returned' | 'overdue' | 'deactivated';
  reminderSent?: boolean; // Track if the 5-day reminder was sent
}

export interface AppNotification {
  id: string;
  userId: string; // 'admin' or specific user email
  title: string;
  message: string;
  read: boolean;
  createdAt: any;
  type: 'warning' | 'info' | 'error';
  linkToRecordId?: string;
}

export interface WorkflowSettings {
  requireManagerAcknowledge: boolean;
  requireWhApprover: boolean;
  adminWhatsApp?: string;
}

export interface NotificationSettings {
  daysBeforeReminder: number;
}

export interface ActivityLog {
  id: string;
  timestamp: string;
  action: string;
  user: string;
  details: string;
}

export interface Rating {
  id: string;
  userId: string;
  userEmail: string;
  userName: string;
  rating: number;
  comment?: string;
  createdAt: any;
}
